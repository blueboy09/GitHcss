package herschel.ia.numeric.toolbox.matrix;



import java.io.IOException;

public class MatrixNumCount {

	
	//2D variable
	/**
	 * default memory allocation is 500(int)
	 */
	private static int _Dim=500;
	/**
	 *  Counter to record the number of created Matrix class 
	 */
	private static long _CreateMatrix;
	/**
	 * Counter to record the MatrixMultiply(Bool1d) method
	 */
	public static MatrixDim Bool1=new MatrixDim(_Dim,"Bool1");
	/**
	 * Counter to record the MatrixMultiply(Bool2d) method
	 */
	public static MatrixDim Bool2=new MatrixDim(_Dim,"Bool2");
	/**
	 * Counter to record the MatrixMultiply(Byte1d) method
	 */
	public static MatrixDim Byte1=new MatrixDim(_Dim,"Byte1");
	/**
	 * Counter to record the MatrixMultiply(Byte2d) method
	 */
	public static MatrixDim Byte2=new MatrixDim(_Dim,"Byte2");
	/**
	 * Counter to record the MatrixMultiply(Short1d) method
	 */
	public static MatrixDim Short1=new MatrixDim(_Dim,"Short1");
	/**
	 * Counter to record the MatrixMultiply(Short2d) method
	 */
	public static MatrixDim Short2=new MatrixDim(_Dim,"Short2");
	/**
	 * Counter to record the MatrixMultiply(Int1d) method
	 */
	public static MatrixDim Int1=new MatrixDim(_Dim,"Int1");
	/**
	 * Counter to record the MatrixMultiply(Int2d) method
	 */
	public static MatrixDim Int2=new MatrixDim(_Dim,"Int2");
	/**
	 * Counter to record the MatrixMultiply(Long1d) method
	 */
	public static MatrixDim Long1=new MatrixDim(_Dim,"Long1");
	/**
	 * Counter to record the MatrixMultiply(Long2d) method
	 */
	public static MatrixDim Long2=new MatrixDim(_Dim,"Long2");
	/**
	 * Counter to record the MatrixMultiply(Float1d) method
	 */
	public static MatrixDim Float1=new MatrixDim(_Dim,"Float1");
	/**
	 * Counter to record the MatrixMultiply(Float2d) method
	 */
	public static MatrixDim Float2=new MatrixDim(_Dim,"Float2");
	/**
	 * Counter to record the MatrixMultiply(Double1d) method
	 */
	public static MatrixDim Double1=new MatrixDim(_Dim,"Double1");
	/**
	 * Counter to record the MatrixMultiply(Double2d) method
	 */
	public static MatrixDim Double2=new MatrixDim(_Dim,"Double2");
	
	
	/**
	 * constructor
	 */
	public MatrixNumCount() {
		_CreateMatrix = 0 ;
		
	}
	/**
	 * reset all counters
	 */
	public static void ReSet(){
		_CreateMatrix = 0 ;
		Bool1.Reset();
		Bool2.Reset();
		Byte1.Reset();
		Byte2.Reset();
		Short1.Reset();
		Short2.Reset();
		Int1.Reset();
		Int2.Reset();
		Long1.Reset();
		Long2.Reset();
		Float1.Reset();
		Float2.Reset();
		Double1.Reset();
		Double2.Reset();

	}
	

	// 2D Get Value
	/**
	 * get the value of _Dim 
	 * @return return _Dim
	 */
	final static public int GetDimValue(){
		return _Dim;
	}
	
	/**
	 * get all value of counters
	 */
	final static public void MatrixGetALL(){
		System.out.println("CreateMatrixNum="+_CreateMatrix);
		MatrixDim [] OptArray={Bool1,Bool2,Byte1,Byte2,Short1,Short2,Int1,Int2,Long1,Long2,Float1,Float2,Double1,Double2};
		for(MatrixDim Opt:OptArray){
			System.out.println(Opt.get_name()+": "+Opt.OptGetValue());
		}
	}
	/**
	 * get the value of the Counter Opt
	 * @param Opt the Counter you care about 
	 * @return the Count number
	 */
	final static public long MatrixOptGetV(MatrixDim Opt){
		System.out.println(Opt.get_name()+": "+Opt.OptGetValue());
		return Opt.OptGetValue();
	}
	


	
	// the 2D Count
	/**
	 * _CreateDouble2d add one
	 */
	final static public void CreateMatrixCount(){
		_CreateMatrix = _CreateMatrix +1;
		
	}
	
	/**
	 * the Counter Opt add one
	 * @param Opt the Counter you care about
	 */

	final static public void MatrixOptCount(MatrixDim Opt){
		Opt.OptCount();
		
	}
	

	
	// the 2D Dimension Detail Count
	/**
	 * the specified data scale of the Counter add one
	 * @param Opt the Counter you care about 
	 * @param row the first dimension of the data scale
	 * @param col the second dimension of the data scale
	 */
	
		final static public void MatrixDimCount(MatrixDim Opt, int lhsM, int lhsN, int rhsN){
			int point;
			if(Opt.search(lhsM, lhsN,rhsN)==true){
				Opt.Calculate(lhsM,lhsN,rhsN);
			}
			else{
				point=Opt.find(lhsM, lhsN,rhsN);
				Opt.insert(point,lhsM,lhsN,rhsN);
			}
			
		}
	
	// 2D dimension detail get value
		/**
		 * get the detail result of the Counter
		 * @param Opt the Counter you care about
		 * @return the detail result of the Counter
		 */		
		final static public long[][] MatrixDimGet(MatrixDim Opt){
			long[][] M2dDim= null;
			int num=Opt.getNUM();
			M2dDim=new long[4][num];
			for (int i=0;i<num;i++){
				for (int j=0;j<4;j++){
					M2dDim[j][i]=Opt.get_MatrixDim()[j][i];					
				}
			}
			return M2dDim;
		}

		// the 2d dimension detail count output  
		/**
		 * output the result to the disc memory, default path is current path, default name is the Counter's name
		 * @param Opt the Counter 
		 * @throws IOException 
		 */

		final static public void MatrixNcOutput(MatrixDim Opt) throws IOException{
			try{
				  Opt.Output();
			
			  }catch(Exception e){
			
			     e.printStackTrace();
			  }
			  
			
		}
		/**
		 * output the result to the disc memory
		 * @param Opt the Counter
		 * @param name the filename 
		 * @param Path the directory
		 * @throws IOException 
		 */
		
		final static public void MatrixNcOutput(MatrixDim Opt,String name,String Path) throws IOException{
			  
			  
			  try{
				  Opt.Output(name, Path);
			     
			  }catch(Exception e){
			     // if any I/O error occurs
			     e.printStackTrace();
			  }
			  
		}
		/**
		 * input the result to RAM
		 * @param Opt the Counter
		 * @param name the filename
		 * @param Path the directory
		 * @return the detail result
		 * @throws IOException
		 */
		
		final static public long[][] MatrixNcInput(MatrixDim Opt,String name,String Path) throws IOException{
			  
			  long[][]dbuf=null;  
			  try{
				  
				  dbuf=Opt.Input(name, Path);
	  
				  
			  }catch(Exception e){
				     // if any I/O error occurs
				     e.printStackTrace();
			  }
			  return dbuf;
		}
		/**
		 * input the result to RAM, default filename is the name of the Counter, default path is current path  
		 * @param Opt the Counter
		 * @return the detail result
		 * @throws IOException
		 */		
		final static public long[][] MatrixNcInput(MatrixDim Opt) throws IOException{
			  long[][]dbuf=null;  
			  try{
				  dbuf=Opt.Input();
				  
			  }catch(Exception e){
				     // if any I/O error occurs
				     e.printStackTrace();
			  }
			  return dbuf;
		}
		

		
	
}

