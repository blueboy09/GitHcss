/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;

/**
 * <b>Facade</b> of matrix function objects for which only one
 * instance is available.
 * @author Jorgo Bakker <jbakker@rssd.esa.int>
 * @see herschel.ia.numeric.toolbox.matrix
 *
 * @jcategory Mathematics/Matrices
 */
public final class Matrix
{
    private Matrix() {}

    public final static MatrixDeterminant DETERMINANT=MatrixDeterminant.FUNCTION;
    public final static MatrixInverse     INVERSE    =MatrixInverse.FUNCTION;
    public final static MatrixTranspose   TRANSPOSE  =MatrixTranspose.FUNCTION;
}
