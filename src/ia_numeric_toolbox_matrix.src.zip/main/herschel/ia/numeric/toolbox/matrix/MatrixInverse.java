/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.*;

/**
 * Computes the inverse of a square matrix.
 * <p>
 * <pre>
 * <em>Compute A<sup>-1</sup> for A:</em>
 *  |5  -2|
 *  |     |
 *  |3   7|
 *
 * <em># jython:</em>
 * a=Int2d( [ [5,-2],[3,7] ])
 * aInv=MatrixInverse.FUNCTION(a)
 * <em># Note, for jython users a simplified approach is available:</em>
 * aInv=INVERSE(a)

 * <em>// java:</em>
 * ArrayData a=new Int2d( [ [5,-2],[3,7] ]);
 * ArrayData b=a.apply(MatrixInverse.FUNCTION);
 * </pre>
 *
 * @jhelp
 * Returns the inverse of a square matrix.
 *
 * @jalias INVERSE
 *
 * @jcategory Mathematics/Matrices
 *
 * @jsynopsis
 *  <y>=INVERSE(<x>)
 *
 * @jexample  Apply INVERSE to a Float2d matrix
 * x=Float2d([ [1,2],[3,4] ])
 * print INVERSE(x) # [ [-2.0,1.0], [1.5,-0.5] ]
 *
 * @jparameter x, INPUT, any square matrix, MANDATORY
 *   Any square matrix
 *
 * @jparameter y, INPUT, double, NOT_MANDATORY, false
 *   Returns a double
 *
 * @jmiscellaneous
 * Does not work for complex matrices.
 *
 * @author Jorgo Bakker <jbakker@rssd.esa.int>
 */
public class MatrixInverse extends AbstractOrderedXdToRealXd
{
    public static final MatrixInverse FUNCTION=new MatrixInverse();
    private MatrixInverse() {}

    public ArrayData of(Double2d x) {
	Util.checkIsSquare(x);
	double[][] y=new Jama.Matrix(x.getArray()).inverse().getArray();
	return new Double2d(y);
    }
}
