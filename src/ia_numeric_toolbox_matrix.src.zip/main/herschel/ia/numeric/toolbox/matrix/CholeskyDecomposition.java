/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;

import herschel.ia.numeric.Double2d;
import herschel.ia.numeric.Float2d;
import herschel.ia.numeric.toolbox.AbstractArrayToObject;

/**
 * CholeskyDecompostion, wraps the Jama class for DP.
 *  <P>
 *  For a symmetric, positive definite matrix A, the Cholesky decomposition
 *  is an lower triangular matrix L so that A = L*L'.
 *  <P>
 *  If the matrix is not symmetric or positive definite, the constructor
 *  returns a partial decomposition and sets an internal flag that may
 *  be queried by the isSPD() method.
 *  This documentation has been taken from the Jama.CholeskyDecompostion
 *  javadocs.
 *
 * <p>
 * Example:
 * <em># jython </em>
 * 
 * A=Double2d( [ [1.,1.,1.],[1.,2.,3.],[1.,3.,6.] ] )
 * B=Double2d( [ [1.,1.,1.],[1.,2.,3.],[1.,3.,6.] ] )
 * result = B.apply(CholeskyDecomposition(A))
 *
 * <em>// java: </em>
 *
 * </pre>
 * @jhelp CholeskyDecompositon
 *
 *
 * @jalias CholeskyDecomposition 
 *
 * @jcategory Mathematics/Matrices
 *
 * @jsynopsis
 *   A=Double2d()
 *   B=Double2d()
 *   res=B.apply(CholeskyDecomposition(A))
 *   
 *   CholeskyD = CholeskyDecomposition(A)
 *   solution = B.apply(CholeskyD)
 *   isSpd = CholeskyD.isSpd
 *   triangularFactor = CholeskyD.l
 * 
 * @jexample
 *  ######################################
 *  #####   CholeskyDecomposition    #####
 *  ######################################
 *  #
 *  ### HIPE ###
 *
 *  A=Double2d (\
 *      [\
 *         [3944.2141901709658, -39.83013886638742, 24.856149542676924, -49.90362121047403],\
 *         [-39.83013886638742, 3958.7850982903415, 39.244285251565444, 37.29778768650653],\
 *         [24.856149542676924, 39.244285251565444, 3952.2910884701473, -1.216735893731549],\
 *         [-49.90362121047403, 37.29778768650653, -1.216735893731549, 3950.7089115298527],\
 *      ])
 *
 *  B = Double2d (\
 *  [\
 *     [1184.8157857233916],\
 *     [-360.85066234104187],\
 *     [-426.7929837904702],\
 *     [-179.95015720518913],\
 *  ])
 *  
 *  CholeskyD = CholeskyDecomposition(A)
 *  solution = B.apply(CholeskyD)
 *  print solution
 *  [
 *  [0.29968672246274],
 *  [-0.08666981085100102],
 *  [-0.10902299389485229],
 *  [-0.04097866183941969]
 *  ]
 *  isSpd = CholeskyD.isSpd
 *  print isSpd
 *  1
 *  triangularFactor = CholeskyD.l
 *  print triangularFactor
 *  [
 *  [62.8029791504429,0.0,0.0,0.0],
 *  [-0.6342077940438997,62.91568070651636,0.0,0.0],
 *  [0.39577978431778954,0.6277495758130477,62.86286962351098,0.0],
 *  [-0.7946059547737568,0.5848119575853922,-0.020192561781548726,62.84691798442629]
 *  ]
 *  
 * @jparameter A, INPUT, Double2d , MANDATORY
 *   Input must be a Double2d or Float2d array.
 *
 *
 * @author Jeff Jacobson <jdj@ipac.caltech.edu>
 */
public class CholeskyDecomposition 
extends AbstractArrayToObject
{
	/**
	 * Wraps the Jama.CholeskyDecompostion class.
	 */
	private Jama.CholeskyDecomposition chd_;

	/**
	 * Default constructor.
	 */
	public CholeskyDecomposition () {}

	/** 
     * Cholesky algorithm for symmetric and positive definite matrix.
     * @param  A   Square, symmetric matrix.
     * @return     Structure to access L and isspd flag.
	 */	
	public CholeskyDecomposition(Double2d A) {
		chd_ = new Jama.CholeskyDecomposition(new Jama.Matrix (A.getArray()));
	}

	/**
     * Cholesky algorithm for symmetric and positive definite matrix.
     * @param  A   Square, symmetric matrix.
     * @return     Structure to access L and isspd flag.
	 */	
	public CholeskyDecomposition(Float2d A) {
		chd_ = new Jama.CholeskyDecomposition(
				new Jama.Matrix (new Double2d (A).getArray()));
	}

	/**
	 * Is the matrix symmetric and positive definite?
	 * return true or false
	 */
	public boolean getIsSpd() {
		return chd_.isSPD();
	}

	/**
	 * Return the triangular factor
	 * @return L
	 */
	public Double2d getL () {
		Double2d L = new Double2d (chd_.getL().getArray());
		return L;
	}

	/**
	 *  Solve A*X = B
     *  @param B    A Matrix with as many rows as A and any number of columns.
     *  @return     X so that L*L'X = B
     *  @exception  IllegalArgumentException  Matrix row dimensions must agree.
     *  @exception  RuntimeException  Matrix is not symmetric positive definite.
	 */
	public Double2d of (Double2d B) {
		Double2d S = new Double2d(chd_.solve(
			new Jama.Matrix(B.getArray())).getArray());
		return S;
	}
	
	/**
	 *  Solve A*X = B
     *  @param B    A Matrix with as many rows as A and any number of columns.
     *  @return     X so that L*L'X = B
     *  @exception  IllegalArgumentException  Matrix row dimensions must agree.
     *  @exception  RuntimeException  Matrix is not symmetric positive definite.
	 */
	public Double2d of (Float2d B) {
		Double2d dB = new Double2d (B);
		Double2d S = new Double2d(chd_.solve(
			new Jama.Matrix(dB.getArray())).getArray());
		return S;
	}
}

