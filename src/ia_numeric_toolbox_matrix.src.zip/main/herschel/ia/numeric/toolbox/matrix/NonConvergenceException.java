/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: NonConvergenceException.java,v 1.3 2010/10/18 21:30:33 jjacob Exp $
 *
 * Copyright (c) 2003 Do Kester SRON Groningen
 */

package herschel.ia.numeric.toolbox.matrix;

/**
 * Exception thrown when the iterative fitter stops while the minimum
 * has not yet been found.
 *
 * @author  Do Kester
 *
 * @jcategory Mathematics/Matrices
 *
 */
public class NonConvergenceException extends RuntimeException {

    private static final long serialVersionUID = 1l;        // first version

    /**
     * Create a new NonConvergenceException.
     */
    public NonConvergenceException() {
   super();
    }

    /**
     * Create a new NonConvergenceException with a message.
     *
     * @param string The message
     */
    public NonConvergenceException( String string ) {
   super( string );
    }
}
