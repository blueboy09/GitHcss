package herschel.ia.numeric.toolbox.matrix;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

class SVDPara{
	/**
	 * dim: predefine the space allocate to the _Detail array 
	 *  
	 */
	int dim;
	/**
	 * num: record the used space of the _Detail array
	 */
	int num;
	/**
	 * _Count: the times of the method being called 
	 */
	long _Count;
	/**
	 * the detail Counter
	 */
	long[][] _Detail;
	/**
	 * _para: the name of the subclass
	 */
	String _para;
	/**
	 * construct function
	 * @param _Dim predefine the space allocate to the _Detail array 
	 * @param name the name of the subclass 
	 * 
	 */
	SVDPara(int _Dim,String name){
		num=0;
		dim=_Dim;
		_Count=0;
		_Detail=new long[3][_Dim];
		_para=name;
	}
	/**
	 * Reset the Counter
	 */

	public void ReSet(){
		num=0;
		_Count=0;
		for(int i=0;i<3;i++){
			for(int j=0;j<dim;j++){
				_Detail[i][j] = 0;
			}
		}
				
	}

	/**
	 * the counter add one 
	 */
	public void NumCount(){
		_Count+=1;
	}
	/**
	 * 
	 * @return the times of being called of the method 
	 */
	public long GetCount(){
		System.out.println("the number of "+_para+": "+ _Count);
		return _Count;
	}
	
	
	
	// this part is used for dimension count
	/**
	 * search whether the data scale have been used before
	 * @param len the data dimension
	 * @return if find the data of this dimension has been counted before,
	 * 			 then return true. 
	 */
	public boolean search(int row, int col){
		boolean flag= false;
		for(int i=0;i<num;i++){
			if(_Detail[0][i]==row && _Detail[1][i]==col){
				flag=true;
				break;
			}
		}
		return flag;
	}
	
	/**
	 * 
	 * 	if the function "search" return true, then use this function. 
	 *  it means this dimension has appeared before, then it appeared again,
	 *  only need calculate once but not add another data kind.
	 *  
	 * @param len: the data scale (dimension)
	 * 
	 */

	public void Calculate(int row, int col){
		int point=0;
		for(int i=0;i<num;i++){
			if(_Detail[0][i]==row && _Detail[1][i]==col){
				point=i;
				break;
			}
		}
		_Detail[2][point] = _Detail[2][point]+1;
		
	}
	/**
	 * 
	 * 	this function used when "search" function return false, it means this data kind
	 *  didn't appear before, so we need find a place in the _Detail array 
	 *  to insert the new one.
	 *  
	 * @param len: the data dimension
	 * 
	 * @return the point where need add the new data kind
	 * 
	 * 
	 */
	public int find(int row,int col){
		int point=0;
		while(_Detail[0][point] < row && point < num){
			point++;
		}
		while(_Detail[1][point] < col && point < num){
			point++;
		}
		
		return point;
	}
	
	
	/**
	 * 
	 * @param point : the point to insert the new data kind
	 * @param len: the dimension of the new data kind
	 */	
	public void insert(int point,int row, int col){
		try {
		 
			if(num == dim) throw new Exception("space is not enough");
			for(int i= num;i>point;i--){
				for(int j=0;j<3;j++){
					_Detail[j][i]=_Detail[j][i-1];
				}
			}
			_Detail[0][point]=row;
			_Detail[1][point]=col;
			_Detail[2][point]=1;			
			num=num+1;
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("The recort space is not enough:"+e);
		}
		
	}
	
	/**
	 * 
	 * Count the detail information of the data used of target method
	 * @param len : the data dimension
	 *  
	 */
	public void DtlCount(int row, int col){
		int point;
		if(search(row,col)==true){
			Calculate(row,col);
		}
		else{
			point=find(row,col);
			insert(point,row,col);
		}

	}
	
	/**
	 * 
	 * @return the _detail array has been counted 
	 */
	public long[][] GetDtl(){
		long[][] SVDDim= null;
		SVDDim=new long[3][num];
		for (int i=0;i<num;i++){
			for (int j=0;j<3;j++){
				SVDDim[j][i]=_Detail[j][i];					
			}
		}
		return SVDDim;
	}
	/**
	 * 
	 * output the detail results
	 * @param name the subclass's name(_para)
	 * @param Path: output path
	 * @throws IOException
	 * 
	 */
	public void NcOutput(String name,String Path) throws IOException{
	      FileOutputStream fos = null;
	      DataOutputStream dos = null;
	      long[][] dbuf = new long[3][num];
	      for(int i=0;i<3;i++){
	    	  for(int j=0;j<num;j++){
	    		  dbuf[i][j]=_Detail[i][j];
	    	  }
	      }
		  try{
		     fos = new FileOutputStream(Path+name);
		     dos = new DataOutputStream(fos);
		     dos.writeInt(num);
		     for(int i=0;i<dbuf.length;i++){
		    	 for (long d:dbuf[i]){
					 dos.writeLong(d);         
				  }	 
		     }
		     
		     dos.flush();  
		  }catch(Exception e){
		     e.printStackTrace();
		  }finally{
		         if(dos!=null)
		            dos.close();
		         if(fos!=null)
		            fos.close();	      
		  }
	}
	/**
	 * 
	 * @param name the subclass's name(para)
	 * @param Path the input path
	 * @return: the detail results
	 * @throws IOException
	 */
	public long[][] NcInput(String name, String Path) throws IOException{
		  InputStream is = null;
		  DataInputStream dis = null;
		  long[][] dbuf=null ;
		  try{
			  is = new FileInputStream(Path+name);
			  dis = new DataInputStream(is);
	  	      int i=0;		   
		      int j=0;		   
		      int num=dis.readInt();
		     
		      dbuf=new long[3][num];
		      while(dis.available()>0)
		      {
		    	 if(j==num){ 
		    	 i++;
	    		 j=0;
	    	  }
	          dbuf[i][j] = dis.readLong();
	          j++;
		     }   
		  }catch(Exception e){     
			  e.printStackTrace();
		  }finally{
			  if(is!=null)
				  is.close();
			  if(dis!=null)	
			  	dis.close();
		  }
		return dbuf;
	}
}

/**
 * 
 * This class is used to count the times of SVD methods called in a jython pipeline. 
 *	
 */
public class SVDNumCount {
	
	/**
	 * the pre-define space used. default=500 (int) 
	 */
	final static int _Dim=300;
	/**
	 * constructor
	 */
	public SVDNumCount(){
	}

	//note that SVDF1 and SVDF2 used for Float2d. the difference of SVDF1 and SVDF2 is the call mode
	// SVDF1:
	//	SingularValueDecomposition svd= new SingularValueDecomposition(X);
	// SVDF2:
	// 		SingularValueDecomposition svd= new SingularValueDecomposition();
	//      X.apply(svd);
	/**
	 * the static class SVDF1 to count the SingularValueDecomposition(Float2d ) method 
	 */
	public static SVDPara SVDF1= new SVDPara(_Dim,"SVDF1");
	/**
	 * the static class SVDD1 to count the SingularValueDecomposition(Double2d ) method 
	 */
	public static SVDPara SVDD1= new SVDPara(_Dim,"SVDD1");
	/**
	 * the static class SVDF2 to count the SingularValueDecomposition(Float2d ) method 
	 */
	public static SVDPara SVDF2= new SVDPara(_Dim,"SVDF2");
	/**
	 * the static class SVDD2 to count the SingularValueDecomposition(Double2d ) method 
	 */
	public static SVDPara SVDD2= new SVDPara(_Dim,"SVDD2");
	/**
	 * the Counter list 
	 */
	public static SVDPara[] list={SVDF1,SVDF2,SVDD1,SVDD2};
	
	/**
	 * Reset all the subclass, i.e. recount again 
	 */
	public static void ReSet(){
		for(SVDPara Ops : list){
			Ops.ReSet();
		}
	}
	
	/**
	 * get all methods' count numbers
	 */
	public static void SVDGetALL(){
		for(SVDPara Ops : list){
			Ops.GetCount();
		}
	}
	/**
	 * output the all record results
	 * @param Path output path
	 * @throws IOException
	 */
	public static void SVDNcOutputALL(String Path) throws IOException{
		for(SVDPara Ops : list){
			Ops.NcOutput(Ops._para,Path);
		}
	}
	
	/**
	 * count the number of the operator
	 * @param Ops operator i.e. the method we want to count
	 * 
	 */
	
	public static void SVDCount(SVDPara Ops){
		Ops.NumCount();
	}
	
	/**
	 * get the times of the Ops method having been called 
	 * @param Ops operator i.e. the method we want to count
	 * @return the number has been count
	 */
	
	public static long SVDGetCount(SVDPara Ops){
		return Ops.GetCount();
	}
	
	/**
	 * Count the detail information 
	 * @param Ops operator i.e. the method we want to count
	 * @param len the dimension of the data 
	 */

	public static void SVDDtlCount(SVDPara Ops,int row,int col){
		Ops.DtlCount(row,col);
	}
	
	/**
	 * 
	 * get the detail results of method Ops
	 * @param Ops operator i.e. the method we want to count
	 * @return the detail information
	 */
	public static long[][] SVDGetDtl(SVDPara Ops){
		return Ops.GetDtl();
	}
	
	/**
	 * Output the detail result of method Ops
	 * @param Ops operator i.e. the method we want to count
	 * @param Path output path
	 * @throws IOException
	 */
	
	public static void SVDNcOutput(SVDPara Ops,String Path) throws IOException{
		Ops.NcOutput(Ops._para, Path);
	}

	/**
	 * 
	 * input the detail result of method Ops
	 * @param Ops  operator i.e. the method we want to count
	 * @param Path input path
	 * @return return the input result
	 * @throws IOException
	 */
	public static long[][] SVDNcInput(SVDPara Ops,String Path) throws IOException{
		return Ops.NcInput(Ops._para, Path);
	}
		
	
}