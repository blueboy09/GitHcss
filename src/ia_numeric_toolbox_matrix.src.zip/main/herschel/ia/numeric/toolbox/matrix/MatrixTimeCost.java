package herschel.ia.numeric.toolbox.matrix;


import java.io.IOException;
import java.util.Random;

import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.matrix.MatrixMultiply;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Bool1;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Bool2;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Byte1;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Byte2;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Short1;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Short2;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Int1;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Int2;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Long1;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Long2;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Float1;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Float2;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Double1;
import static herschel.ia.numeric.toolbox.matrix.MatrixNumCount.Double2;

/**
 * 
 * @author Yifei Jin <m-astro@163.com>
 *
 */

public class MatrixTimeCost {

	private String name="MatrixTimeCost";
	/**
	 * Constructor
	 */	
	public MatrixTimeCost() {
	}
	/**
	 * Constructor 
	 * @param _name the name of the class MatrixTimeCost
	 */
	public MatrixTimeCost(String _name) {
		this.name=_name;
	}
	
	/**
	 * input the count number from disc
	 * @param Opt the Counter 
	 * @param name filename
	 * @param Path file directory
	 * @return the count result array
	 * @throws IOException
	 */
	final static public long[][] MatrixInput(MatrixDim Opt, String name, String Path) throws IOException{
		  
		  long[][]dbuf=null;  
		  
		  try{
			  dbuf=Opt.Input(name, Path);		  
		  }catch(Exception e){
			     // if any I/O error occurs
			     e.printStackTrace();
		  }
		  return dbuf;
	}
	
	/**
	 * input the count number from disc, default filename is the counter's name, default directory is the current path
	 * @param Opt the Counter we care about
	 * @return
	 */
	final static public long[][] MatrixInput(MatrixDim Opt){
		  long[][]dbuf=null;  
		  try{
			  dbuf=Opt.Input();
			  
		  }catch(Exception e){
			     // if any I/O error occurs
			     e.printStackTrace();
		  }
		  return dbuf;
		
	}
//------------------------------- Time Cost----------------------------------------
// the main function to calculate the time used
	/**
	 * calculate the time cost of the Opt Counter 
	 * @param Opt the counter we care about
	 * @param name the  filename 
	 * @param Path the count results' directory
	 * @return the time cost of the method which we use the counter record 
	 * @throws IOException
	 */
	public double TimeCost (MatrixDim Opt, String name, String Path) throws IOException{
		long[][] dbuf = MatrixInput(Opt,name,Path);
		int lhsM,lhsN,rhsN,nums;
		int row=dbuf.length;
		if(row!=4) throw new IllegalArgumentException("the lead dimension unmatched");
		int col=dbuf[0].length;
		double AllTime=0;
		for(int i=0;i<col;i++){
				lhsM=(int)(dbuf[0][i]);
				lhsN=(int)(dbuf[1][i]);
				rhsN=(int)(dbuf[2][i]);
				nums=(int)(dbuf[3][i]);
				for(int j=0;j<nums;j++){
					AllTime=AllTime+TimeCal(Opt,lhsM,lhsN,rhsN);
				}
		}
		return AllTime;
	}
//------------------------------calculate the MatrixMultiply Once-----------------------
	/**
	 * the time cost of the target method by once called 
	 * @param Opt the counter 
	 * @param lhsM the first dimension of data scale
	 * @param lhsN the second dimension of data scale
	 * @return
	 */

		public double TimeCal(MatrixDim Opt,int lhsM, int lhsN, int rhsN){
		
		double timeBegin=0, timeEnd = 0;
		if(Opt==Bool1){
			if(lhsM!=1){
				throw new IllegalArgumentException("the lead dimension unmatched");
			}
			boolean[][] LM=GenerateBoolArray(lhsM,lhsN);
			boolean[][] RM=GenerateBoolArray(lhsN,rhsN);
			Bool2d LArray= new Bool2d(LM);
			Bool2d RArray= new Bool2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
			
		}else if(Opt==Byte1){
			if(lhsM!=1){
				throw new IllegalArgumentException("the lead dimension unmatched");
			}
			byte[][] LM=GenerateByteArray(lhsM,lhsN);
			byte[][] RM=GenerateByteArray(lhsN,rhsN);
			Byte2d LArray= new Byte2d(LM);
			Byte2d RArray= new Byte2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
		}else if(Opt==Short1){
			if(lhsM!=1){
				throw new IllegalArgumentException("the lead dimension unmatched");
			}
			short [][] LM=GenerateShortArray(lhsM,lhsN);
			short [][] RM=GenerateShortArray(lhsN,rhsN);
			Short2d LArray= new Short2d(LM);
			Short2d RArray= new Short2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
		}else if(Opt==Int1){
			if(lhsM!=1){
				throw new IllegalArgumentException("the lead dimension unmatched");
			}
			int [][] LM=GenerateIntArray(lhsM,lhsN);
			int [][] RM=GenerateIntArray(lhsN,rhsN);
			Int2d LArray= new Int2d(LM);
			Int2d RArray= new Int2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
			
		}else if(Opt==Long1){
			if(lhsM!=1){
				throw new IllegalArgumentException("the lead dimension unmatched");
			}
			long [][] LM=GenerateLongArray(lhsM,lhsN);
			long [][] RM=GenerateLongArray(lhsN,rhsN);
			Long2d LArray= new Long2d(LM);
			Long2d RArray= new Long2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
			
		}else if(Opt==Float1){
			if(lhsM!=1){
				throw new IllegalArgumentException("the lead dimension unmatched");
			}
			float[][] LM=GenerateFloatArray(lhsM,lhsN);
			float[][] RM=GenerateFloatArray(lhsN,rhsN);
			Float2d LArray= new Float2d(LM);
			Float2d RArray= new Float2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
		}else if(Opt==Double1){
			if(lhsM!=1){
				throw new IllegalArgumentException("the lead dimension unmatched");
			}
			double[][] LM=GenerateDoubleArray(lhsM,lhsN);
			double[][] RM=GenerateDoubleArray(lhsN,rhsN);
			Double2d LArray= new Double2d(LM);
			Double2d RArray= new Double2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
		}else if(Opt==Bool2){
			boolean[][] LM=GenerateBoolArray(lhsM,lhsN);
			boolean[][] RM=GenerateBoolArray(lhsN,rhsN);
			Bool2d LArray= new Bool2d(LM);
			Bool2d RArray= new Bool2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
			
		}else if(Opt==Byte2){
			byte[][] LM=GenerateByteArray(lhsM,lhsN);
			byte[][] RM=GenerateByteArray(lhsN,rhsN);
			Byte2d LArray= new Byte2d(LM);
			Byte2d RArray= new Byte2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
			
		}else if(Opt==Short2){
			short [][] LM=GenerateShortArray(lhsM,lhsN);
			short [][] RM=GenerateShortArray(lhsN,rhsN);
			Short2d LArray= new Short2d(LM);
			Short2d RArray= new Short2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
			
		}else if(Opt==Int2){
			int [][] LM=GenerateIntArray(lhsM,lhsN);
			int [][] RM=GenerateIntArray(lhsN,rhsN);
			Int2d LArray= new Int2d(LM);
			Int2d RArray= new Int2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
			
		}else if(Opt==Long2){
			long [][] LM=GenerateLongArray(lhsM,lhsN);
			long [][] RM=GenerateLongArray(lhsN,rhsN);
			Long2d LArray= new Long2d(LM);
			Long2d RArray= new Long2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
			
		}else if(Opt==Float2){
			float[][] LM=GenerateFloatArray(lhsM,lhsN);
			float[][] RM=GenerateFloatArray(lhsN,rhsN);
			Float2d LArray= new Float2d(LM);
			Float2d RArray= new Float2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
			
		}else if(Opt==Double2){
			double[][] LM=GenerateDoubleArray(lhsM,lhsN);
			double[][] RM=GenerateDoubleArray(lhsN,rhsN);
			Double2d LArray= new Double2d(LM);
			Double2d RArray= new Double2d(RM);
			MatrixMultiply MaMul=new MatrixMultiply(RArray);
			timeBegin=System.nanoTime();
			LArray.apply(MaMul);
			timeEnd=(double)(System.nanoTime()-timeBegin);
			timeEnd=timeEnd/1000000000.0;
		}else{
			timeEnd=-1;
			throw new IllegalArgumentException("these kind of operation is not exsit");
		}
		
		return timeEnd;
	}

	//----------------------------// Generate Array //---------------------------------------------------
		/**
		 * generate random double2d array 
		 * @param lhsM the first dimension
		 * @param lhsN the second dimension
		 * @return a random double2d array
		 */
	public double[][] GenerateDoubleArray(int lhsM, int lhsN){
		Random rdm =new Random();
		double[][] CalArray= new double[lhsM][lhsN];
		for(int i=0;i<lhsM;i++){
			for (int j=0;j<lhsN;j++){
				CalArray[i][j]=10*rdm.nextDouble();
			}
		}
		return CalArray;
	}
	/**
	 * generate random float2d array
	 * @param lhsM the first dimension
	 * @param lhsN the second dimension
	 * @return a random float2d array
	 */
	public float[][] GenerateFloatArray(int lhsM, int lhsN){
		Random rdm =new Random();
		float[][] CalArray= new float[lhsM][lhsN];
		for(int i=0;i<lhsM;i++){
			for (int j=0;j<lhsN;j++){
				CalArray[i][j]=10*rdm.nextFloat();
			}
		}
		return CalArray;
	}
	/**
	 * generate random Long2d array
	 * @param lhsM the first dimension
	 * @param lhsN the second dimension
	 * @return a random Long2d array
	 */	
	public long[][] GenerateLongArray(int lhsM, int lhsN){
		Random rdm =new Random();
		long[][] CalArray= new long[lhsM][lhsN];
		for(int i=0;i<lhsM;i++){
			for (int j=0;j<lhsN;j++){
				CalArray[i][j]=10*rdm.nextLong();
			}
		}
		return CalArray;
	}
	/**
	 * generate random Int2d array
	 * @param lhsM the first dimension
	 * @param lhsN the second dimension
	 * @return a random Int2d array
	 */
	public int[][] GenerateIntArray(int lhsM, int lhsN){
		Random rdm =new Random();
		int[][] CalArray= new int[lhsM][lhsN];
		for(int i=0;i<lhsM;i++){
			for (int j=0;j<lhsN;j++){
				CalArray[i][j]=10*rdm.nextInt();
			}
		}
		return CalArray;
	}
	/**
	 * generate random Short2d array
	 * @param lhsM the first dimension
	 * @param lhsN the second dimension
	 * @return a random Short2d array
	 */
	public short[][] GenerateShortArray(int lhsM, int lhsN){
		Random rdm =new Random();
		short[][] CalArray= new short[lhsM][lhsN];
		for(int i=0;i<lhsM;i++){
			for (int j=0;j<lhsN;j++){
				CalArray[i][j]=(short) (10*rdm.nextInt());
			}
		}
		return CalArray;
	}
	/**
	 * generate random Byte2d array
	 * @param lhsM the first dimension
	 * @param lhsN the second dimension
	 * @return a random Byte2d array
	 */
	public byte[][] GenerateByteArray(int lhsM, int lhsN){
		Random rdm =new Random();
		byte[][] CalArray= new byte[lhsM][lhsN];
		for(int i=0;i<lhsM;i++){
			rdm.nextBytes(CalArray[i]);
		}
		return CalArray;
	}
	/**
	 * generate random Bool2d array
	 * @param lhsM the first dimension
	 * @param lhsN the second dimension
	 * @return a random Bool2d array
	 */
	public boolean[][] GenerateBoolArray(int lhsM, int lhsN){
		Random rdm =new Random();
		boolean[][] CalArray= new boolean[lhsM][lhsN];
		for(int i=0;i<lhsM;i++){
			for (int j=0;j<lhsN;j++){
				CalArray[i][j]=rdm.nextBoolean();
			}
		}
		return CalArray;
	}
	//--------------------------------------get & set -----------------------------------
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	

}
