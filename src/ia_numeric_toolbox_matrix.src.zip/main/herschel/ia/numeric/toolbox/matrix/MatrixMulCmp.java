package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.*;
import java.util.Random;


/**
 * 
 * @author Yifei jin<m-astro@163.com>
 *
 */

public class MatrixMulCmp {


	
	public final int LOGSCALE=0;
	public final int LINESCALE=1;
	public final int FLOAT=0;
	public final int DOUBLE=1;
	
	int begin;
	int end;
	int step;
	int num;
	int type;
	
	public MatrixMulCmp(){
		begin=1;
		end=1001;
		step=20;
		num=50;
		type=DOUBLE;
	}

	public MatrixMulCmp(int _begin, int _end, int _step,int _num, int _type) {
		begin=_begin;
		end=_end;
		step=_step;
		num=_num;
		type=_type;
	}
	
	public void SetPara(int _begin, int _end, int _step,int _num, int _type) {
		this.begin=_begin;
		this.end=_end;
		this.step=_step;
		this.num=_num;
		this.type=_type;
	}
	
	public double[][] MatrixMultime(int scaleMode){
		if(scaleMode==this.LINESCALE){
			double[][] timelist= new double[2][(int)((end-begin)/step)];
			double[] timeonce ={0,0};
			int j=0;
			for(int i=begin;i<end;i+=step){
				timeonce=ComPare(i,this.num,this.type);
				timelist[0][j]=timeonce[0];
				timelist[1][j]=timeonce[1];
				j=j+1;
			}
			return timelist;
		}else if(scaleMode==this.LOGSCALE){
			double[][] timelist= new double[2][(int)((end-begin)/step)];
			double[] timeonce ={0,0};
			int j=0;
			for(int i=begin;i<end;i+=step){
				timeonce=ComPare((int)java.lang.Math.pow(2, i),this.num,this.type);
				timelist[0][j]=timeonce[0];
				timelist[1][j]=timeonce[1];
				j=j+1;
			}
			return timelist;
			
		}else{
			throw new IllegalArgumentException("NO SUCH SCALE MODE");
		}
		
		
	}
	
	public double[] ComPare(int dim, int num,int type) {
		
		Float2d Xf=null,Yf=null;
		Double2d Xd=null,Yd=null;
		double[] timelist =null;
		double timeBegin=0,timeEnd=0;
		double cuTime=0,jaTime=0;
		if(type==this.FLOAT){
			for(int i=0;i<num;i++){
				Xf=GenerateFloatArray(dim,dim);
				Yf=GenerateFloatArray(dim,dim);
				MatrixMultiply Majava= new MatrixMultiply(Xf); 
				timeBegin=(double)System.nanoTime();
				Yf.apply(Majava);	
				timeEnd =(double)System.nanoTime() - timeBegin;
				jaTime+=timeEnd;
				
				MatrixMultiply1 Macuda= new MatrixMultiply1(Xf);
				timeBegin=(double)System.nanoTime();
				Yf.apply(Macuda);
				timeEnd =(double)System.nanoTime() - timeBegin;
				cuTime+=timeEnd;
			}
		}
		else if(type==this.DOUBLE){
			for(int i=0;i<num;i++){
				Xd=GenerateDoubleArray(dim,dim);
				Yd=GenerateDoubleArray(dim,dim);
				MatrixMultiply Majava= new MatrixMultiply(Xd); 
				timeBegin=(double)System.nanoTime();
				Yd.apply(Majava);	
				timeEnd =(double)System.nanoTime() - timeBegin;
				jaTime+=timeEnd;
				
				MatrixMultiply1 Macuda= new MatrixMultiply1(Xd);
				timeBegin=(double)System.nanoTime();
				Yd.apply(Macuda);
				timeEnd =(double)System.nanoTime() - timeBegin;
				cuTime+=timeEnd;
			}
		}else {
			throw new IllegalArgumentException("the data type is error");
		}		
		
		jaTime = jaTime/(1000000000.0*num);
		cuTime = cuTime/(1000000000.0*num);
		timelist=new double[]{jaTime,cuTime};
		return timelist;
		
	}
	
	public Double2d GenerateDoubleArray(int col,int row){
		Random rdm= new Random();
		double[][] X = new double[col][row];
		for(int i=0;i<col;i++){
			for(int j=0;j<row;j++){
				X[i][j]=rdm.nextDouble();
			}

		}
		Double2d Array = new Double2d(X);
		return Array;
	}
	
	public Float2d GenerateFloatArray(int col,int row){
		Random rdm= new Random();
		float[][] X = new float[col][row];
		for(int i=0;i<col;i++){
			for(int j=0;j<row;j++){
				X[i][j]=rdm.nextFloat();
			}

		}
		Float2d Array = new Float2d(X);
		return Array;
	}	
	

}

