/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*  -*-java-*-   This is an automatically generated file.
 *                  It will be created from a template.
 *                         Do Not Edit!
 * 
 *  Copyright (c) 2003-2004 Jorgo Bakker and Jon Brumfitt
 *  Template file "template/MatrixTranspose.tpl"
 */
package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.AbstractArrayToArray;

/**
 * Transposes a matrix.
 *
 * @jhelp
 *    Transposes a matrix.
 *
 * @jalias TRANSPOSE
 *
 * @jcategory Mathematics/Matrices
 *
 * @jsynopsis 
 *   <y>=TRANSPOSE(<x>)
 *
 * @jexample Transposing a 2D array
 *    x=Int2d([ [1,2],[3,4],[5,6] ])
 *    print TRANSPOSE(x) # [ [1,3,5],[2,4,6] ]
 *
 * @jparameter x, INPUT, Array2dData, MANDATORY
 *    Input must be a 2d array as defined by the numeric library.
 *
 * @jmiscellaneous
 *    TRANSPOSE is an alias for MatrixTranspose.FUNCTION
 *
 * @author Jorgo Bakker <jbakker@rssd.esa.int>
 */
public class MatrixTranspose extends AbstractArrayToArray
{
    public static final MatrixTranspose FUNCTION=new MatrixTranspose();

    private MatrixTranspose() {}

    /**
     * Returns a transposed array of type Bool2d.
     */
    public ArrayData of(Bool2d x) {
	// get the dimensions and create a new array:
	final int[] dim=x.getDimensions();
	final int m=dim[0],n=dim[1];
	Bool2d y=new Bool2d(n,m);

	// adapt inner arrays:
	boolean[][] lhs=y.getArray();
	boolean[][] rhs=x.getArray();
	for(int i=0; i<m; i++) for(int j=0; j<n; j++) lhs[j][i] = rhs[i][j];
	
	// and pass it back:
	return y;
    }
    
    /**
     * Returns a transposed array of type Byte2d.
     */
    public ArrayData of(Byte2d x) {
	// get the dimensions and create a new array:
	final int[] dim=x.getDimensions();
	final int m=dim[0],n=dim[1];
	Byte2d y=new Byte2d(n,m);

	// adapt inner arrays:
	byte[][] lhs=y.getArray();
	byte[][] rhs=x.getArray();
	for(int i=0; i<m; i++) for(int j=0; j<n; j++) lhs[j][i] = rhs[i][j];
	
	// and pass it back:
	return y;
    }
    
    /**
     * Returns a transposed array of type Short2d.
     */
    public ArrayData of(Short2d x) {
	// get the dimensions and create a new array:
	final int[] dim=x.getDimensions();
	final int m=dim[0],n=dim[1];
	Short2d y=new Short2d(n,m);

	// adapt inner arrays:
	short[][] lhs=y.getArray();
	short[][] rhs=x.getArray();
	for(int i=0; i<m; i++) for(int j=0; j<n; j++) lhs[j][i] = rhs[i][j];
	
	// and pass it back:
	return y;
    }
    
    /**
     * Returns a transposed array of type Int2d.
     */
    public ArrayData of(Int2d x) {
	// get the dimensions and create a new array:
	final int[] dim=x.getDimensions();
	final int m=dim[0],n=dim[1];
	Int2d y=new Int2d(n,m);

	// adapt inner arrays:
	int[][] lhs=y.getArray();
	int[][] rhs=x.getArray();
	for(int i=0; i<m; i++) for(int j=0; j<n; j++) lhs[j][i] = rhs[i][j];
	
	// and pass it back:
	return y;
    }
    
    /**
     * Returns a transposed array of type Long2d.
     */
    public ArrayData of(Long2d x) {
	// get the dimensions and create a new array:
	final int[] dim=x.getDimensions();
	final int m=dim[0],n=dim[1];
	Long2d y=new Long2d(n,m);

	// adapt inner arrays:
	long[][] lhs=y.getArray();
	long[][] rhs=x.getArray();
	for(int i=0; i<m; i++) for(int j=0; j<n; j++) lhs[j][i] = rhs[i][j];
	
	// and pass it back:
	return y;
    }
    
    /**
     * Returns a transposed array of type Float2d.
     */
    public ArrayData of(Float2d x) {
	// get the dimensions and create a new array:
	final int[] dim=x.getDimensions();
	final int m=dim[0],n=dim[1];
	Float2d y=new Float2d(n,m);

	// adapt inner arrays:
	float[][] lhs=y.getArray();
	float[][] rhs=x.getArray();
	for(int i=0; i<m; i++) for(int j=0; j<n; j++) lhs[j][i] = rhs[i][j];
	
	// and pass it back:
	return y;
    }
    
    /**
     * Returns a transposed array of type Double2d.
     */
    public ArrayData of(Double2d x) {
	// get the dimensions and create a new array:
	final int[] dim=x.getDimensions();
	final int m=dim[0],n=dim[1];
	Double2d y=new Double2d(n,m);

	// adapt inner arrays:
	double[][] lhs=y.getArray();
	double[][] rhs=x.getArray();
	for(int i=0; i<m; i++) for(int j=0; j<n; j++) lhs[j][i] = rhs[i][j];
	
	// and pass it back:
	return y;
    }
    
    /**
     * Returns a transposed array of type Complex2d.
     */
    public ArrayData of(Complex2d x) {
	// get the dimensions and create a new array:
	final int[] dim=x.getDimensions();
	final int m=dim[0],n=dim[1];
	Complex2d y=new Complex2d(n,m);

	// adapt inner arrays:
	double[][] lhs=y.realArray();
	double[][] rhs=x.realArray();
	for(int i=0; i<m; i++) for(int j=0; j<n; j++) lhs[j][i] = rhs[i][j];

	lhs=y.imagArray();
	rhs=x.imagArray();
	for(int i=0; i<m; i++) for(int j=0; j<n; j++) lhs[j][i] = rhs[i][j];
	
	// and pass it back:
	return y;
    }
    
}
