
/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2011 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*  -*-java-*-   This is an automatically generated file.
 *                  It will be created from a template.
 *                         Do Not Edit!
 * 
 *  Copyright (c) 2003-2004 Jorgo Bakker and Jon Brumfitt
 *  Template file "template/MatrixMultiply.tpl"
 */
package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.AbstractArrayToArray;
import herschel.ia.numeric.toolbox.basic.Reshape;
import herschel.ia.numeric.toolbox.basic.Basic; // CONCATENATE
import jcuda.*;
import jcuda.jcublas.JCublas;

/**
 * Performs matrix multiplication of numeric or logical matrices.
 *
 * @jhelp
 *    Performs matrix multiplication of numeric or logical matrices.
 *
 * @jalias
 @    MATRIXMULTIPLY
 * 
 * @jcategory Mathematics/Matrices
 *
 * @jsynopsis 
 *   <y>=MatrixMultiply(<b>)(<a>)
 *
 * @jexample-preamble
 * a = Int2d([[1,2,3], [2,3,4]])
 * b = Int2d([[1,2], [2,3], [3,4]])
 * @jexample Different syntax forms
 *    # spelled out:
 *    c=MatrixMultiply(b)(a)
 *    c=a.apply(MatrixMultiply(b))
 *    #
 *    # reusing an instance of a matrix-multiplier:
 *    f=MatrixMultiply(b)
 *    c=f(a)
 *    c=a.apply(f)
 * @jexample-postamble
 * del(a, b)
 *
 * @jexample Matrix multiplication examples
 *    A = Int2d([[1,2,3], [2,3,4]])
 *    B = Int2d([[1,2], [2,3], [3,4]])
 *    X = Int1d([1,2])
 *    Y = Int1d([1,2,3])
 *    #
 *    print A.apply(MatrixMultiply(B))
 *    [[14, 20], [20, 29]]
 *                                 
 *    print X.apply(MatrixMultiply(A))
 *    [5, 8, 11]
 *    
 *    print A.apply(MatrixMultiply(Y))
 *    [14, 20]
 * 
 * @jparameter a, INPUT, Array1dData or Array2dData, MANDATORY
 *    Input must be a rank one or rank two array of any type, but String or Complex.
 *
 * @jparameter b, INPUT, Array1dData or Array2dData, MANDATORY
 *    Input must be an array of the same type as 'a'. If 'a' has rank one, 'b'
 *    must have rank two. If 'b' has rank one, 'a' must have rank two.
 *
 * @jmiscellaneous
 *    Complex arrays are not supported yet.
 * @author Jorgo Bakker <jbakker@rssd.esa.int>
 */
public class MatrixMultiply1 extends AbstractArrayToArray
{
    private final ArrayData _rhs;
    private final int _rhsM,_rhsN;
    private final boolean _rhsIsRankOneArray;
    private transient int _lhsM,_lhsN;

    public MatrixMultiply1(Array2dData rhs) {
	if (rhs==null)
	    throw new NullPointerException("Null is not allowed as input argument.");
	final int[] d=rhs.getDimensions();
	_rhs=rhs;
	_rhsM=d[0];
	_rhsN=d[1];
	_rhsIsRankOneArray=false;
    }

    public MatrixMultiply1(Array1dData rhs) {
	if (rhs==null)
	    throw new NullPointerException("Null is not allowed as input argument.");
	_rhsM=rhs.getSize();
	_rhsN=1;
	_rhs=rhs.apply(new Reshape(_rhsM,_rhsN));
	_rhsIsRankOneArray=true;
    }

    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Bool1d.
     */
    public ArrayData of(Bool1d lhs) {
	return to2d(lhs).apply(this).apply(Basic.CONCATENATE);
    }

    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Bool2d.
     */
    public ArrayData of(Bool2d lhs) {
	validate(lhs);
	Bool2d rhs=(Bool2d)_rhs;

	// create the resulting array and some short-cuts:
	Bool2d y=new Bool2d(_lhsM,_rhsN);
	final boolean[][] rA=rhs.getArray();
	final boolean[][] lA=lhs.getArray();
	final boolean[][] yA=y.getArray();

	// do the multiplication
	for(int i=0; i<_lhsM; i++) {
	    boolean[] a=lA[i];
	    boolean[] c=yA[i];
	    for(int j=0; j<_rhsN; j++) {
		boolean sum=false;		
		for(int k=0; k<_lhsN; k++) sum |= a[k] && rA[k][j];
		c[j] = sum;
	    }
	}
	
	// and pass it back:
	return _rhsIsRankOneArray?y.apply(Basic.CONCATENATE):y;
    }
    
    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Byte1d.
     */
    public ArrayData of(Byte1d lhs) {
	return to2d(lhs).apply(this).apply(Basic.CONCATENATE);
    }

    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Byte2d.
     */
    public ArrayData of(Byte2d lhs) {
	validate(lhs);
	Byte2d rhs=(Byte2d)_rhs;

	// create the resulting array and some short-cuts:
	Byte2d y=new Byte2d(_lhsM,_rhsN);
	final byte[][] rA=rhs.getArray();
	final byte[][] lA=lhs.getArray();
	final byte[][] yA=y.getArray();

	// do the multiplication
	for(int i=0; i<_lhsM; i++) {
	    byte[] a=lA[i];
	    byte[] c=yA[i];
	    for(int j=0; j<_rhsN; j++) {
		byte sum=0;
		for(int k=0; k<_lhsN; k++) sum += a[k] * rA[k][j];
		c[j] = sum;
	    }
	}
	
	// and pass it back:
	return _rhsIsRankOneArray?y.apply(Basic.CONCATENATE):y;
    }
    
    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Short1d.
     */
    public ArrayData of(Short1d lhs) {
	return to2d(lhs).apply(this).apply(Basic.CONCATENATE);
    }

    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Short2d.
     */
    public ArrayData of(Short2d lhs) {
	validate(lhs);
	Short2d rhs=(Short2d)_rhs;

	// create the resulting array and some short-cuts:
	Short2d y=new Short2d(_lhsM,_rhsN);
	final short[][] rA=rhs.getArray();
	final short[][] lA=lhs.getArray();
	final short[][] yA=y.getArray();

	// do the multiplication
	for(int i=0; i<_lhsM; i++) {
	    short[] a=lA[i];
	    short[] c=yA[i];
	    for(int j=0; j<_rhsN; j++) {
		short sum=0;
		for(int k=0; k<_lhsN; k++) sum += a[k] * rA[k][j];
		c[j] = sum;
	    }
	}
	
	// and pass it back:
	return _rhsIsRankOneArray?y.apply(Basic.CONCATENATE):y;
    }
    
    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Int1d.
     */
    public ArrayData of(Int1d lhs) {
	return to2d(lhs).apply(this).apply(Basic.CONCATENATE);
    }

    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Int2d.
     */
    public ArrayData of(Int2d lhs) {
	validate(lhs);
	Int2d rhs=(Int2d)_rhs;

	// create the resulting array and some short-cuts:
	Int2d y=new Int2d(_lhsM,_rhsN);
	final int[][] rA=rhs.getArray();
	final int[][] lA=lhs.getArray();
	final int[][] yA=y.getArray();

	// do the multiplication
	for(int i=0; i<_lhsM; i++) {
	    int[] a=lA[i];
	    int[] c=yA[i];
	    for(int j=0; j<_rhsN; j++) {
		int sum=0;
		for(int k=0; k<_lhsN; k++) sum += a[k] * rA[k][j];
		c[j] = sum;
	    }
	}
	
	// and pass it back:
	return _rhsIsRankOneArray?y.apply(Basic.CONCATENATE):y;
    }
    
    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Long1d.
     */
    public ArrayData of(Long1d lhs) {
	return to2d(lhs).apply(this).apply(Basic.CONCATENATE);
    }

    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Long2d.
     */
    public ArrayData of(Long2d lhs) {
	validate(lhs);
	Long2d rhs=(Long2d)_rhs;

	// create the resulting array and some short-cuts:
	Long2d y=new Long2d(_lhsM,_rhsN);
	final long[][] rA=rhs.getArray();
	final long[][] lA=lhs.getArray();
	final long[][] yA=y.getArray();

	// do the multiplication
	for(int i=0; i<_lhsM; i++) {
	    long[] a=lA[i];
	    long[] c=yA[i];
	    for(int j=0; j<_rhsN; j++) {
		long sum=0;
		for(int k=0; k<_lhsN; k++) sum += a[k] * rA[k][j];
		c[j] = sum;
	    }
	}
	
	// and pass it back:
	return _rhsIsRankOneArray?y.apply(Basic.CONCATENATE):y;
    }
    
    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Float1d.
     */
    public ArrayData of(Float1d lhs) {
	return to2d(lhs).apply(this).apply(Basic.CONCATENATE);
    }

    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Float2d.
     */
    public ArrayData of(Float2d lhs) {
	validate(lhs);
	Float2d rhs=(Float2d)_rhs;

	// create the resulting array and some short-cuts:
	Float2d y=new Float2d(_lhsM,_rhsN);
	// do the multiplication
	float alpha=1f;
	float beta=0f;
    

	final float[][] B=rhs.getArray();
	final float[][] A=lhs.getArray();
	float[][] C=y.getArray();
	


	int m=_lhsM;
	int n=_rhsN;
	int l=_lhsN;
	
	   
    // Create a CUBLAS handle
	JCublas.cublasInit();
	// Allocate memory on the device
	Pointer d_B = new Pointer();
	Pointer d_C = new Pointer();
	Pointer d_A = new Pointer();
	JCublas.cublasAlloc(m*l, Sizeof.FLOAT, d_A);
	JCublas.cublasAlloc(l*n, Sizeof.FLOAT, d_B);
	JCublas.cublasAlloc(m*n, Sizeof.FLOAT, d_C);
	
	// Copy the memory from the host to the device
	float AA[]=new float[m*l];
	float BB[]=new float[l*n];
	float CC[]=new float[m*n];
	
	for(int i=0;i<m;i++){
	    for(int j=0;j<l;j++){
			AA[j*m+i]=A[i][j];
	    }
	}
	for(int i=0;i<l;i++){
	    for(int j=0;j<n;j++){
			BB[j*l+i]=B[i][j];
	    }
	}
	for(int i=0;i<m;i++){
	    for(int j=0;j<n;j++){
			CC[j*m+i]=C[i][j];
	    }
	}

	JCublas.cublasSetMatrix(m,l, Sizeof.FLOAT, Pointer.to(AA), m, d_A, m);
	JCublas.cublasSetMatrix(l,n, Sizeof.FLOAT, Pointer.to(BB), l, d_B, l);
	JCublas.cublasSetMatrix(m,n, Sizeof.FLOAT, Pointer.to(CC), m, d_C, m);
	JCublas.cublasSgemm('n', 'n', m, n, l, alpha, d_A, m, d_B, l, beta, d_C, m);

	// Copy the result from the device to the host
	JCublas.cublasGetMatrix(m,n, Sizeof.FLOAT, d_C, m, Pointer.to(CC), m);
 

	// Clean up


    for(int i=0;i<_lhsM;i++){
    	for (int j=0;j<_rhsN;j++){
    		C[i][j]=CC[j*_lhsM+i];
    	}
    }
	
	JCublas.cublasFree(d_A);
	JCublas.cublasFree(d_B);
	JCublas.cublasFree(d_C);
	JCublas.cublasShutdown();
	
	// and pass it back:
	return _rhsIsRankOneArray?y.apply(Basic.CONCATENATE):y;
    }
    
    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Double1d.
     */
    public ArrayData of(Double1d lhs) {
	return to2d(lhs).apply(this).apply(Basic.CONCATENATE);
    }

    /**
     * Computes the matrix multiplication of specified input array with
     * the array passed during construction fo this class.
     * @return an array of type Double2d.
     */
    public ArrayData of(Double2d lhs) {
	validate(lhs);
	Double2d rhs=(Double2d)_rhs;
	
	Double2d y=new Double2d(_lhsM,_rhsN);
	
	// create the resulting array and some short-cuts:
	final double[][] B=rhs.getArray();
	final double[][] A=lhs.getArray();
	double[][] C=y.getArray();
		
	
	int m=_lhsM;
	int n=_rhsN;
	int l=_lhsN;

    // Create a CUBLAS handle
    JCublas.cublasInit();
    // Allocate memory on the device
    Pointer d_A = new Pointer();
    Pointer d_B = new Pointer();
    Pointer d_C = new Pointer();
    JCublas.cublasAlloc(m*l, Sizeof.DOUBLE, d_A);
    JCublas.cublasAlloc(l*n, Sizeof.DOUBLE, d_B);
    JCublas.cublasAlloc(m*n, Sizeof.DOUBLE, d_C);

    // Copy the memory from the host to the device
    double AA[]=new double[m*l];
    double BB[]=new double[l*n];
    double CC[]=new double[m*n];
    

    
    for(int i=0;i<m;i++){
    	for(int j=0;j<l;j++){
    		AA[j*m+i]=A[i][j];
    	}
    }
    for(int i=0;i<l;i++){
    	for(int j=0;j<n;j++){
    		BB[j*l+i]=B[i][j];
    	}
    }
    for(int i=0;i<m;i++){
    	for(int j=0;j<n;j++){
    		//CC[j*m+i]=C[i][j];
    		CC[j*m+i]=11;
    	}
    }
    
    
    
    JCublas.cublasSetMatrix(m,l, Sizeof.DOUBLE, Pointer.to(AA), m, d_A, m);
    JCublas.cublasSetMatrix(l,n, Sizeof.DOUBLE, Pointer.to(BB), l, d_B, l);
    JCublas.cublasSetMatrix(m,n, Sizeof.DOUBLE, Pointer.to(CC), m, d_C, m);

	double alpha=1;
	double beta=0;
    
    
    // Execute sgemm

    JCublas.cublasDgemm('n', 'n', m, n, l, alpha, d_A, m, d_B, l, beta, d_C, m);
    //JCublas.cublasSgemm('n', 'n', m, n, l, alpha, d_A, m, d_B, l, beta, d_C, m);
    // Copy the result from the device to the host
    JCublas.cublasGetMatrix(m,n, Sizeof.DOUBLE, d_C, m, Pointer.to(CC), m);
 

    // Clean up
    
    
    for(int i=0;i<m;i++){
    	for (int j=0;j<n;j++){
    		C[i][j]=CC[j*m+i];
 
    	}
    }
    
    
    JCublas.cublasFree(d_A);
    JCublas.cublasFree(d_B);
    JCublas.cublasFree(d_C);
    JCublas.cublasShutdown(); 
    
	// and pass it back:
	return _rhsIsRankOneArray?y.apply(Basic.CONCATENATE):y;
    }
    

    private ArrayData validate(Array2dData lhs) {
	if (!lhs.getClass().equals(_rhs.getClass()))
	    throw new IllegalArgumentException("Arrays must be of the same type.");
	final int[] d=lhs.getDimensions();
	_lhsM=d[0];
	_lhsN=d[1];
	if (_lhsN!=_rhsM)
	    throw new IndexOutOfBoundsException("Matrix size mismatch.");
	return lhs;
    }

    /**
     * Validates and converts the specified argument into a 2d array.
     */
    private ArrayData to2d(Array1dData lhs) {
	if (_rhsIsRankOneArray)
	    throw new IllegalArgumentException("Cannot matrix-multiply two vectors.");
	return lhs.apply(new Reshape(1,lhs.getSize()));
    }
    
}
