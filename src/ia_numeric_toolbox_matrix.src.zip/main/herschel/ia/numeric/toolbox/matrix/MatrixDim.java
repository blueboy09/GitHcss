package herschel.ia.numeric.toolbox.matrix;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
/**
*
*the class is the base of counter of any specific Double2d operator(methods). 
*@jcategory Arrays and datasets
*
*@author Yifei Jin <m-astro@163.com>,
*
*/
public final class MatrixDim {
	/**
	 * predefine the space allocate to the _Detail array 
	 *  
	 */
	private int _Dim;
	/**
	 * the name for a specific method you care about. 
	 */
	private String _name;
	/**
	 * use to save the detail result.  called times of different data scales. 
	 */
	private long[][] _MatrixDim=null;
	/**
	 * record the used space in the "_MatrixDim" array 
	 */
	private int NUM;
	/**
	 * record the called times of all data scales
	 */
	private long _OptCount;
	
	/**
	 * initial function
	 */
	public void init(){
		_Dim=500;
		setNUM(0);
		set_name("Opt");
		_OptCount=0;
		
	}
	/**
	 * constructor, default the space allocation is 500
	 */
	public  MatrixDim(){
		init();
		set_MatrixDim(new long[4][_Dim]);
		for(int i=0;i<3;i++){
			for(int j=0;j<_Dim;j++){
				get_MatrixDim()[i][j]=0;
			}
		}
	}
	/**
	 * constructor
	 * @param Dim the space allocation
	 */
	public MatrixDim(int Dim) {
		_Dim=Dim;
		set_MatrixDim(new long[4][_Dim]);
		for(int i=0;i<3;i++){
			for(int j=0;j<_Dim;j++){
				get_MatrixDim()[i][j]=0;
			}
		}
	}	
	/**
	 * 
	 * constructor 
	 * @param Dim the space allocation
	 * @param name the name of the method
	 * 
	 */
	public MatrixDim(int Dim,String name) {
		_Dim=Dim;
		set_name(name);
		set_MatrixDim(new long[4][_Dim]);
		for(int i=0;i<3;i++){
			for(int j=0;j<_Dim;j++){
				get_MatrixDim()[i][j]=0;
			}
		}
	}
	
	/**
	 * reset the counter
	 */

	public void Reset(){
		setNUM(0);
		_OptCount=0;
		for(int i=0;i<4;i++){
			for(int j=0;j<_Dim;j++){
				get_MatrixDim()[i][j]=0;
			}
		}
	}
	
	// this part is used for number count
	/**
	 * counter add one
	 */
	public void OptCount(){
		_OptCount=_OptCount+1;
		
	}
	/**
	 * get the result of the counter
	 * @return the Count number
	 */
	public long OptGetValue(){
		return _OptCount;
	}
	
	
	// this part is used for dimension count
	/**
	 * 
	 * search whether the data scale have been called before
	 * @param row the first dimension of the data scale
	 * @param col the second dimension of the data scale 
	 * @return return true if the the data scale in the _Double2dDim array, else false
	 */
	public boolean search(int lhsM, int lhsN, int rhsN){
		boolean flag= false;
		for(int i=0;i<getNUM();i++){
			if(get_MatrixDim()[0][i]==lhsM && get_MatrixDim()[1][i]==lhsN && get_MatrixDim()[2][i]==rhsN){
				flag=true;
				break;
			}
		}
		return flag;
	}
	/**
	 *  this function used when "search" function return false, it means this data kind
	 *  didn't appear before, so we need find a place in the _Detail array 
	 *  to insert the new one.
	 *  note : the _Double2dDim array is descending order by its first dimension.
	 *
	 * @param row the first dimension of the data scale
	 * @param col the second dimension of the data scale
	 */
	public void Calculate(int lhsM, int lhsN, int rhsN){
		int point=0;
		for(int i=0;i<getNUM();i++){
			if(get_MatrixDim()[0][i]==lhsM && get_MatrixDim()[1][i]==lhsN && get_MatrixDim()[2][i]==rhsN){
				point=i;
				break;
			}
		}
		get_MatrixDim()[3][point] = get_MatrixDim()[3][point]+1;
		
	}
	/**
	 * 
	 * find the insert point in the _Double2dDim array
	 * @param row the first dimension of the data scale
	 * @param col the second dimension of the data scale
	 * @return the insert point 
	 */
	public int find(int lhsM, int lhsN, int rhsN){
		int point=0;
		while(get_MatrixDim()[0][point] < lhsM && point < getNUM()){
			point++;
		}
		while(get_MatrixDim()[1][point] < lhsN && point < getNUM()){
			point++;
		}
		while(get_MatrixDim()[2][point] < rhsN && point < getNUM()){
			point++;
		}
		
		return point;
	}
	
	
	/**
	 * insert the new data scale and accumulate one
	 * @param point the insert point 
	 * @param row the first dimension of the data scale 
	 * @param col the second dimension of the data scale 
	 */

	public void insert(int point,int lhsM, int lhsN, int rhsN){
		try {
		 
			if(getNUM() ==_Dim) throw new Exception("space is not enough");
			for(int i=getNUM();i>point;i--){
				for(int j=0;j<4;j++){
					get_MatrixDim()[j][i]=get_MatrixDim()[j][i-1];
				}
			}
			get_MatrixDim()[0][point]=lhsM;
			get_MatrixDim()[1][point]=lhsN;
			get_MatrixDim()[2][point]=rhsN;
			get_MatrixDim()[3][point]=1;
			
			setNUM(getNUM()+1);
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("The recort space is not enough:"+e);
		}
		
	}
	
	
	// output data
	/**
	 * output the result, default path is the current directory 
	 * @throws IOException
	 */
	
	public void Output() throws IOException{		
		Output(get_name(), ".\\");
	}
	/**
	 * output the result
	 * @param name the name of the result file
	 * @param Path the path of the result file
	 * @throws IOException
	 */	
	public void Output(String name,String Path) throws IOException{
	      FileOutputStream fos = null;
	      DataOutputStream dos = null;
	      long[][] dbuf = new long[4][getNUM()];  
		  for(int i=0;i<4;i++){
			  for(int j=0;j<getNUM();j++){
				  dbuf[i][j]=get_MatrixDim()[i][j];
			  }
		  }
				  
	      
		  try{
		     fos = new FileOutputStream(Path+name);
		 // create data output stream
		     dos = new DataOutputStream(fos);
		 
		 // for each byte in the buffer
		 
		     dos.writeInt(getNUM());
		     
		     for(int i=0;i<dbuf.length;i++){
			 
		    	 for (long d:dbuf[i])
		    	 {
			    // write double to the data output stream
		    		 dos.writeLong(d);         
		    	 }
		     }
		 // force bytes to the underlying stream
		     dos.flush();
		     
		     
		  }catch(Exception e){
		  		// if any I/O error occurs
		     e.printStackTrace();
		  }finally{
		     
		     // releases all system resources from the streams
		         if(dos!=null)
		            dos.close();
		         if(fos!=null)
		            fos.close();
		      }
		   }
	
	
	// data input
	/**
	 * 
	 * input the result from disc memory
	 * default file name is the value of "name", default directory is the current path
	 * @return the detail result array
	 * @throws IOException
	 */
	public long[][] Input() throws IOException{
		long[][] dbuf=Input(get_name(),".\\");
		return dbuf;
	}
	
	/**
	 * input the result from disc memory
	 * @param name the file name 
	 * @param Path the file directory
	 * @return the detail result array
	 * @throws IOException
	 */
	public long[][] Input(String name,String Path) throws IOException{
		  InputStream is = null;
		  DataInputStream dis = null;
		  long[][] dbuf=null;
		  try{
		  		     
		 // create file input stream
	         is = new FileInputStream(Path+name);
       // create new data input stream
		     dis = new DataInputStream(is);
       
       // read till end of the stream		   
		     int i=0;		   
		     int j=0;		   
		     int num=dis.readInt();
		     
		     dbuf=new long[4][num];
		     while(dis.available()>0)
		     {
	          // read character
		    	 if(j==num){ 
		    	 i++;
	    		 j=0;
	    	  }
	          dbuf[i][j] = dis.readLong();
	          j++;
		     }

			
	       }catch(Exception e){
			     // if any I/O error occurs
	    	   e.printStackTrace();
	       }finally{
			     // releases all system resources from the streams
			   if(is!=null)
			   is.close();
			   if(dis!=null)
			   dis.close();
			  }
		  return dbuf;

	}
	

	public String toString(){
		return get_name();
		
	}
	public String get_name() {
		return _name;
	}
	public void set_name(String _name) {
		this._name = _name;
	}
	public long[][] get_MatrixDim() {
		return _MatrixDim;
	}
	public void set_MatrixDim(long[][] _MatrixDim) {
		this._MatrixDim = _MatrixDim;
	}
	public int getNUM() {
		return NUM;
	}
	public void setNUM(int num) {
		NUM = num;
	}
	
	
	

}

