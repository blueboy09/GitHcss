package herschel.ia.numeric.toolbox.matrix;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;
import herschel.ia.numeric.*;

/**
 * 
 * @author Yifei Jin <m-astro@163.com>
 *
 */
public class SVDTimeCost {
	/**
	 * Constructor
	 */

	public SVDTimeCost() {
		// TODO Auto-generated constructor stub
	}
	
//--------.---------------------- time cost calculate ---------------------------------
	/**
	 * 
	 * calculate the time cost of the method Ops
	 * @param Ops the operator (method) which we care about
	 * @param Path  the output path of detail result NumCount.class 
	 * @return : time cost of the method 
	 * @throws IOException
	 */
	public double TimeCost(String Ops,String Path) throws IOException{
		long[][] numCount = TcInput(Ops, Path);
		int lhsM,lhsN,nums;
		int row=numCount.length;
		if(row!=3) throw new IllegalArgumentException("the lead dimension unmatched");
		int col=numCount[0].length;
		double AllTime=0;
		for(int i=0;i<col;i++){
				lhsM=(int)(numCount[0][i]);
				lhsN=(int)(numCount[1][i]);
				nums=(int)(numCount[2][i]);
				for(int j=0;j<nums;j++){
					AllTime=AllTime+TimeCal(Ops,lhsM,lhsN);					
				}

		}
		return AllTime;
	}
	
	/**
	 * calculate the time cost of once method called
	 * @param Ops :operator ,the method which we care about
	 * @param len : the dimension of data 
	 * @return: the time used of the data scale of the method 
	 * 
	 */
	public double TimeCal(String Ops,int lhsM,int lhsN){
		double timeused=0;
		double timeBegin=0,timeEnd=0;
		int its=1;
		if(Ops=="SVDF1"){
			for(int i=0;i<its;i++){
				Float2d X = GenerateFloatArray(lhsM,lhsN);
				timeBegin=System.nanoTime();
				SingularValueDecomposition svd= new SingularValueDecomposition(X);
				timeEnd=(double) (System.nanoTime()-timeBegin)/1000000000;
				timeused+=timeEnd;
			}
			
			
		}else if(Ops=="SVDF2"){
			for(int i=0;i<its;i++){
				Float2d X = GenerateFloatArray(lhsM,lhsN);
				timeBegin=System.nanoTime();
				SingularValueDecomposition svd= new SingularValueDecomposition();
				X.apply(svd);
				timeEnd=(double) (System.nanoTime()-timeBegin)/1000000000;
				timeused+=timeEnd;
			}
			
			
		}else if(Ops=="SVDD1"){
			for(int i=0;i<its;i++){
				Double2d X = GenerateDoubleArray(lhsM,lhsN);
				timeBegin=System.nanoTime();
				SingularValueDecomposition svd= new SingularValueDecomposition(X);
				timeEnd=(double) (System.nanoTime()-timeBegin)/1000000000;
				timeused+=timeEnd;
				
			}
			
		}else if(Ops=="SVDD2"){
			for(int i=0;i<its;i++){
				Double2d X = GenerateDoubleArray(lhsM,lhsN);
				timeBegin=System.nanoTime();
				SingularValueDecomposition svd= new SingularValueDecomposition();
				X.apply(svd);
				timeEnd=(double) (System.nanoTime()-timeBegin)/1000000000;
				timeused+=timeEnd;
			}
		}else{
			timeEnd=-1;
			throw new IllegalArgumentException("these kind of operation is not exsit");
		}
		return (timeused/its);
	}
	
//-------------------------------input the data from number count file ---------------	
	
	
	/**
	 * 
	 * Input the called times of the method
	 * @param name the name of the operator/method/function 
	 * @param Path : the path of input result
	 * @return
	 * @throws IOException
	 */
	public long[][] TcInput (String name, String Path) throws IOException{
		  InputStream is = null;
		  DataInputStream dis = null;
		  long[][] dbuf=null ;
		  try{
			  is = new FileInputStream(Path+name);
			  dis = new DataInputStream(is);
	  	      int i=0;		   
		      int j=0;		   
		      int num=dis.readInt();
		     
		      dbuf=new long[3][num];
		      while(dis.available()>0)
		      {
		    	 if(j==num){ 
		    	 i++;
	    		 j=0;
	    	  }
	          dbuf[i][j] = dis.readLong();
	          j++;
		     }   
		  }catch(Exception e){     
			  e.printStackTrace();
		  }finally{
			  if(is!=null)
				  is.close();
			  if(dis!=null)	
			  	dis.close();
		  }
		return dbuf;
	}
// ---------------------------------------- Generate Array ------------------------
	/**
	 * generate the random Double2d data 
	 * @param lhsM the first dimension of the data
	 * @param lhsN the second dimension of the data
	 * @return the random generate array
	 */
	public Double2d GenerateDoubleArray(int lhsM, int lhsN){
		Random rdm =new Random();
		double[][] CalArray= new double[lhsM][lhsN];
		for(int i=0;i<lhsM;i++){
			for (int j=0;j<lhsN;j++){
				CalArray[i][j]=10*rdm.nextDouble();
			}
		}
		Double2d Array =new Double2d(CalArray);
		return Array;
	}
	
	/**
	 * generate the random Float2d data 
	 * @param lhsM the first dimension of the data
	 * @param lhsN the second dimension of the data 
	 * @return the random generate array
	 */
	public Float2d GenerateFloatArray(int lhsM, int lhsN){
		Random rdm =new Random();
		float[][] CalArray= new float[lhsM][lhsN];
		for(int i=0;i<lhsM;i++){
			for (int j=0;j<lhsN;j++){
				CalArray[i][j]=10*rdm.nextFloat();
			}
		}
		Float2d Array = new Float2d(CalArray);
		return Array;
	}

	
	
	
}
