/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * EigenvalueDecompositionTest.java
 * JUnit based test
 * @author Jeff Jacobson (jdj@ipac.caltech.edu)
 */

package herschel.ia.numeric.toolbox.matrix.test;

import junit.framework.*;
import herschel.ia.numeric.toolbox.matrix.EigenvalueDecomposition;
import herschel.ia.numeric.toolbox.matrix.NonConvergenceException;
import herschel.ia.numeric.Double1d;
import herschel.ia.numeric.Double2d;
import herschel.ia.numeric.Float2d;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 *
 * @author jdj
 */
public class EigenvalueDecompositionTest extends TestCase {
    
    private static int maxIterations = 1;  // Force timeout handling.

    public EigenvalueDecompositionTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }

    /* AllTests uses this to access the EigenvalueDecompositionTest class. */
    public static Test suite() {
      return new TestSuite(EigenvalueDecompositionTest.class);
    }

    /**
     * Test symetric matrix.
     */
    public void testDouble2dConstructor() throws Exception {
      double[][] pvals = {{1.,1.,1.},{1.,2.,3.},{1.,3.,6.}};
      Double2d A = new Double2d (pvals);

      EigenvalueDecomposition Eig = new EigenvalueDecomposition (A);
      Double2d D = Eig.getD();
      Double2d V = Eig.getV();
      double c = Eig.getVcond();
      Double1d I = Eig.getImagEigenvalues();
      Double1d R = Eig.getRealEigenvalues();
      
      //System.out.println ("A = " + A);
      //System.out.println ("D = " + D);
      //System.out.println ("V = " + V);
      //System.out.println ("I = " + I);
      //System.out.println ("R = " + R);
      //System.out.print ("D = " + D);
      //System.out.print ("V = " + V);
      check(c,I,R);
      check(times(A,V),times(V,D));
    }
    /**
     * Test symetric matrix.
     */
    public void testSymmetricDouble() {
      double[][] pvals = {{1.,1.,1.},{1.,2.,3.},{1.,3.,6.}};
      Double2d A = new Double2d (pvals);

      //EigenvalueDecomposition Eig = new EigenvalueDecomposition (A);
      EigenvalueDecomposition Eig = (EigenvalueDecomposition) A.apply(new EigenvalueDecomposition());
      Double2d D = Eig.getD();
      Double2d V = Eig.getV();
      double c = Eig.getVcond();
      Double1d I = Eig.getImagEigenvalues();
      Double1d R = Eig.getRealEigenvalues();
      
      //System.out.print ("D = " + D);
      //System.out.print ("V = " + V);
      check(c,I,R);
      check(times(A,V),times(V,D));

    }

    /**
     * Test nonsymetric matrix.
     */
    public void testNonSymmetricDouble() {
      double[][] evals =
         {{0.,1.,0.,0.},{1.,0.,2.e-7,0.},{0.,-2.e-7,0.,1.},{0.,0.,1.,0.}};
      Double2d A = new Double2d (evals);

      EigenvalueDecomposition Eig = (EigenvalueDecomposition) A.apply(new EigenvalueDecomposition());
      Double2d D = Eig.getD();
      Double2d V = Eig.getV();
      double c = Eig.getVcond();
      Double1d I = Eig.getImagEigenvalues();
      Double1d R = Eig.getRealEigenvalues();
      
      check(c,I,R);
      check(times(A,V),times(V,D));
   }

    /**
     * Test symetric matrix.
     */
    public void testSymmetricFloat() {
      float[][] pvals = {{4.f,1.f,1.f},{1.f,2.f,3.f},{1.f,3.f,6.f}};
      Float2d A = new Float2d (pvals);
      double[][] pvals2 = {{4.,1.,1.},{1.,2.,3.},{1.,3.,6.}};
      Double2d A2 = new Double2d (pvals2);

      //EigenvalueDecomposition Eig = new EigenvalueDecomposition (A);
      EigenvalueDecomposition Eig = (EigenvalueDecomposition) A.apply(new EigenvalueDecomposition());
      Double2d D = Eig.getD();
      Double2d V = Eig.getV();
      double c = Eig.getVcond();
      Double1d I = Eig.getImagEigenvalues();
      Double1d R = Eig.getRealEigenvalues();
      
      //System.out.print ("D = " + D);
      //System.out.print ("V = " + V);
      check(c,I,R);
      check(times(A2,V),times(V,D));
    }

    /**
     * Test nonsymetric matrix.
     */
    public void testNonSymmetricFloat() {
      float[][] evals =
         {{0.f,1.f,0.f,0.f},{1.f,0.f,2.e-7f,0.f},{0.f,-2.e-7f,0.f,1.f},{0.f,0.f,1.f,0.f}};
      Float2d A = new Float2d (evals);
      double[][] evals2 =
         {{0.,1.,0.,0.},{1.,0.,2.e-7,0.},{0.,-2.e-7,0.,1.},{0.,0.,1.,0.}};
      Double2d A2 = new Double2d (evals2);

      EigenvalueDecomposition Eig = (EigenvalueDecomposition) A.apply(new EigenvalueDecomposition());
      Double2d D = Eig.getD();
      Double2d V = Eig.getV();
      double c = Eig.getVcond();
      Double1d I = Eig.getImagEigenvalues();
      Double1d R = Eig.getRealEigenvalues();
      check(c,I,R);
      check(times(A2,V),times(V,D));
   }

    /**
     * Test symetric matrix non-converging.
     */
    public void testDouble2dConstructorNonConverging() {
      try {
         double[][] pvals = {{4.,1.,1.},{1.,2.,3.},{1.,3.,6.}};
         Double2d A = new Double2d (pvals);

         EigenvalueDecomposition Eig = new EigenvalueDecomposition (A,maxIterations);
      } catch (NonConvergenceException e ) {
         return;  // OK
      }
      throw new RuntimeException ("Failed to raise NonConvergenceException");

    }
    /**
     * Test symetric matrix non-converging.
     */
    public void testSymmetricDoubleNonConverging() {
      try {
      double[][] pvals = {{4.,1.,1.},{1.,2.,3.},{1.,3.,6.}};
      Double2d A = new Double2d (pvals);

      //EigenvalueDecomposition Eig = new EigenvalueDecomposition (A);
      EigenvalueDecomposition Eig = (EigenvalueDecomposition) A.apply(new EigenvalueDecomposition(maxIterations));
      } catch (NonConvergenceException e ) {
         return;  // OK
      }
      throw new RuntimeException ("Failed to raise NonConvergenceException");
      
    }

    /**
     * Test nonsymetric matrix non-converging.
     */
    public void testNonSymmetricDoubleNonConverging() {
      try {
         double[][] evals =
         {{0.,1.,0.,0.},{1.,0.,2.e-7,0.},{0.,-2.e-7,0.,1.},{0.,0.,1.,0.}};
         Double2d A = new Double2d (evals);

         EigenvalueDecomposition Eig = (EigenvalueDecomposition) A.apply(new EigenvalueDecomposition(maxIterations));
      } catch (NonConvergenceException e ) {
         return;  // OK
      }
      throw new RuntimeException ("Failed to raise NonConvergenceException");
   }

   /** Check norm of difference of Matrices. **/

   //private static void check(Matrix X, Matrix Y) {
   private static void check(Double2d X, Double2d Y) {
      double eps = Math.pow(2.0,-52.0);
      if (norm1(X) == 0. & norm1(Y) < 10*eps) return;
      if (norm1(Y) == 0. & norm1(X) < 10*eps) return;
      //System.out.println ("\nnorm1(X) = " + norm1(X));
      //System.out.println ("norm1(Y) = " + norm1(Y));
      //System.out.println ("eps = " + eps);
      //System.out.println ("1000 * eps * max(norm1(X), norm1(Y)) = " + 10*eps*Math.max(norm1(X),norm1(Y)));
      //System.out.println ("X.copy().subtract(Y)) = " + X.copy().subtract(Y));
      if (norm1(X.copy().subtract(Y)) > 
          1000*eps*Math.max(norm1(X),norm1(Y))) {
         throw new RuntimeException("The norm of (X-Y) is too large: " 
            +  Double.toString(norm1(X.copy().subtract(Y))));
      }
    }

   /** Check that vCond > 0 and both imaginary and real parts are returned. **/
   private void check(double c, Double1d i, Double1d r) {
	   if (c <= 0.0) {
	       throw new RuntimeException ("Vcond <= 0.0, found " + c + ".");
   	}
   	if (i == null) {
   	    throw new RuntimeException ("No imaginary values.");
   	}
   	if (r == null) {
   	    throw new RuntimeException ("No real values");
   	}
   }

   private static double norm1 (Double2d A) {
      int dim[] = A.getDimensions ();
      int m = dim[0];
      int n = dim[1];
      double f = 0.;
      for (int j = 0; j < n; j++) {
         double s = 0;
         for (int i = 0; i < m; i++) {
            s += Math.abs(A.get(i,j));
         }
         f = Math.max(f,s);
      }
      return f;
   }

   /** Linear algebraic matrix multiplication, A * B
   @param B    another matrix
   @return     Matrix product, A * B
   @exception  IllegalArgumentException Matrix inner dimensions must agree.
   JJ's note:  Should use Matrix.Multiply, but that needs test harness.
   */
   private Double2d times (Double2d A, Double2d B) {
      int Am = A.getDimensions()[0];
      int An = A.getDimensions()[1];
      int Bm = B.getDimensions()[0];
      int Bn = B.getDimensions()[1];

      if (Bm != An) {
         throw new IllegalArgumentException("Matrix inner dimensions must agree.");
      }
      //Double2d X = new Double2d(Am,Bn);
      //double[][] C = X.getArray();
      double [][] C = new double[Am][Bn];
      double[] Bcolj = new double[An];
      for (int j = 0; j < Bn; j++) {
         for (int k = 0; k < An; k++) {
            //Bcolj[k] = B.A[k][j];
            Bcolj[k] = B.get(k,j);
         }
         for (int i = 0; i < Am; i++) {
            //double[] Arowi = A[i];
            double[] Arowi = A.get(i).toArray();
            double s = 0;
            for (int k = 0; k < An; k++) {
               s += Arowi[k]*Bcolj[k];
            }
            C[i][j] = s;
         }
      }
      return new Double2d(C);
   }

}
