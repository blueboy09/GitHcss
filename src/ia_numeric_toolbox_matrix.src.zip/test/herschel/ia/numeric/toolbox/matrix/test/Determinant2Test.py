# 
#  This file is part of Herschel Common Science System (HCSS).
#  Copyright 2001-2010 Herschel Science Ground Segment Consortium
# 
#  HCSS is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as
#  published by the Free Software Foundation, either version 3 of
#  the License, or (at your option) any later version.
# 
#  HCSS is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU Lesser General Public License for more details.
# 
#  You should have received a copy of the GNU Lesser General
#  Public License along with HCSS.
#  If not, see <http://www.gnu.org/licenses/>.
# 
#  -*-jython-*-   This is an automatically generated file.
#                  It will be created from a template.
#                         Do Not Edit!
# 
#  Copyright (c) 2003-2004 Jorgo Bakker and Jon Brumfitt
#  Template file "template/Determinant2Test.tpl"
# 
"""
Test harness of DETERMINANT
"""

from java.util.logging import *
from herschel.ia.numeric.toolbox.basic import *
from herschel.ia.numeric import *
from herschel.ia.numeric import AbstractArrayData
from herschel.ia.numeric import BooleanArray
from herschel.ia.numeric import ByteArray
from herschel.ia.numeric import ShortArray
from herschel.ia.numeric import IntegerArray
from herschel.ia.numeric import LongArray
from herschel.ia.numeric import FloatArray
from herschel.ia.numeric import DoubleArray
from herschel.ia.numeric import ComplexArray
from herschel.ia.numeric import StringArray
from herschel.ia.numeric.toolbox.matrix import *

import unittest
from org.python.core import PyList
from java.lang import Boolean,Byte,Short,Integer,Long,Float,Double, String
from java.lang import UnsupportedOperationException

class DETERMINANT2Test(unittest.TestCase):

  # dimSize is the number of elements in each dimension
  dimSize=2

  # maxDim is the maximun number of dimensions of an Array
  maxDim=5

  types = ['Bool', 'Byte', 'Short', 'Int', 'Long', 'Float', 'Double', 'Complex', 'String']

  # test arrays for the following shapes
  shapes= None

  supported = Int2d(maxDim, len(types), 0)
  result = 0
  #----------------------------------------------------------------------------
  # TestCase behavior
  #----------------------------------------------------------------------------
  def __init__(self,methodName='runTest'):
    unittest.TestCase.__init__(self,methodName)
    self.initialize()
    # test arrays for the following shapes
    d = self.dimSize
    self.shapes= [[d],
                  [d,d],
                  [d,d,d],
                  [d,d,d,d],
                  [d,d,d,d,d]]
    return

  def setUp(self):
    return

  def tearDown(self):
    return

  #----------------------------------------------------------------------------
  # Test for String1d
  #----------------------------------------------------------------------------
  def testString1d(self):
    self.doTest('String', 1)
    return

  #----------------------------------------------------------------------------
  # Tests for Numeric Integral Arrays of type Bool[12345]d
  #----------------------------------------------------------------------------
  def testBool1d(self):
    self.doTest('Bool',1)  
    return
  
  def testBool2d(self):
    self.doTest('Bool',2)
    return
  
  def testBool3d(self):
    self.doTest('Bool',3)
    return
  
  def testBool4d(self):
    self.doTest('Bool',4)
    return
  
  def testBool5d(self):
    self.doTest('Bool',5)
    return
  
  #----------------------------------------------------------------------------
  # Tests for Numeric Integral Arrays of type Byte[12345]d
  #----------------------------------------------------------------------------
  def testByte1d(self):
    self.doTest('Byte',1)  
    return
  
  def testByte2d(self):
    self.doTest('Byte',2)
    return
  
  def testByte3d(self):
    self.doTest('Byte',3)
    return
  
  def testByte4d(self):
    self.doTest('Byte',4)
    return
  
  def testByte5d(self):
    self.doTest('Byte',5)
    return
  
  #----------------------------------------------------------------------------
  # Tests for Numeric Integral Arrays of type Short[12345]d
  #----------------------------------------------------------------------------
  def testShort1d(self):
    self.doTest('Short',1)  
    return
  
  def testShort2d(self):
    self.doTest('Short',2)
    return
  
  def testShort3d(self):
    self.doTest('Short',3)
    return
  
  def testShort4d(self):
    self.doTest('Short',4)
    return
  
  def testShort5d(self):
    self.doTest('Short',5)
    return
  
  #----------------------------------------------------------------------------
  # Tests for Numeric Integral Arrays of type Int[12345]d
  #----------------------------------------------------------------------------
  def testInt1d(self):
    self.doTest('Int',1)  
    return
  
  def testInt2d(self):
    self.doTest('Int',2)
    return
  
  def testInt3d(self):
    self.doTest('Int',3)
    return
  
  def testInt4d(self):
    self.doTest('Int',4)
    return
  
  def testInt5d(self):
    self.doTest('Int',5)
    return
  
  #----------------------------------------------------------------------------
  # Tests for Numeric Integral Arrays of type Long[12345]d
  #----------------------------------------------------------------------------
  def testLong1d(self):
    self.doTest('Long',1)  
    return
  
  def testLong2d(self):
    self.doTest('Long',2)
    return
  
  def testLong3d(self):
    self.doTest('Long',3)
    return
  
  def testLong4d(self):
    self.doTest('Long',4)
    return
  
  def testLong5d(self):
    self.doTest('Long',5)
    return
  
  #----------------------------------------------------------------------------
  # Tests for Numeric Integral Arrays of type Float[12345]d
  #----------------------------------------------------------------------------
  def testFloat1d(self):
    self.doTest('Float',1)  
    return
  
  def testFloat2d(self):
    self.doTest('Float',2)
    return
  
  def testFloat3d(self):
    self.doTest('Float',3)
    return
  
  def testFloat4d(self):
    self.doTest('Float',4)
    return
  
  def testFloat5d(self):
    self.doTest('Float',5)
    return
  
  #----------------------------------------------------------------------------
  # Tests for Numeric Integral Arrays of type Double[12345]d
  #----------------------------------------------------------------------------
  def testDouble1d(self):
    self.doTest('Double',1)  
    return
  
  def testDouble2d(self):
    self.doTest('Double',2)
    return
  
  def testDouble3d(self):
    self.doTest('Double',3)
    return
  
  def testDouble4d(self):
    self.doTest('Double',4)
    return
  
  def testDouble5d(self):
    self.doTest('Double',5)
    return
  
  #----------------------------------------------------------------------------
  # Tests for Numeric Integral Arrays of type Complex[12345]d
  #----------------------------------------------------------------------------
  def testComplex1d(self):
    self.doTest('Complex',1)  
    return
  
  def testComplex2d(self):
    self.doTest('Complex',2)
    return
  
  def testComplex3d(self):
    self.doTest('Complex',3)
    return
  
  def testComplex4d(self):
    self.doTest('Complex',4)
    return
  
  def testComplex5d(self):
    self.doTest('Complex',5)
    return
  

  #----------------------------------------------------------------------------
  # PRIVATE "NON-TEST" METHODS
  #----------------------------------------------------------------------------

  # executes algorithm for given type and rank and expect proper answers
  def doTest(self,type,rank):
    x=self.populate(type,rank)
    passed = self.doRun(x)
    self.checkSupported(passed, type, rank, x)
    if (passed):
      y=self.expectedResult(type, rank, x)
      self.checkResult(type, rank, self.result, y)

  # runs y=OPERATION(x) and return if it passes
  # To Be implemented
  def doRun(self,x):
    try:
      self.result=self.doOperation(x)
      passed=1
    except UnsupportedOperationException, e:
      passed=0
    return passed

  # check if the operation was suported and it passed accordingly.
  def checkSupported(self,passed, sType, rank, x):
    isSupported = self.supported[rank-1, self.types.index(sType)]
    self.failIf(passed!=isSupported,"Operation support check fail on class %s.\n"%x.__class__+str(self.supported)+"\npassed: "+str(passed)+" isSupported: "+str(isSupported))

  # check the results
  def checkResult(self, sType, rank, result, expectedResult):
    if isinstance(result, AbstractArrayData):
      self.failIf(result.__class__ != expectedResult.__class__, "Result type check failed on class "+sType+str(rank)+"d:\nResult class was:\n"+str(result.__class__)+"\nExpected class was:\n"+str(expectedResult.__class__)+"\n")
      if (isinstance(result, FloatArray)):
        epsilon = 1e-7
        areEquals = ALL(ABS(result-expectedResult) < epsilon)
      if (isinstance(result, DoubleArray)):
        epsilon = 1e-10
        areEquals = ALL(ABS(result-expectedResult) < epsilon)
      else:
        areEquals = result.equals(expectedResult)
    else:
      if (IS_NAN(result) | IS_NAN(expectedResult)):
        # Obviously two NaN are never equal but here we want
        # to test that the OPERATION and test harness result were
        # the same
        areEquals = (IS_NAN(result) & IS_NAN(expectedResult))
      else:
        areEquals = (result == expectedResult)
    self.failUnless(areEquals, "Result check failed on class "+sType+str(rank)+"d:\nResult was:\n"+str(result)+"\nExpected was:\n"+str(expectedResult)+"\n")

  # check the results
  def genericReshape(self, array, rank):
    if rank>1:
      array=RESHAPE(array, self.shapes[rank-1])
    return array


  def initialize(self):
    # only rank 2 arrays are supported
    self.supported[1,self.types.index('Byte'):self.types.index('Double')+1] = 1
    # set dimSize to 3 instead of the default value.
    self.dimSize = 3
    return

  # fetch pre-defined results for specified type. if specific results exist
  # for specified rank, repot that specific result.
  def expectedResult(self,sType,rank, array):
    supposedResult = -27.0
    return supposedResult

  # returns an array of specified type and rank, populated with unique values
  # e.g. self.populate('Int',3) --> returns an Int3d.
  def populate(self,sType,rank):
    array_aux = SHIFT(Int1d(range(self.dimSize**rank)),1,0)
    # perform conversion and reshape  from Double1d or Complex1d to the proper Array type
    exec ("array = "+sType+"1d(array_aux)")
    array=self.genericReshape(array, rank)
    return array

  def doOperation(self,x):
    return DETERMINANT(x)

  pass # class


if __name__ == '__main__':
  p=PRODUCTTest("testInt1d")
  p.doRun(Int1d([1,2]))
  #unittest.main()

