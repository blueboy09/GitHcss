/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: AllTests.java,v 1.5 2010/02/02 10:23:37 hsclib Exp $
 *
 * Copyright (c) 2004 Jorgo Bakker <jbakker@rssd.esa.int>
 */
package herschel.ia.numeric.toolbox.matrix;

import junit.framework.*;
import junit.textui.TestRunner;

/**
 * Test suite for this toolbox.
 * @author Jorgo Bakker <jbakker@rssd.esa.int>
 */
public class AllTests {

    public static Test suite( ) {
        TestSuite suite = new TestSuite("All tests");

	// no actual tests defined yet!
        suite.addTest(herschel.ia.numeric.toolbox.matrix.test.AllTests.suite());
        return suite;
    }

    /** Allows you to run all tests as an application */
    public static void main(String[] arguments ) {
        TestRunner.run(suite());
    }
}
