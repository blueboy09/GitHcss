# 
#  This file is part of Herschel Common Science System (HCSS).
#  Copyright 2001-2010 Herschel Science Ground Segment Consortium
# 
#  HCSS is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as
#  published by the Free Software Foundation, either version 3 of
#  the License, or (at your option) any later version.
# 
#  HCSS is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU Lesser General Public License for more details.
# 
#  You should have received a copy of the GNU Lesser General
#  Public License along with HCSS.
#  If not, see <http://www.gnu.org/licenses/>.
# 
"""	 
         $Id: HammingFTDataTest.py,v 1.2 2010/02/02 10:24:01 hsclib Exp $

         Copyright (c) 2008 Blue Sky Spectroscopy,
                     www.blueskyinc.ca
                     Lethbridge, Alberta, Canada.



              Jython Test Harness of Hamming.java - Expected FT data comparisons  (see SPR-3173)

Summary:
These tests show that the output of the Hamming class is essentially the same as that of IDL's Hamming function. 
It is in response to Software Problem Report 3173.   The data is shown to be the same for 19 and 20 element arrays.

Algorithm:
1)Read in IDL's calculations of the FT of the amplitude normalized Hamming function.
2)Calculate the FT of the amplitude normalized Hamming function in Jython using HAMMING.AMPLITUDE and FFT_PACK
3)Compare the results of IDL and Jython. Fail if they differ too much.

Tests:
 1.  Tests that the FT of a 19 element amplitude normalized Hamming function is essentially the same as in IDL.
 2.  Tests that the FT of a 20 element amplitude normalized Hamming function is essentially the same as in IDL.

History:
  07 Mar 2008 (PK): Created
  18 Mar 2009 (PK): Recalculated IDL data
"""
import unittest
from herschel.ia.numeric import *
from herschel.ia.numeric.toolbox.basic import *
from herschel.ia.numeric.toolbox.xform import *

class HammingFTDataTest(unittest.TestCase):
	def setUp(self):
		# Permitted difference between expected and actual values
		self.epsilon = 1e-13
		
		#start dictionary to hold results from IDL
		self.idlResults = {}
		# Read in IDL results for Hamming function applied to 19 element array of 1's
		self.idlResults[(19, "Hamming")] = Complex1d([(0.54+0j),(-0.23+0j),0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,(-0.23+0j)])
		# Read in IDL results for Hamming function applied to 20 element array of 1's
		self.idlResults[(20, "Hamming")] = Complex1d([(0.54+0j),(-0.23+0j),0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,0j,(-0.23+0j)])
		
	#Tests that the FT of a 19 element amplitude normalized Hamming function is essentially the same as in IDL.
	def testHammingIDLFTLength19(self):
		arrayLength = 19
		#Check FFT spectrum of Hamming test data with IDL results
		self.checkIdlFtData(arrayLength)
	
	#Tests that the FT of a 20 element amplitude normalized Hamming function is essentially the same as in IDL.	
	def testHammingIDLFTLength20(self):
		arrayLength = 20
		#Check FFT spectrum of Hamming test data with IDL results
		self.checkIdlFtData(arrayLength)
		
	# Asserts that two arrays are almost equal to the specified number of decimal places
	#
	# firstArray - the first array to compare 
	# secondArray - the second array to compare 
	# epsilon - the maximum absolute difference between an actual and expected value permitted for the check to pass
	# failMessage - the message to display with the assertion if the test fails
	def checkArrayAlmostEqual(self, firstArray, secondArray, epsilon, failMessage):
		#Make sure the arrays are the same length
		self.assertEqual(len(firstArray), len(secondArray), failMessage)
		#Make sure the arrays contain similar elements
		for element in range(0, len(firstArray)):
			#get difference between arrays
			difference = ABS(firstArray[element] - secondArray[element])
			self.failUnless( difference < epsilon, failMessage)
			
	# Checks whether the output of the FT(Hamming(array of 1's)) is equal to the 
	# equivalent IDL results.
	#
 	# The FT in IDL needs be scaled by the number of elements in the input vector.
	#
	# arrayLength - the length of array to get results for
	def checkIdlFtData(self, arrayLength):
		#create array of 1's
		input = Double1d(arrayLength)+ 1.0
		#apply Hamming function to array
		hammingArray = HAMMING.AMPLITUDE(input)
		#take FT using FT package specified by fftType
		spectrum = FFT_PACK(Complex1d(hammingArray.copy()))
		# Divide Jython spectrum to scale to IDL's spectrum
		spectrum = spectrum / arrayLength
		#Get results of application of FT of Hamming function to array of 1's in IDL
		expectedIdl = self.idlResults[(arrayLength,"Hamming")]
		
		#check that the real part of spectrum output is as expected
		failMessage = "Real part of spectrum not as expected given input " + str(arrayLength)+" element array."
		#Check that expected real portion of FT is close to the actual
		self.checkArrayAlmostEqual(expectedIdl.getReal(), spectrum.getReal(), self.epsilon, failMessage)
		#check that the imaginary part of spectrum output is as expected
		failMessage = "Imaginary part of spectrum output not as expected given input " + str(arrayLength)+" element array."
		#check that the expected imaginary portion of FT is close to the actual
		self.checkArrayAlmostEqual(expectedIdl.getImag(), spectrum.getImag(), self.epsilon, failMessage)

# Run this module as an independent test
if __name__ == '__main__':
	suite = unittest.makeSuite(HammingFTDataTest)
	unittest.TextTestRunner().run(suite)
