# 
#  This file is part of Herschel Common Science System (HCSS).
#  Copyright 2001-2010 Herschel Science Ground Segment Consortium
# 
#  HCSS is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as
#  published by the Free Software Foundation, either version 3 of
#  the License, or (at your option) any later version.
# 
#  HCSS is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU Lesser General Public License for more details.
# 
#  You should have received a copy of the GNU Lesser General
#  Public License along with HCSS.
#  If not, see <http://www.gnu.org/licenses/>.
# 
"""	 
         $Id: HammingTest.py,v 1.2 2010/02/02 10:24:01 hsclib Exp $

         Copyright (c) 2008 Blue Sky Spectroscopy,
                     www.blueskyinc.ca
                     Lethbridge, Alberta, Canada.
"""
#
#                                  Jython Test Harness of Hamming.java
#
# Tests:
# A) Hamming AREA normalization tests
#   1) Tests whether the Hamming function with AREA normalization applied to a short array of 1's 
#      results in an output array whose values sum up to the length of the array. Tests for four consecutive array lengths.
#   2) Tests whether the Hamming function with AREA normalization applied to a long array of 1's 
#      results in an output array whose values sum up to the length of the array. Tests for four consecutive array lengths.
#   3) Tests whether the Hamming function with AREA normalization applied to an array of 2's 
#      results in an output array whose values sum up to the length of the array times 2. Tests for four consecutive array lengths.
#   
# B) Hamming AMPLITUDE normalization tests
#   1) Tests whether the Hamming function with AMPLITUDE normalization applied to a short array
#      of 1's results in an output array that has a maximum value of 1.   For odd length arrays, tests
#      that there are two maxima that have the value of  expectedMax = (0.54 + 0.46*Math.cos(Math.PI/arraySize))*arrayValue.
#      Tests for four consecutive array lengths.
#   2) Tests whether the Hamming function with AMPLITUDE normalization applied to a long array
#      of 1's results in an output array that has a maximum value of 1.   For odd length arrays, tests
#      that there are two maxima that have the value of  expectedMax = (0.54 + 0.46*Math.cos(Math.PI/arraySize))*arrayValue.
#      Tests for four consecutive array lengths.
#   3)  Tests whether the Hamming function with AMPLITUDE normalization applied to a short array
#      of 2's results in an output array that has a maximum value of 2.   For odd length arrays, tests
#      that there are two maxima that have the value of  expectedMax = (0.54 + 0.46*Math.cos(Math.PI/arraySize))*arrayValue.
#      Tests for four consecutive array lengths.
#
# C) Hamming ENERGY normalization tests
#   1) Tests whether the Hamming function with ENERGY normalization applied to an array
#      of 1's results in an output array for which the sum of its squares is 1. Tests for four consecutive array lengths.
#   2) Tests whether the Hamming function with ENERGY normalization applied to an  array
#      of 1's results in an output array for which the sum of its squares is 1. Tests for four consecutive array lengths.
#   3) Tests whether the Hamming function with ENERGY normalization applied to an array
#      of 2's results in an output array whose sum of squares is 4.    Tests for four consecutive array length.
#
# D) Legacy Hamming Normalization tests
#   1) Tests that when the Hamming function is applied using Hamming.PROCEDURE the 
#   result has AREA normalization.  This is tested by applying the Hamming function to an array of 1's
#   and checking that the output array has values that sum up to the length of the array.
#
# E) Alias Tests
#   1) Tests whether the HAMMING alias provides area normalization.
#   2) Tests whether HAMMING.AMPLITUDE provides amplitude normalization.
#   3) Tests whether HAMMING.ENERGY provides energy normalization
#
# History:
# 07 Mar 2008 (PK): Created
#
import unittest
from java.lang import Math
from herschel.ia.numeric import Double1d
from herschel.ia.numeric.toolbox.basic import * # load ABS alias
from herschel.ia.numeric.toolbox.xform import * #load in HAMMING alias
from herschel.ia.numeric.toolbox.xform import Hamming

class HammingTest(unittest.TestCase):

	def setUp(self):
		self.epsilon = 1e-13
	
	#######################
	## AREA normalization #
	#######################
	
	# Tests whether the Hamming function with AREA normalization applied to a short array of 1's 
	# results in an output array whose values sum up to the length of the array. Tests for four consecutive array lengths.
	def testAreaNormalizationShortArrayLength(self):
		for arraySize in range(2000, 2004):
			self.checkAreaNormalization(arraySize, 1.0)
	
	# Tests whether the Hamming function with AREA normalization applied to a long array of 1's 
	# results in an output array whose values sum up to the length of the array. Tests for four consecutive array lengths.
	def testAreaNormalizationLongArrayLength(self):
		for arraySize in range(40000, 40004):
			self.checkAreaNormalization(arraySize,1.0)
	
	# Tests whether the Hamming function with AREA normalization applied to an array of 2's 
	# results in an output array whose values sum up to the length of the array times 2. Tests for four consecutive array lengths.
	def testAreaNormalizationWithDifferentArrayValue(self):
		for arraySize in range(40000, 40004):
			self.checkAreaNormalization(arraySize,2.0)
	
	###########################
	# AMPLITUDE normalization #
	###########################
	
	# Tests whether the Hamming function with AMPLITUDE normalization applied to a short array
	# of 1's results in an output array that has a maximum value of 1.  Tests for four consecutive array lengths.
	def testAmplitudeNormalizationShortArrayLength(self):
		for arraySize in range(1100,1104):
			self.checkAmplitudeNormalization(arraySize,1.0)
	
	# Tests whether the Hamming function with AMPLITUDE normalization applied to a long array
	# of 1's results in an output array that has a maximum value of 1.  Tests for four consecutive array lengths.
	def testAmplitudeNormalizationLongArrayLength(self):
		for arraySize in range(38000,38004):
			self.checkAmplitudeNormalization(arraySize,1.0)
			
	# Tests whether the Hamming function with AMPLITUDE normalization applied to a short array
	# of 2's results in an output array that has a maximum value of 2.  Tests for four consecutive array lengths.
	def testAmplitudeNormalizationWithDifferentArrayValue(self):
		for arraySize in range(1100,1104):
			self.checkAmplitudeNormalization(arraySize,2.0)
	
	########################
	# ENERGY normalization #
	########################
	
	# Tests whether the Hamming function with ENERGY normalization applied to an array
	# of 1's results in an output array for which the sum of its squares is 1. Tests for four consecutive array lengths.
	def testEnergyNormalizationShortArrayLength(self):
		for arraySize in range(3,7):
			self.checkEnergyNormalization(arraySize,1.0)
	
	# Tests whether the Hamming function with ENERGY normalization applied to an  array
	# of 1's results in an output array for which the sum of its squares is 1. Tests for four consecutive array lengths.
	def testEnergyNormalizationLongArrayLength(self):
		for arraySize in range(39000,39004):
			self.checkEnergyNormalization(arraySize,1.0)
	
	# Tests whether the Hamming function with ENERGY normalization applied to an array
	# of 2's results in an output array whose sum of squares is 4.    Tests for four consecutive array length.
	def testEnergyNormalizationWithDifferentArrayValue(self):
		for arraySize in range(100,104):
			self.checkEnergyNormalization(arraySize,2.0)
	
	#################
	# Alias Testing #
	#################
	
	# Tests whether the HAMMING alias provides area normalization
	def testHAMMINGAlias(self):
		arraySize = 3000
		expectedSum = arraySize
		# fill array of length arraySize with 1's (input to Hamming function)
		x = Double1d( arraySize )+1.0
		#Apply Hamming with alias and find difference between sum and expected value
		sumDiff = ABS(expectedSum - SUM(HAMMING(x)))/arraySize
		self.failUnless(sumDiff < self.epsilon, "Failure of HAMMING alias: does not provide area normalization")
		
	#Tests whether HAMMING.AMPLITUDE provides amplitude normalization
	def testHAMMINGAmplitudeAlias(self):
		arraySize = 3000
		arrayValue = 2
		expectedMax = arrayValue
		# fill array of length arraySize with 2's (input to Hamming function)
		x = Double1d( arraySize,arrayValue)
		#Apply amplitude normalized Hamming with alias and find difference between sum and expected value
		maxDiff = ABS(expectedMax - MAX(HAMMING.AMPLITUDE(x)))
		self.failUnless(maxDiff < self.epsilon, "Failure of Hamming alias: does not provide amplitude normalization")
		
	#Tests whether HAMMING.ENERGY provides energy normalization
	def testHAMMINGEnergyAlias(self):
		arraySize = 3000
		arrayValue = 2
		expectedSum = pow(arrayValue,2)
		# fill array of length arraySize with 2's (input to Hamming function)
		x = Double1d( arraySize,arrayValue)
		#Apply amplitude normalized Hamming with alias and find difference between sum and expected value
		sumDiff = ABS(expectedSum - SUM(pow(HAMMING.ENERGY(x),2)))
		self.failUnless(sumDiff < self.epsilon, "Failure of Hamming alias: does not provide energy normalization")
		
	
	########################
	# Legacy normalization #
	########################
	
	# Tests that when the Hamming function is applied using Hamming.PROCEDURE, the
	# result has AREA normalization.  This is tested by applying the Hamming function to an array of 1's
	# and checking that the output array has values that sum up to the length of the array.
	def testLegacyNormalization(self):
		arraySize = 3000
		expectedSum = arraySize
		# fill array of length arraySize with 1's (input to Hamming function)
		x = Double1d(arraySize,1.0)
		#Apply Hamming with the legacy PROCEDURE function object and find difference between sum and expected value
		sumDiff = ABS(expectedSum - SUM(Hamming.PROCEDURE(x)))/arraySize
		self.failUnless(sumDiff < self.epsilon, "Failure of Hamming function with default normalization for array of length " +str(arraySize))
		
	#################
	# Check Methods #
	#################
	
	# Applies the Hamming function (normalized by AREA) to an array filled with values of "arrayValue" and checks
	# that the sum of the output array's values is equal to the size
	# of the array times "arrayValue".
	#
	# arraySize - the size of the array to check for correct area normalization
	# arrayValue - the value to fill the array with
	def checkAreaNormalization(self, arraySize, arrayValue):
		expectedSum = arraySize*arrayValue
		# fill array of length arraySize with arrayValue values(input to Hamming function)
		x = Double1d( arraySize )+ arrayValue
		# find difference between the expected value and the sum of the output
		# from Hamming (normalized by AREA and divided by the array size)
		sumDiff = ABS(expectedSum - SUM(Hamming.AREA(x)))/arraySize
		self.failUnless(sumDiff < self.epsilon, "Failure of Hamming function with AREA normalization for array of length = "+ str(arraySize) +" and array values = " +str(arrayValue))
	
	# Applies the Hamming function (normalized by AMPLITUDE) to an array filled with values of "arrayValue" and checks
	# that the maximum amplitude of the output array is "arrayValue" for arrays of even length.  For arrays of odd length,
	# this method checks that there are two maximima and that their values are: (0.54 + (.46)*cos(pi/n))*"arrayvalue".
	#
	# arraySize - the size of the array to check for correct area normalization (must be >2)
	# arrayValue - the value to fill the array with (must be nonzero)
	def checkAmplitudeNormalization(self,arraySize, arrayValue):
		# fill array of length arraySize with arrayValue values (input to Hamming function)
		x = Double1d( arraySize )+ arrayValue
		# apply amplitude normalized Hamming function to array
		y = Hamming.AMPLITUDE(x)
		#If the array length is even
		if (arraySize % 2) == 0:
			#expect maximum of arrayValue because the Hamming maximum is at index arraySize/2
			expectedMax = arrayValue
			# find difference between expected and actual maximum value in output
			# from Hamming (normalized by AMPLITUDE)
			maxDiff = ABS(expectedMax - MAX(y))
			self.failUnless(maxDiff < self.epsilon, "Failure of Hamming function with AMPLITUDE normalization for array of length = "+ str(arraySize) +" and array values = " +str(arrayValue))
		else: # arrayLength is odd
			# When the array length is odd, the sampling of the Hamming function is such that
			# there are no samples at the maximum of the Hamming function.  Instead,
			# the sampled values have two maxima in adjacent indices having values equal to (0.54 + (.46)*cos(pi/arraySize))*arrayvalue
			expectedMax = (0.54 + 0.46*Math.cos(Math.PI/arraySize))*arrayValue
			#find maximum
			actualMax = MAX(y)
			#get difference
			maxDiff = ABS(expectedMax - actualMax)
			#Make sure difference between actual and expected is small enough
			self.failUnless(maxDiff < self.epsilon, "Failure of Hamming function with AMPLITUDE normalization for array of length = "+ str(arraySize) +" and array values = " +str(arrayValue))
			#Make sure that there are two maxima adjacent to each other
			maxima = y.where(y.eq(actualMax)).toInt1d()
			self.failUnless(maxima.getSize() == 2, "Two maxima not found in Hamming output for an array of length  = "+ str(arraySize) +" and array values = " +str(arrayValue)) 
			#Make sure that maxima are adjacent
			self.failUnless( ABS(maxima.get(0) - maxima.get(1)) == 1, "Adjacent maxima not found in Hamming output for an array of length  = "+ str(arraySize) +" and array values = " +str(arrayValue))   
	
	# Applies the Hamming function (normalized by ENERGY) to an array filled with values of "arrayValue" and checks
	# that the sum of the squares of the output array is "arrayValue" squared.
	#
	#arraySize - the size of the array to check for correct area normalization
	# arrayValue - the value to fill the array with
	def checkEnergyNormalization(self, arraySize, arrayValue):
		expectedSum = pow(arrayValue,2)
		# fill array of length arraySize with 1's (input to Hamming function)
		x = Double1d( arraySize )+ arrayValue
		# Find difference between expected and actual sum of the squares of the 
		# Hamming output (normalized by ENERGY)
		sumDiff = ABS(expectedSum - SUM(pow(Hamming.ENERGY(x),2)))
		self.failUnless(sumDiff < self.epsilon, "Failure of Hamming function with ENERGY normalization for array of length = "+ str(arraySize) +" and array values = " +str(arrayValue))

# Run this module as an independent test
if __name__ == '__main__':
	suite=unittest.makeSuite(HammingTest)
	unittest.TextTestRunner().run(suite)
