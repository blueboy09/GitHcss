/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: RealDoubleFFT_Even_OddTest.java,v 1.2 2012/06/07 20:45:33 tfulton Exp $
 *
 * Copyright (c) 2007 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import herschel.ia.numeric.Double1d;

import java.util.logging.Logger;

import junit.framework.JUnit4TestAdapter;

import org.junit.Test;

/**
 * Tests the ComplexDoubleFFT class.
 * 
 * At the time of this writing, 13DEC10, this test harness only ensures that ComplexDoubleFFT's 
 * methods are invokable: it does not confirm anything significant about the validity of the 
 * methods' output.
 * 
 * @author David Sharpe
 */
public class RealDoubleFFT_Even_OddTest {

    private static final Logger LOG = Logger.getLogger(RealDoubleFFT_Even_OddTest.class.getName());

    /**
     * Calls the bt method several times to cover a variety of input size conditions.
     */
    @Test
    public void testBt() {
        LOG.info("testBt");

        for (int size = 2; size < 200; size++) {
            RealDoubleFFT_Even_Odd table = new RealDoubleFFT_Even_Odd(size);
            double[] out = Double1d.range(size).toArray();
            table.bt(out);
            assertBasics(out, size);
        }
    }

    /**
     * Calls the ft method several times to cover a variety of input size conditions.
     */
    @Test
    public void testFt() {
        LOG.info("testFt");

        for (int size = 2; size < 200; size++) {
            RealDoubleFFT_Even_Odd table = new RealDoubleFFT_Even_Odd(size);
            double[] out = Double1d.range(size).toArray();
            table.ft(out);
            assertBasics(out, size);
        }
    }

    /**
     * Confirm that the output is non-null and the right size.
     * 
     * @param out the output of the method.
     * @param size the expected size of the output.
     */
    private static final void assertBasics(double[] out, int size) {

        assertNotNull("The output cannot be null.", out);
        assertEquals("The output length must equal the input length.", size, out.length);
    }

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(RealDoubleFFT_Even_OddTest.class);
    }

}
