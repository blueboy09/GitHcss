/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: FFTTest.java,v 1.4 2012/06/07 20:45:33 tfulton Exp $
 *
 * Copyright (c) 2001 Jon Brumfitt
 */

package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.basic.Basic;

import java.util.Random;
import junit.framework.*;

/**
 * Test harness for Fast Fourier Transform.
 *
 * @author Jon Brumfitt
 */
public class FFTTest extends TestCase {
    private static final double EPSILON = 1E-11;

    public FFTTest(String name) {
        super(name);
    }

    private double rmsDiff(Complex1d x, Complex1d y) {
        return x.copy().subtract(y).apply(Basic.ABS).as().double1d().reduce(Basic.SUM);
    }

    public static Test suite() {
        return new TestSuite(FFTTest.class);
    }

    protected void setUp() {
    }

    protected void tearDown() {
    }

    // Create some random data.
    private Complex1d createData(int n) {
        Random random = new Random(7356092013606681914L);

        double[] real = new double[n];
        double[] imag = new double[n];

        for (int i = 0; i < n; i++) {
            real[i] = random.nextDouble();
            imag[i] = random.nextDouble();
        }
        return new Complex1d(real, imag);
    }

    public void testChirpZ() {
        // Try with non power-of-2.
        double sigma = doChirpZ(13);
        assertTrue(sigma < EPSILON);

        // Try with a power-of-2.
        sigma = doChirpZ(16);
        assertTrue(sigma < EPSILON);
    }

    private double doChirpZ(int n) {
        Complex1d data = createData(n);

        Complex1d z = data.copy();
        FFT.chirpZFft(z);

        Complex1d ref = data.copy();
        FFT.dft(ref);
        return rmsDiff(z, ref) / n;
    }

    public void testCooleyTukey() {
        double sigma = doCooleyTukey(16);
        assertTrue(sigma < EPSILON);
    }

    private double doCooleyTukey(int n) {
        Complex1d data = createData(n);
        Complex1d z = data.copy();
        FFT.cooleyTukeyFft(z);

        Complex1d ref = data.copy();
        FFT.dft(ref);

        return rmsDiff(z, ref) / n;
    }
}
