/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id:
 *
 * Copyright (c) 2007 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.toolbox.xform.util.RealDoubleFFT_Even_OddTest;
import herschel.share.testharness.PyTestModule;
import junit.framework.TestSuite;

/**
 * @author Zhaohan Weng
 *
 * Change Log:
 * 2007-11-27 ZW First Version
 * 2008-03-03 PK Removed static paths to Jython module
 */
public class AllTests {

    public static junit.framework.Test suite() {
        TestSuite suite = new TestSuite();

        suite.addTest(FFTTest.suite());
        suite.addTest(FFT_PACKTest.suite());
        suite.addTest(FFT_PACK_EVENTest.suite());
        suite.addTest(FFT_PACK_ODDTest.suite());
        suite.addTest(RealDoubleFFT_Even_OddTest.suite());

        suite.addTest(TestHamming.suite());
        suite.addTest(TestHanning.suite());
        suite.addTest(new PyTestModule("herschel.ia.numeric.toolbox.xform.HanningTest"));
        suite.addTest(new PyTestModule("herschel.ia.numeric.toolbox.xform.HammingTest"));
        suite.addTest(new PyTestModule("herschel.ia.numeric.toolbox.xform.HammingFTDataTest"));
        suite.addTest(new PyTestModule("herschel.ia.numeric.toolbox.xform.HanningFTDataTest"));

        return suite;
    }

    /**
     * Both JUnit 3.8 and 4.3 runners can run this test class
     * @param args String[]
     */
    public static void main(String[] args) {
        org.junit.runner.JUnitCore.main("herschel.ia.numeric.toolbox.xform.AllTests");
    }
}
