/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: FFT_PACK_EVENTest.java,v 1.3 2012/06/07 20:45:33 tfulton Exp $
 *
 * Copyright (c) 2007 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.basic.Basic;
import java.util.Random;
import junit.framework.*;
import herschel.ia.numeric.toolbox.basic.Reverse;

public class FFT_PACK_EVENTest extends TestCase {
    private static final double EPSILON = 1e-13;

    public FFT_PACK_EVENTest(String name) {
        super(name);
    }

    private double rmsDiff(Double1d x, Double1d y) {
        return x.copy().subtract(y).apply(Basic.ABS).as().double1d().reduce(Basic.SUM);
    }

    public static Test suite() {
        return new TestSuite(FFT_PACK_EVENTest.class);
    }

    protected void setUp() {
    }

    protected void tearDown() {
    }

    // Create some random data.
    private Double1d createData(int n) {
        Random random = new Random(7356092013606681914L);

        double[] real = new double[n];

        for (int i = 0; i < n; i++) {
            real[i] = random.nextDouble();
        }
        return new Double1d(real);
    }

    public void testCosine() {

    }

    public void notYetImplementedtestCosine() {
        double sigma = doCosine(14);
        assertTrue(sigma < EPSILON);

        sigma = doCosine(15);
        assertTrue(sigma < EPSILON);

        //
        // @todo FIXME: forward followed by inverse transform is not bumped up by a known factor
        //
        sigma = doCosineForwardBackward(14);
        assertTrue(sigma < EPSILON);
    }

    public double doCosine(int n) {
        Double1d data = createData(n / 2 + 1);
        Double1d copy = data.copy();

        Complex1d ref = new Complex1d(data.copy());
        ref = butterfly(ref);

        copy = FFT_PACK_EVEN.fft_pack_even(copy);
        copy = butterfly(new Complex1d(copy)).getReal();

        FFT.dft(ref);

        return rmsDiff(copy, ref.getReal()) / n;
    }

    private double doCosineForwardBackward(int n) {
        Double1d data = createData(n);

        Double1d copy = data.copy();

        copy = FFT_PACK_EVEN.fft_pack_even(copy);
        copy = FFT_PACK_EVEN.ifft_pack_even(copy);

        //sine forward reverse is not out by a factor of n or n^2
        copy.divide(n);

        return rmsDiff(data, copy) / n;
    }

    public static void main(String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    /**
     * Butterfly the incoming data.
     *
     * @param complex Array to be butterflyed
     * @return Result
     */
    public Complex1d butterfly(Complex1d complex) {
        Complex1d result;
        Double1d rhsReal, rhsImag;

        result = new Complex1d(complex.getSize() * 2 - 2);
        result.set(new Range(0, complex.getSize()), complex);
        // RH real portion of result is even
        rhsReal = (Double1d) complex.get(new Range(1, complex.getSize() - 1)).getReal()
                .apply(Reverse.PROCEDURE);
        rhsImag = (Double1d) complex.get(new Range(1, complex.getSize() - 1)).getImag()
                .apply(Reverse.PROCEDURE);
        rhsImag.multiply(-1);

        // add the RHS to the result
        result.set(new Range(complex.getSize(), result.getSize()), new Complex1d(rhsReal, rhsImag));

        return result;

    }

}
