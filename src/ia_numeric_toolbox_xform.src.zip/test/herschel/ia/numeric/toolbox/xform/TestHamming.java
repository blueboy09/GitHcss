/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: TestHamming.java,v 1.3 2012/06/07 20:45:33 tfulton Exp $
 *
 * Copyright (c) 2007 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform;

import junit.framework.JUnit4TestAdapter;
import static org.junit.Assert.*;
import org.junit.*;
import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.basic.Max;
import herschel.ia.numeric.toolbox.basic.Sum;

/**
 * Test harness for the Hamming function.
 * 
 * @author Trevor Fulton (trevor.fulton@blueskyinc.ca), Zhaohan Weng
 * @version $Revision: 1.3 $
 * @jhistory:
 * 23 Nov 2007: (ZW) Added tests for hamming amplitude and energy
 * 07 Mar 2008: (PK) Changed tests to reflect new location (arraylength/2.0) of maximum amplitude of output array. Refactored.
 * 13 Mar 2008: (PK) Introduced new Hamming API that uses static members
 */
public class TestHamming {

    // Maximum error for double-precision tests to pass
    static final double EPSILON = 1e-13;
    // Maximum error for single-precision tests to pass
    static final float EPSILON_FLOAT = 1e-5f;

    /**
     *  Checks that the Hamming function accepts floating point input.
     */
    @Test
    public void testFloatingPoint() {
        int n = 101;
        Float1d odd = new Float1d(n, 1.0f);
        Float1d resultOdd = (Float1d) odd.apply(Hamming.AREA);

        //Get sum of values in array
        float oddSum = resultOdd.reduce(Sum.FOLDR);

        // Check that sum is as expected
        float sumDiff = Math.abs((float) resultOdd.getSize() - oddSum);
        assertTrue("Float1d input not AREA normalized, Sum mismatch " + (float) resultOdd.getSize()
                + ":" + oddSum, sumDiff < EPSILON_FLOAT);
    }

    /**
     * Tests that apply and perform methods result in not-in-place and in-place operations respectively.
     */
    @Test
    public void testInplace() {
        int n = 100;
        Double1d x = new Double1d(n, 1);
        Double1d y = new Double1d();
        y = (Double1d) x.apply(Hamming.ENERGY);
        assertNotSame(x, y);
        assertTrue(x != y);
        y = (Double1d) x.perform(Hamming.ENERGY);
        assertEquals(x, y);
        assertSame(x, y);
    }

    /**
     * Test the Hamming area function for when the
     * input array has an odd number of points
     */
    @Test
    public void testAreaOdd() {
        int n = 101;
        Double1d odd = new Double1d(n, 1);
        Double1d resultOdd = (Double1d) odd.apply(Hamming.AREA);

        //Get sum of values in array
        double oddSum = resultOdd.reduce(Sum.FOLDR);

        // Check that sum is as expected
        double sumDiff = Math.abs((double) resultOdd.getSize() - oddSum);
        assertTrue("AREA: odd: Data not normalized, Sum mismatch " + (double) resultOdd.getSize() + ":"
                + oddSum, sumDiff < EPSILON);
    }

    /**
     * Test the Hamming area function for when the
     * input array has an even number of points
     */
    @Test
    public void testAreaEven() {
        int n = 100;
        Double1d even = new Double1d(n, 1);
        Double1d resultEven = (Double1d) even.apply(Hamming.AREA);

        //Check that the array has symmetrical values
        checkSymmetry(resultEven, "Even length array with AREA normalization");

        //Get sum of values in array
        double evenSum = resultEven.reduce(Sum.FOLDR);

        //Check that sum is as expected
        double sumDiff = Math.abs((double) resultEven.getSize() - evenSum);
        assertTrue("AREA: even: Data not normalized, Sum mismatch " + (double) resultEven.getSize()
                + ":" + evenSum, sumDiff < EPSILON);
    }

    /**
     * Test the Hamming amplitude function for when the
     * input array has an odd number of points
     */
    @Test
    public void testAmplitudeOdd() {
        int n = 101;
        Double1d odd = new Double1d(n, 1);
        Double1d resultOdd = (Double1d) odd.apply(Hamming.AMPLITUDE);

        //Check that the array has symmetrical values
        checkSymmetry(resultOdd, "Odd length array with AMPLITUDE normalization");

        // Check that the amplitude normalization is correct
        checkAmplitudeNormalization(resultOdd, 1.0);
    }

    /**
     * Test the Hamming amplitude function for when the
     * input array has an even number of points.
     */
    @Test
    public void testAmplitudeEven() {
        int n = 100;
        Double1d even = new Double1d(n, 1);
        Double1d resultEven = (Double1d) even.apply(Hamming.AMPLITUDE);

        //Check that the array has symmetrical values
        checkSymmetry(resultEven, "Even length array with AMPLITUDE normalization");

        // Check that the amplitude normalization is correct
        checkAmplitudeNormalization(resultEven, 1.0);
    }

    /**
     * Test the Hamming energy function for when the
     * input array has an odd number of points.
     */
    @Test
    public void testEnergyOdd() {
        int n = 101;
        double expectedSum = 1.0;
        Double1d odd = new Double1d(n, 1);
        Double1d resultOdd = (Double1d) odd.apply(Hamming.ENERGY);

        //Check that the array has symmetrical values
        checkSymmetry(resultOdd, "Odd length array with ENERGY normalization");

        //Get sum of squares
        double oddSum = resultOdd.dotProduct(resultOdd);

        //Is the sum of squares as expected?
        double sumDiff = expectedSum - oddSum;
        assertTrue("ENERGY: odd: Data not normalized, Sum mismatch " + expectedSum + ":" + oddSum,
                sumDiff < EPSILON);
    }

    /**
     * Test the Hamming energy function for when the
     * input array has an even number of points.
     */
    @Test
    public void testEnergyEven() {
        int n = 100;
        double expectedSum = 1.0;
        Double1d even = new Double1d(n, 1);
        Double1d resultEven = (Double1d) even.apply(Hamming.ENERGY);

        //Check that the array has symmetrical values
        checkSymmetry(resultEven, "Even length array with ENERGY normalization");

        //Get sum of squares
        double evenSum = resultEven.dotProduct(resultEven);

        //Is the sum of squares as expected?
        double sumDiff = expectedSum - evenSum;
        assertTrue("ENERGY: even: Data not normalized, Sum mismatch " + expectedSum + ":" + evenSum,
                sumDiff < EPSILON);
    }

    /**
     * Test the default PROCEDURE api and expect 
     * area normalized output.
     */
    @Test
    public void testLegacy() {
        int n = 101;
        Double1d arr = new Double1d(n, 1.0);
        //Use legacy Hamming.PROCEDURE Api
        Double1d resultArr = (Double1d) arr.apply(Hamming.PROCEDURE);

        //Get sum of values in array
        double arrSum = resultArr.reduce(Sum.FOLDR);

        // Check that sum is as expected
        double sumDiff = Math.abs((double) resultArr.getSize() - arrSum);
        assertTrue(
                "Default PROCEDURE Api does not apply Hamming function with AREA normalization, Sum mismatch "
                        + (double) resultArr.getSize() + ":" + arrSum, sumDiff < EPSILON);
    }

    /**
     * Checks that the array is symmetrical (excepting the 0th index of the
     * array which is unique). For even length arrays, the (arrayLength)/2 
     * index is also unique.
     * 
     * @param array The array to check for symmetry.
     * @param failMessage The message to display if the check fails.
     */
    public void checkSymmetry(Double1d array, String failMessage) {

        //get number of pairs
        //Note: the 0 index is a unique point and is not paired
        int pairs = array.getSize() / 2;

        //If the array is of even length
        if (array.getSize() % 2 == 0) {
            //subtract 1 from number of pairs
            pairs--;
        }

        //For each pair  
        for (int i = 0; i < pairs; i++) {

            //Left point in pair
            int leftInd = i + 1;
            //Right point in pair
            int rightInd = array.getSize() - 1 - i;

            // compare ith point with (n-i)th
            double diff = Math.abs(array.get(leftInd) - array.get(rightInd));
            assertTrue(failMessage + ", Unmatched Indices: " + array.get(leftInd) + " at " + leftInd
                    + " != " + array.get(rightInd) + " at " + rightInd, diff < EPSILON);
        }
    }

    /**
     * Checks that the array has a maximum amplitude of 1 (if of even length).
     * Checks that the array has 2 adjacent maxima having values equal to (0.54 + (.46)*cos(pi/arraySize))*arrayvalue
     * @param array The array to check
     * @param arrayValue The value of all elements in the array before the Hamming function was applied
     */
    public void checkAmplitudeNormalization(Double1d array, double arrayValue) {
        int arraySize = array.getSize();
        double expectedMax;
        double actualMax = array.reduce(Max.FOLDR);

        //If the array length is even
        if ((arraySize % 2) == 0) {
            //expected maximum from Hamming
            expectedMax = arrayValue;

            // find difference between expected and actual maximum value in output
            // from Hamming (normalized by AMPLITUDE)
            double maxDiff = Math.abs(expectedMax - actualMax);
            assertTrue("Failure of Hamming function with AMPLITUDE normalization for array of length = "
                    + arraySize + " and array values = " + arrayValue, maxDiff < EPSILON);
        } else {// arrayLength is odd
            // When the array length is odd, the sampling of the Hamming function is such that
            // there are no samples at the maximum of the Hamming function.  Instead,
            // the sampled values have two maxima in adjacent indices having values equal to (0.54 + (.46)*cos(pi/arraySize))*arrayvalue
            expectedMax = (0.54 + 0.46 * Math.cos(Math.PI / arraySize)) * arrayValue;

            //get difference
            double maxDiff = Math.abs(expectedMax - actualMax);
            //Make sure difference between actual and expected is small enough
            assertTrue("Failure of Hamming function with AMPLITUDE normalization for array of length = "
                    + arraySize + " and array values = " + arrayValue, maxDiff < EPSILON);
            //Make sure that there are two maxima adjacent to each other
            Int1d maxima = array.where(array.eq(actualMax)).toInt1d();
            assertTrue("Two maxima not found in Hamming output for an array of length  = " + arraySize
                    + " and array values = " + arrayValue, maxima.getSize() == 2);
            //Make sure that maxima are adjacent
            assertTrue("Adjacent maxima not found in Hamming output for an array of length  = "
                    + arraySize + " and array values = " + arrayValue, maxima.getSize() == 2);
        }
    }

    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(TestHamming.class);
    }

    public static void main(String[] args) {
        org.junit.runner.JUnitCore.main("herschel.ia.numeric.toolbox.xform.TestHamming");
    }
}
