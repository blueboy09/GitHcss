/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: FFT_PACKTest.java,v 1.3 2012/06/07 20:45:33 tfulton Exp $
 *
 * Copyright (c) 2007 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform;

import junit.framework.*;
import java.util.Random;
import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.basic.Basic;
import herschel.ia.numeric.toolbox.basic.Reverse;

public class FFT_PACKTest extends TestCase {
    private static final double EPSILON = 1e-13;

    public FFT_PACKTest(String name) {
        super(name);
    }

    private double rmsDiff(Complex1d x, Complex1d y) {
        return x.copy().subtract(y).apply(Basic.ABS).as().double1d().reduce(Basic.SUM);
    }

    public static Test suite() {
        return new TestSuite(FFT_PACKTest.class);
    }

    // Create some random data.
    private Complex1d createData(int n) {
        Random random = new Random(7356092013606681914L);

        double[] real = new double[n];
        double[] imag = new double[n];

        for (int i = 0; i < n; i++) {
            real[i] = random.nextDouble();
            imag[i] = random.nextDouble();
        }
        return new Complex1d(real, imag);
    }

    public void testReal13() {
        double sigma = doReal(13);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testReal14() {
        double sigma = doReal(14);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testReal15() {
        double sigma = doReal(15);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testReal16() {
        double sigma = doReal(16);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testReal17() {
        double sigma = doReal(17);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testReal18() {
        double sigma = doReal(18);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testReal19() {
        double sigma = doReal(19);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testReal20() {
        double sigma = doReal(20);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealReverse13() {
        double sigma = doRealReverse(13);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealReverse14() {
        double sigma = doRealReverse(14);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealReverse15() {
        double sigma = doRealReverse(15);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealReverse16() {
        double sigma = doRealReverse(16);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealReverse17() {
        double sigma = doRealReverse(17);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealReverse18() {
        double sigma = doRealReverse(18);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealReverse19() {
        double sigma = doRealReverse(19);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealReverse20() {
        double sigma = doRealReverse(20);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealFB13() {
        double sigma = doRealForwardBackward(13);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealFB14() {
        double sigma = doRealForwardBackward(14);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealFB15() {
        double sigma = doRealForwardBackward(15);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    public void testRealFB16() {
        double sigma = doRealForwardBackward(16);
        assertTrue("sigma > " + EPSILON + ", " + sigma, sigma < EPSILON);
    }

    private double doReal(int n) {

        Double1d data = createData(n).getReal();
        Complex1d z = new Complex1d(data.copy());
        Complex1d ref = z.copy();

        z = FFT_PACK.fft_pack(z);

        FFT.dft(ref);
        assertEquals("Length Mismatch", ref.length(), z.length());
        double sigma = rmsDiff(z, ref) / n;
        assertNotNull("sigma is null", sigma);

        return sigma;
    }

    private double doRealReverse(int n) {

        Double1d data = createData(n).getReal();
        Complex1d z = new Complex1d(data.copy());
        Complex1d ref = z.copy();

        z = FFT_PACK.ifft_pack(z);

        FFT.idft(ref);
        assertEquals("Length Mismatch", ref.length(), z.length());
        double sigma = rmsDiff(z, ref) / n;
        assertNotNull("sigma is null", sigma);

        return sigma;
    }

    private double doRealLength(int n) {

        Double1d data = createData(n).getReal();
        Complex1d z = new Complex1d(data.copy());
        Complex1d ref = z.copy();

        z = FFT_PACK.fft_pack(z);

        FFT.dft(ref);
        assertEquals("Length Mismatch", ref.length(), z.length());

        return rmsDiff(z, ref) / n;
    }

    private double doRealForwardBackward(int n) {
        Double1d data = createData(n).getReal();

        Complex1d z = new Complex1d(data.copy());

        z = FFT_PACK.fft_pack(z);
        z = FFT_PACK.ifft_pack(z);
        z.divide(new Complex(n));

        return rmsDiff(new Complex1d(data), z) / n;
    }

    public static void main(String[] args) {
        junit.textui.TestRunner.run(suite());
    }

    /**
     * Butterfly the incoming data.
     *
     * @param complex Array to be butterflyed
     * @return Result
     */
    public Complex1d butterfly(Complex1d complex) {
        Complex1d result;
        Double1d rhsReal, rhsImag;

        result = new Complex1d(complex.getSize() * 2 - 2);
        result.set(new Range(0, complex.getSize()), complex);
        // RH real portion of result is even
        rhsReal = (Double1d) complex.get(new Range(1, complex.getSize() - 1)).getReal()
                .apply(Reverse.PROCEDURE);
        rhsImag = (Double1d) complex.get(new Range(1, complex.getSize() - 1)).getImag()
                .apply(Reverse.PROCEDURE);
        rhsImag.multiply(-1);

        // add the RHS to the result
        result.set(new Range(complex.getSize(), result.getSize()), new Complex1d(rhsReal, rhsImag));

        return result;

    }

}
