package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.*;
import java.util.Random;
import static herschel.ia.numeric.toolbox.xform.FFT.FFT;
import static herschel.ia.numeric.toolbox.xform.FFT.IFFT;
import static herschel.ia.numeric.toolbox.xform.CudaFFT.CudaFFT;
import static herschel.ia.numeric.toolbox.xform.CudaFFT.CudaIFFT;


/**
 * Compare the timeused of CuFFT and FFT
 * 
 * @jhelp A rectangular numeric Complex array of rank 1.
 *
 *
 * @jcategory xform
 *
 * @jparameters 
 * "direction" :FORWARD/REVERSE means usiing FFT(value -1) of IFFT(value 1)
 * 
 * use "begin step and end" to  determine the test array's dimenstion
 * 
 * "num" means the calculate times of test
 * 
 * 
 * @author Yifei Jin <m-astro@163.com>
 *         
 */

public class FFTCmp {

	public final int FORWARD=-1;
	public final int REVERSE=1;
	public final int LOGSCALE=0;
	public final int LINESCALE=1;
	
	int begin;
	int end;
	int step;
	int direction;
	int num;
	
	public FFTCmp(){
		begin=1;
		end=1001;
		step=20;
		num=50;
		direction=this.FORWARD;
	}
	public FFTCmp(int _begin, int _end, int _step,int _num, int _direction) {
		begin=_begin;
		end=_end;
		step=_step;
		num=_num;
		direction=_direction;
	}
	
	/**
	 * 
	 * 
	 * RESET the test parameters 
	 *
	 */
	public void SetPara(int _begin, int _end, int _step,int _num, int _direction) {
		this.begin=_begin;
		this.end=_end;
		this.step=_step;
		this.num=_num;
		this.direction=_direction;
	}
	
	/**
	 * the main method
	 * calculate the time used of the data scale [begin:step:end]
	 * 
	 * 
	 */
	
	
	public double[][] FFTtime(int scaleMode){
		if(scaleMode==this.LINESCALE){
			double[][] timelist= new double[2][(int)((end-begin)/step)];
			double[] timeonce ={0,0};
			int j=0;
			for(int i=begin;i<end;i+=step){
				timeonce=ComPare(i,this.num,this.direction);
				timelist[0][j]=timeonce[0];
				timelist[1][j]=timeonce[1];
				j=j+1;
			}
			return timelist;
		}else if(scaleMode==this.LOGSCALE){
			double[][] timelist= new double[2][(int)((end-begin)/step)];
			double[] timeonce ={0,0};
			int j=0;
			for(int i=begin;i<end;i+=step){
				timeonce=ComPare((int)java.lang.Math.pow(2, i),this.num,this.direction);
				timelist[0][j]=timeonce[0];
				timelist[1][j]=timeonce[1];
				j=j+1;
			}
			return timelist;
			
		}else{
			throw new IllegalArgumentException("NO SUCH SCALE MODE");
		}
		
		
	}
	
	/**
	 * 
	 * @param dim :the data dimension of FFT 
	 * @param num :accumulate numbers 
	 * @param direction : FFT or IFFT
	 * @return the time used
	 * 
	 */
	public double[] ComPare(int dim, int num, int direction) {
		
		Complex1d X=null;
//		Complex1d Y1=null;
//		Complex1d Y2=null;
		double[] timelist =null;
		double timeBegin=0,timeEnd=0;
		double cuTime=0,jaTime=0;
		if(direction==this.FORWARD){
			for(int i=0;i<num;i++){
				X=GenerateArray(dim);
				timeBegin=(double)System.nanoTime();
				X.apply(FFT);	
				timeEnd =(double)System.nanoTime() - timeBegin;
				jaTime+=timeEnd;
				timeBegin=(double)System.nanoTime();
				X.apply(CudaFFT);
				timeEnd =(double)System.nanoTime() - timeBegin;
				cuTime+=timeEnd;
			}
		}
		else if(direction==this.REVERSE){
			for(int i=0;i<num;i++){
				X=GenerateArray(dim);
				timeBegin=(double)System.nanoTime();
				X.apply(IFFT);
				timeEnd =(double)System.nanoTime() - timeBegin;
				jaTime+=timeEnd;
				
				timeBegin=(double)System.nanoTime();
				X.apply(CudaIFFT);
				timeEnd =(double)System.nanoTime() - timeBegin;
				cuTime+=timeEnd;
			}
		}
		else {
			throw new IllegalArgumentException("the direction is error");
		}
		
		jaTime = jaTime/(1000000000.0*num);
		cuTime = cuTime/(1000000000.0*num);
		timelist=new double[]{jaTime,cuTime};
		return timelist;
		
	}
	/**
	 * 
	 * @param dim: the dimension 
	 * @return a Complex1d Array 
	 */
	public Complex1d GenerateArray(int dim){
		Random rdm= new Random();
		double[] re = new double[dim];
		double[] im = new double[dim];
		for(int i=0;i<dim;i++){
			re[i]=rdm.nextDouble();
			im[i]=rdm.nextDouble();
		}
		Complex1d Array = new Complex1d(re,im);
		return Array;
	}
	/**
	 * 
	 * @param result the result of CuFFT/CuIFFT
	 * @param reference the result of FFT/IFFT
	 * @return if the error is small enough, then return right
	 */
	
	public boolean isCorrectResult(Complex1d result, Complex1d reference)
	    {
	        double errorNorm = 0;
	        double refNorm = 0;
	        double para;
	        for (int i = 0; i < result.getSize(); i++)
	        {
	            Complex diff = result.get(i).divide(reference.get(i));
	            errorNorm += diff.abs()*diff.abs();
	            para=(reference.get(i).multiply(result.get(i).conjugate())).abs();
	            refNorm += para*para;
	        }
	        errorNorm = (double) Math.sqrt(errorNorm);
	        refNorm = (double) Math.sqrt(refNorm);
	        if (Math.abs(refNorm) < 1e-6)
	        {
	            return false;
	        }
	        return (errorNorm / refNorm < 1e-6f);
	    }
	
}
