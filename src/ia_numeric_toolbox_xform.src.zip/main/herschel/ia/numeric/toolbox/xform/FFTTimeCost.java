package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.*;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

/**
 * 
 * @author Yifei Jin <m-astro@163.com>
 *
 */
public class FFTTimeCost {
	/**
	 * Constructor
	 */

	public FFTTimeCost() {
		// TODO Auto-generated constructor stub
	}
	
//------------------------------ time cost calculate ---------------------------------
	/**
	 * 
	 * calculate the time cost of the method Ops
	 * @param Ops the operator (method) which we care about
	 * @param Path  the output path of detail result NumCount.class 
	 * @return : time cost of the method 
	 * @throws IOException
	 */
	public static double TimeCost(String Ops,String Path) throws IOException{
		long[][] numCount = TcInput(Ops, Path);
		int len,nums;
		int row=numCount.length;
		if(row!=2) throw new IllegalArgumentException("the lead dimension unmatched");
		int col=numCount[0].length;
		double AllTime=0;
		for(int i=0;i<col;i++){
				len=(int)(numCount[0][i]);
				nums=(int)(numCount[1][i]);
				AllTime=AllTime+TimeCal(Ops,len)*nums;					
				

		}
		return AllTime;
	}
	
	/**
	 * calculate the time cost of once method called
	 * @param Ops :operator ,the method which we care about
	 * @param len : the dimension of data 
	 * @return: the time used of the data scale of the method 
	 * 
	 */
	public static double TimeCal(String Ops,int len){
		double timeused=0;
		double timeBegin=0,timeEnd=0;
		int its=200;
		if(Ops=="NCfft"){
			for(int i=0;i<its;i++){
				Complex1d X = GenerateArray(len);
				timeBegin=System.nanoTime();
				FFT.fft(X);
				timeEnd=(double) (System.nanoTime()-timeBegin)/1000000000.0;
				timeused+=timeEnd;
			}
			
//     according the methods, the IFFT has already been calculate by the FFT methods		
		}else if(Ops=="NCifft"){
			for(int i=0;i<its;i++){
				Complex1d X = GenerateArray(len);
				timeBegin=System.nanoTime();
				FFT.invFft(X);
				timeEnd=(double) (System.nanoTime()-timeBegin)/1000000000.0;
				timeused+=timeEnd;
			}
			
		}else{
			timeEnd=-1;
			throw new IllegalArgumentException("these kind of operation is not exsit");
		}
		return (timeused/its);
	}
	
//-------------------------------input the data from number count file ---------------	
	
	
	/**
	 * 
	 * Input the called times of the method
	 * @param name the name of the operator/method/function 
	 * @param Path : the path of input result
	 * @return
	 * @throws IOException
	 */
	public static long[][] TcInput (String name, String Path) throws IOException{
		  InputStream is = null;
		  DataInputStream dis = null;
		  long[][] dbuf=null ;
		  try{
			  is = new FileInputStream(Path+name);
			  dis = new DataInputStream(is);
	  	      int i=0;		   
		      int j=0;		   
		      int num=dis.readInt();
		     
		      dbuf=new long[2][num];
		      while(dis.available()>0)
		      {
		    	 if(j==num){ 
		    	 i++;
	    		 j=0;
	    	  }
	          dbuf[i][j] = dis.readLong();
	          j++;
		     }   
		  }catch(Exception e){     
			  e.printStackTrace();
		  }finally{
			  if(is!=null)
				  is.close();
			  if(dis!=null)	
			  	dis.close();
		  }
		return dbuf;
	}
// ---------------------------------------- Generate Array ------------------------
	/**
	 * generate the random Complex1d data 
	 * @param length the dimension of the data
	 * @return the random generate array
	 */
	public static Complex1d GenerateArray(int length){
		Random rdm =new Random();
		double[] re= new double[length];
		double[] imag=new double[length];
		for(int i=0;i<length;i++){
			re[i]=rdm.nextDouble();
			imag[i]=rdm.nextDouble();
		}
		Complex1d X= new Complex1d(re,imag);
		return X;
	}

	
	
	
}

