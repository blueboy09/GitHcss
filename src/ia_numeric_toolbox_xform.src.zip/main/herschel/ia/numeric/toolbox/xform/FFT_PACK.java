/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: FFT_PACK.java,v 1.9 2012/07/23 22:24:27 tfulton Exp $
 *
 * Copyright (c) 2011 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.Complex1d;
import herschel.ia.numeric.toolbox.AbstractArrayProcedure;
import herschel.ia.numeric.toolbox.ArrayProcedure;
import herschel.ia.numeric.toolbox.xform.util.Complex1D;
import herschel.ia.numeric.toolbox.xform.util.ComplexDoubleFFT;

/**
 * Fast Fourier Transform of complex data using the FFT_PACK algorithm. 
 * <p>       
 * FFT_PACK transforms complex input into complex output.  
 * The forward transform of FFT_PACK is equivalent to that of FFT but it may require less time to execute.
 * </p>
 * <p>
 * If input has length N then output has length N.  
 * FFT_PACK is fast for input for which the input length can be  decomposed into small factors.
 * </p>    
 * <p>
 * Use FFT_PACK when the input has a length which can be decomposed into small factors.  
 * However, if the length of input has large prime factors, use FFT instead.
 * Also, if the input length is a power of two, use FFT instead.  
 * </p>
 * <p>
 * The inverse transform is IFFT_PACK.  
 * It transforms complex input to complex output. 
 * If input has length N then output has length N.     
 * Note that the output of IFFT_PACK is not normalized.    
 * To normalize, divide by the length of the input: signal = IFFT_PACK(FFT_PACK(signal))/(signal.size)
 *</p>
 *
 * @jhelp Gives the Fast Fourier Transform of complex data using an FFT_PACK algorithm.  
 * 
 * <p>       
 * FFT_PACK transforms complex input into complex output.  
 * The forward transform of FFT_PACK is equivalent to that of FFT but it may require less time to execute.
 * </p>
 * <p>
 * If input has length N then output has length N.  
 * FFT_PACK is fast for input for which the input length can be  decomposed into small factors.
 * </p>    
 * <p>
 * Use FFT_PACK when the input has a length which can be decomposed into small factors.  
 * However, if the length of input has large prime factors, use FFT instead.
 * Also, if the input length is a power of two, use FFT instead.  
 * </p>
 * <p>
 * The inverse transform is IFFT_PACK.  
 * It transforms complex input to complex output. 
 * If input has length N then output has length N.     
 * Note that the output of IFFT_PACK is not normalized.    
 * To normalize, divide by the length of the input: signal = IFFT_PACK(FFT_PACK(signal))/(signal.size)
 * </p>
 *
 * @jalias FFT_PACK
 *
 * @jsynopsis
 *  y = FFT_PACK(x)
 *  
 * @jparameter <x>, INPUT, Complex1d, MANDATORY
 *  Complex1d arrays only.
 *
 * @jparameter <y>, OUTPUT, Complex1d
 *   Returns a Complex1d
 *  
 *  @jexample Apply FFT_PACK to an asymmetric signal
 *  from java.lang.Math import PI
 *
 *  # Frequency modulated signal: parameters
 *  ts = 1E-6          # Sampling period (sec)
 *  fc = 200000        # Carrier frequency (Hz)
 *  fm = 2000          # Modulation frequency (Hz)
 *  beta = .0003       # Modulation index (Hz)
 *  n = 5000           # Number of samples
 *
 *  # Create signal in complex form
 *  t = Double1d.range(n) * ts
 *  signal = SIN(2 * PI * fc * t * (1 + beta * COS(2 * PI * fm * t)))
 *  z_signal=Complex1d(signal)
 *
 *  # Get spectrum
 *  spectrum = ABS(FFT_PACK(z_signal))
 *
 *  # Repeat with apodizing
 *  z_signal=Complex1d(HAMMING(signal))
 *  spectrum2 = ABS(FFT_PACK(z_signal))
 *
 *@jexample Show how to get equivalent results with FFT and FFT_PACK, IFFT and IFFT_PACK  
 * N= 1000
 * signal = Complex1d(Double1d.range(N), Double1d.range(N))
 * 
 * # Transform signal using FFT and FFT_PACK
 * spec_fft = FFT(signal)
 * spec_fft_pack = FFT_PACK(signal)
 * 
 * # Compare results of transformations 
 * print "The maximum absolute difference between FFT and FFT_PACK spectra: "
 * print MAX(ABS(spec_fft-spec_fft_pack))
 * 
 * # Recreate signal with inverse transforms
 * recreatedSignal_fft = IFFT(spec_fft)
 * # Normalize recreated signal from FFT_PACK for comparison with FFT
 * recreatedSignal_fft_pack = IFFT_PACK(spec_fft_pack)/N
 * 
 * # Compare results of inverse transformations 
 * print "The maximum absolute difference signals recreated using IFFT and IFFT_PACK: "
 * print MAX(ABS(recreatedSignal_fft-recreatedSignal_fft_pack))
 *
 *
 * @jcategory
 *  Mathematics/Signal processing
 *
 * @miscellaneous
 * This is implemented for Complex1d arrays only.
 *
 * @jref um:sec-integral-transforms
 * @jref herschel.ia.numeric.toolbox.xform.FFT
 * @jref herschel.ia.numeric.toolbox.xform.util.RealDoubleFFT
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_EVEN
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_ODD
 *
 * @author Trevor Fulton
 * 
 * Change Log:
 * 2011-06-24 PK [HCSS-12037] Updated URM entry.
 * 2011-07-19 PK [HCSS-12037] Made URM title consistent with other titles in the package.
 * 2012-07-23 TRF [HCSS-15868] Fix: Hide Utility Class Constructor violations.
 */
public class FFT_PACK {

    /**
     * Returns a function that computes the forward Fourier Transform
     * using FFT_PACK.
     */
    public final static ArrayProcedure FFT_PACK = new AbstractArrayProcedure() {
        /**
         * Apply FFT_PACK function to Complex1d. This function performs the real forward fourier transform.
         *
         * @param array Complex data to be transformed
         * @return Result of transform
         */
        public final Complex1d mutate(Complex1d array) {
            return fft_pack(array);
        }
    };

    /**
     * Returns a function that computes the reverse Fourier Transform
     * using FFT_PACK.
     */
    public final static ArrayProcedure IFFT_PACK = new AbstractArrayProcedure() {
        /**
         * Apply FFT_PACK function to Complex1d. This function performs the real forward fourier transform.
         *
         * @param array Complex data to be transformed
         * @return Result of transform
         */
        public final Complex1d mutate(Complex1d array) {
            return ifft_pack(array);
        }

    };

    //
    // Make it so the class cannot be instantiated.
    //
    private FFT_PACK() {
        throw new UnsupportedOperationException();
    }

    /**
     * Compute the forward Fourier Transform of a Complex array using FFT_PACK.
     *
     * @param array Complex1d Input array
     * @return Complex1d Output array
     */
    public static Complex1d fft_pack(Complex1d array) {
        Complex1d result;
        int n = array.length();

        ComplexDoubleFFT cdfft = new ComplexDoubleFFT(array.getSize());
        Complex1D postTransform = new Complex1D();
        postTransform.setX(array.realArray());
        postTransform.setY(array.imagArray());
        cdfft.ft(postTransform);

        double[] x;
        double[] y;
        x = postTransform.getX();
        y = postTransform.getY();
        result = new Complex1d(x, y);
        return result;
    }

    /**
     * Compute the reverse Fourier Transform of a Complex array using FFT_PACK.
     *
     * @param array Complex1d Input array
     * @return Complex1d Output array
     */
    public static Complex1d ifft_pack(Complex1d array) {
        Complex1D c = new Complex1D();
        Complex1d result;
        c.setX(array.getReal().getArray());
        c.setY(array.getImag().getArray());
        int n = array.getSize();

        ComplexDoubleFFT cdfft = new ComplexDoubleFFT(n);
        cdfft.bt(c);

        result = new Complex1d(c.getX(), c.getY());
        return result;
    }
}
