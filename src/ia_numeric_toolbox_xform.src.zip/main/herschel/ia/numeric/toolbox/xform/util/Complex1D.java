/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: Complex1D.java,v 1.6 2012/06/28 22:01:18 tfulton Exp $
 *
 * Copyright (c) 2006 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform.util;

/**
 * Construct a 1-D complex data sequence.
 * @author Baoshe Zhang
 * NOTE: this file should be included into the herschel's extlib and remove from here
 */

public class Complex1D {
    /** The real part of the complex data. */
    private double x[];
    /** The imaginary part of the complex data. */
    private double y[];

    /**
    * Set the real part of complex data.
    * 
    * @param x Real part of complex data.
    */
    public void setX(double[] x) {
        this.x = x;
    }

    /**
    * Get the real part of complex data.
    * 
    * @return Real part of complex data.
    */
    public double[] getX() {
        return this.x;
    }

    /**
    * Set the imaginary part of complex data.
    * 
    * @param y Imaginary part of complex data.
    */
    public void setY(double[] y) {
        this.y = y;
    }

    /**
    * Get the imaginary part of complex data.
    * 
    * @return Imaginary part of complex data.
    */
    public double[] getY() {
        return this.y;
    }
}
