# 
#  This file is part of Herschel Common Science System (HCSS).
#  Copyright 2001-2010 Herschel Science Ground Segment Consortium
# 
#  HCSS is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as
#  published by the Free Software Foundation, either version 3 of
#  the License, or (at your option) any later version.
# 
#  HCSS is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU Lesser General Public License for more details.
# 
#  You should have received a copy of the GNU Lesser General
#  Public License along with HCSS.
#  If not, see <http://www.gnu.org/licenses/>.
# 
# 
# $Id: hamming.py,v 1.3 2010/02/02 10:23:59 hsclib Exp $
# Hamming Example
#
# Author: Trevor Fulton
#

# Try the Hamming window with an ODD number of points
nOdd    = 9
wOdd    = Double1d( nOdd )+1.0
w2Odd   = HAMMING.AMPLITUDE(wOdd) 
specOdd = FFT(Complex1d(w2Odd))

# Inspect the Hamming coefficients and the spectral components 
text = ""
for i in range(len(w2Odd)): text = text + " %0.6f" %(ABS(w2Odd[i]))
print text
text = ""
for i in range(len(specOdd)): text = text + " %0.3f" %((specOdd[i]).getReal())
print text
text = ""
for i in range(len(specOdd)): text = text + " %0.3f" %((specOdd[i]).getImag())
print text

# Try the Hamming window with an EVEN number of points
nEven    = 10
wEven    = Double1d( nEven )+1.0
w2Even   = HAMMING.AMPLITUDE(wEven)
specEven = FFT(Complex1d(w2Even))

# Inspect the Hamming coefficients and the spectral components 
text = ""
for i in range(len(w2Even)): text = text + " %0.6f" %(ABS(w2Even[i]))
print text
text = ""
for i in range(len(specEven)): text = text + " %0.3f" %((specEven[i]).getReal())
print text
text = ""
for i in range(len(specEven)): text = text + " %0.3f" %((specEven[i]).getImag())
print text


