/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: Hamming.java,v 1.12 2012/06/07 22:31:27 tfulton Exp $
 *
 * Copyright (c) 2007 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.Double1d;
import herschel.ia.numeric.toolbox.AbstractRealXdProcedure;
import herschel.ia.numeric.toolbox.xform.Hamming;

/**
 * <p>
 *     <b>Hamming Window Function</b>
 *</p>
 *<p>
 * The discrete Hamming window function is defined as: 
 * <br><br>
 *Hamming[i] = 0.54 + 0.46 * cos(2&#x03C0;( i-&#x03BE; ) / N) <i>(Equation 1)</i>  
 *<pre>
 * where:
 *   <code>Hamming[i]</code> is the value of the Hamming function at array index <code>i</code>, 
 *   where 0&#x2264;i&#x2264;(N-1)
 *   N is the length of the array for which the Hamming function is calculated.  
 *   &#x03BE; is the phase shift, defined as &#x03BE; = N/2.0
 *</pre> 
 *</p>
 *
 *<b>i) Symmetry</b>
 *
 *<p>
 * <i>Equation 1</i> produces a discrete Hamming function with a unique point at index <code>i=0</code>.
 * This asymmetry is because an array with <code>N</code> indices is not centred about index <code>N/2.0</code>.
 * An even length array has an additional unique value at index <code>i= N/2.0</code>, the maximum of the Hamming
 * function.
 * </p>
 * <p>
 * For an odd length array, the maximum of the continuous Hamming function is not sampled.  Instead, there are
 * two maxima located at <code>i=ceiling(N/2.0)</code> and <code>i=floor(N/2.0)</code>.  These
 * maxima will approach the continuous Hamming function maximum as <code>N</code> increases. 
 * </p>
 * 
 *<b>ii) Input and Output</b> 
 *<p>
 *  The <code>Hamming</code> class takes a <code>Double1d</code> or <code>Float1d</code> array as input.  It performs an
 *  element-by-element multiplication of the input array with the discrete Hamming function described
 *  in <i>Equation 1</i>.  Consequently, for an input array of size <code>N</code>, a Hamming function 
 *  with <code>N</code> elements is calculated. 
 *</p>
 *<p>
 * The input array must have length N&#x2265;3.   
 *</p>
 *<p>
 *The output array is a <code>Double1d</code> or <code>Float1d</code> array of length <code>N</code> that contains the 
 *element-by-element multiplication of the input array with the Hamming function.
 *</p>
 *
 *<b>iii) Normalization of the Hamming Function</b>
 *<p>
 * The <code>Hamming</code> class provides the Hamming function with a choice of three different
 * normalizations: AMPLITUDE, AREA, and ENERGY:
 *</p>
 *<ol>
 *<li><b>AMPLITUDE:</b> For even length arrays, the amplitude of the Hamming function at 
 * <code>N/2.0</code> is <code>1.0</code>. 
 * For odd length arrays, there are two maxima located at <code>ceiling(N/2.0)</code> and <code>floor(N/2.0)</code>
 * These maxima have amplitude <code>y = 0.54 + 0.46*cos(&#x03C0;/N)</code>.
 * <p>
 * <br>  
 * Amplitude normalization requires no scaling of output from <i>Equation 1</i>.
 * </p> 
 * <br>
 * <i>Note for odd length arrays:</i> The maximum of a continuous Hamming function is different from the maximum of
 * a discrete Hamming function when the array length is odd.  When discretizing to an odd length array, the maximum
 * of the continuous Hamming function is not sampled.   
 * </li>
 * <br><br>
 *<li><b>AREA:</b> The sum of all values of the Hamming function is equal to <code>N</code>, the number of elements
 * in the input array. <i>Equation 1</i> is multiplied by <code>scale = 1/(0.54)</code> to produce this
 * Hamming function.  
 * </li>
 * <br><br>
 * <li><b>ENERGY:</b> The sum of the squares of all values of the Hamming function is equal to 1.0.
 *  To produce this normalization, the values from <i>Equation 1</i> are multiplied by:  
 *  <code>scale = Math.sqrt(1/((Math.pow(0.54, 2) + Math.pow(0.46, 2)/2.0)*N)</code>
 * </li>
 *</ol>
 *<p>
 * The three normalizations are implemented in three unique, static function object
 * members of the Hamming class.  To apply a normalization in Java or Jython,
 * choose the appropriate function object:
 * </p>
 * <table  border="1" summary="Java and Jython Hamming Normalization Function Objects">
 *    <tr><th>Normalization</th>   <th>Java</th> <th>Jython</th></tr>
 *     <tr><td>Area</td>        <td>Hamming.AREA</td> <td>HAMMING.AREA</td></tr>
 *     <tr><td>Amplitude</td>   <td>Hamming.AMPLITUDE</td> <td>HAMMING.AMPLITUDE</td></tr>
 *     <tr><td>Energy</td>       <td>Hamming.ENERGY</td> <td>HAMMING.ENERGY</td></tr>
 *     <tr><td>Area (legacy)</td>  <td>Hamming.PROCEDURE</td> <td>HAMMING</td></tr>
 *   </table>
 *
 *<p>
 *<b>iv) Java Usage and Examples</b>
 *</p>
 *<p>
 * The Hamming function objects are precreated static objects.  They are typically used as arguments
 * to array objects:
 * <pre>
 * Double1d x = new Double1d(100,1.0); // create array of 100 1's
 * Double1d y = (Double1d)x.apply(Hamming.AREA); 
 * // Hamming function is multiplied with the input array and the results are stored in a new array
 * System.out.println("The Hamming output array has a sum of " + y.reduce(Sum.FOLDR)); 
 * // Sum = 100.0! (AREA normalization)
 *</pre>
 * In the above example, the output array's sum is equal to 100.0 because the AREA normalized 
 * Hamming function was multiplied against an array of 1's 
 * (the output <i>is</i> the AREA normalized Hamming function).
 *</p>
 * <p>
 * An AREA normalized Hamming function can also be applied using
 * the <code>Hamming.PROCEDURE</code> member field:
 * </p>
 * <pre>
 * Double1d x = new Double1d(100,1.0);  // create array of 100 1's
 * Double1d y = (Double1d)x.apply(Hamming.PROCEDURE);   // Apply AREA normalized Hamming function 
 * System.out.println("The Hamming output array has a sum of " + y.reduce(Sum.FOLDR)); // Sum = 100.0!
 * </pre>
 * <p>
 * Here is an example of how to apply an amplitude normalized Hamming function:
 * </p>
 * <pre>
 * //Amplitude normalized example
 * int N =100;
 * Double1d x = new Double1d(N,7.0); // create array of 100 7's
 * Double1d y = (Double1d) x.apply(Hamming.AMPLITUDE); 
 * // Hamming function is multiplied with the input array and the results are stored in a new array
 * System.out.println("The Hamming output array has an amplitude of "+ y.get(N/2) + " at index "+ N/2); 
 * // amplitude of 7.0 at index 50!
 * </pre>
 * To apply an ENERGY normalized Hamming function:
 *  <pre>
 * //Energy normalized example
 * int N =100;
 * Double1d x = new Double1d(N,7.0); // create array of 100 7's
 * Double1d y = (Double1d) x.apply(Hamming.ENERGY); // Multiply by energy normalized Hamming function
 * System.out.println("The Hamming output array has a sum of squares of "+ y.multiply(y).reduce(Sum.FOLDR)); //sum = 49!
 * </pre>
 * 
 * <p>
 * <b>v) Jython Usage and Examples</b>
 * </p>
 * <p>
 * To apply an AREA normalized Hamming function to an array:
 * </p>
 * <pre>
 *   x = Double1d(100,10.0) #create input array filled with 10.0's
 *   y = HAMMING.AREA(x)
 *   # y now contains an area normalized Hamming function (multiplied by 10.0, the original input array value) 
 * </pre>
 * Here is the same AREA normalization using legacy syntax:
 *  <pre>
 *   x = Double1d(100,10.0) #create input array filled with 10.0's
 *   y = HAMMING(x) 
 *   # y now contains an area normalized Hamming function (multiplied by 10.0, the original input array value)
 * </pre>  
 * <p>
 * Here is an AMPLITUDE normalized example:
 * </p>
 * <pre>
 *   x = Double1d(100, 55.3) #create input array filled with 55.3's   
 *   y = HAMMING.AMPLITUDE(x) # multiply AMPLITUDE normalized Hamming function with input array
 * </pre>
 *<p>
 * To apply an ENERGY normalized Hamming function to an array:
 * </p>
 * <pre>
 *   x = Double1d(100, 55.3) #create input array filled with 55.3's   
 *   y = HAMMING.ENERGY(x) # y is now equal to x multiplied by an ENERGY normalized Hamming function 
 * </pre>
 * 
 * 
 * 
 * @jhelp <b>Hamming function</b> for multiplying with input arrays.
 * <p>This function performs an element-by-element multiplication of a input array with a Hamming function
 * having the same number of elements.  The Hamming function is defined by the following equation:
 * <pre>
 * Hamming[i] = 0.54 + 0.46 * cos(2&#x03C0;( i-&#x03BE; ) / N) 
 * 
 * where:
 * 
 *   Hamming[i] is the value of the Hamming function at array index i, where 0&#x2264;i&#x2264;(N-1)
 *   N is the length of the array for which the Hamming function is calculated.  
 *   &#x03BE; is the phase shift, defined as &#x03BE; = N/2.0
 *</pre> 
 * </p>
 * <p>
 * <b>Input:</b><br>
 * The input array should be a <code>Double1d</code> or <code>Float1d</code> and have length N&#x2265;3.
 * </p> 
 * <p>
 * <b>Output:</b><br>
 * The output array is a floating point array of length N that 
 * contains the element-by-element multiplication of the 
 * input array with the Hamming function.
 * </p> 
 * <p>
 * <b>Symmetry:</b><br>
 * This equation produces a Hamming function with a unique point at index <code>i=0</code>. 
 * For even length arrays, the maximum amplitude is located at <code>N/2.0</code>.
 * For odd length arrays, there are two amplitude maxima located at 
 * <code>ceiling(N/2.0)</code> and <code>floor(N/2.0)</code>.
 * </p>
 * 
 *  <p>
 * <b>Syntax:</b><br>
 * To apply an element-by-element multiplication of the array <code>x</code> by the Hamming function, 
 * use any of the following options while coding in Jython:
 * </p>
 * <ol>
 * <li><code>p = HAMMING(x) #Area normalized</code></li>
 * <li><code>p = HAMMING.AREA(x) #Area normalized, alternative syntax</code></li>
 * <li><code>q = HAMMING.AMPLITUDE(x) #Amplitude normalized</code> </li>
 * <li><code>r = HAMMING.ENERGY(x) #Energy normalized</code> </li>
 * </ol>
 * 
 * @jalias HAMMING
 *
 * @jsynopsis
 *  <y>=HAMMING.[<normalization> = AREA|AMPLITUDE|ENERGY] (<x>)
 *  
 * @jparameter x, INPUT, Double1d or Float1d, MANDATORY, No default value
 *  The input array to be multiplied by the Hamming function.
 *
 * @jparameter y, OUTPUT, Double1d or Float1d, OPTIONAL, No default value
 * Outputs an array containing the element-by-element 
 * multiplication of the input array with the Hamming function.
 * 
 * @jparameter normalization, INPUT, <AMPLITUDE|ENERGY|AREA|PROCEDURE>, OPTIONAL, No default value
 * The type of normalization of the Hamming function.
 * 
 * @jexample Apply Hamming function to an input array x.
 * x = Double1d(100,1.0)
 * p = HAMMING(x) #Area normalized
 * p2 = HAMMING.AREA(x) #Area normalized, alternative syntax
 * q = HAMMING.AMPLITUDE(x) #Amplitude normalized
 * r = HAMMING.ENERGY(x) #Energy normalized
 *
 * @jcategory Mathematics/Signal processing
 *  
 * @jlimitation This function on operates on <code>Double1d</code> and <code>Float1d</code> arrays.
 * It does not work for <code>Complex1d</code> arrays.
 *  
 * @jref
 *  herschel.ia.numeric.toolbox.xform.Hamming
 *  
 * @jhistory 
 * 2007-Nov-23 (ZW) First version.
 *
 * @author Jon Brumfitt, Trevor Fulton, Zhaohan Weng
 *
 * Change Log:
 * 2007-Nov-23 (ZW) Added two new types of normalization.
 *                  Changed the private constructor to take in one String parameter
 *                  in order to have 3 types of normalization of the window functions.
 *                  Changed some javadoc.
 * 2008-Mar-07  (PK) Added static PROCEDURE member, modified n2 division and refactored.
 *   		     Used double to calculate n2 peak of the Hamming function thus affecting the symmetry of function.
 * 2008-Mar-13  (PK) Changed to use a unique static member for each normalization.
 * 2010-Sep-10  (DS) [SPIRE-2250] Separated change log and jhistory.
 * 2010-Dec-04 (TRF) [HCSS-11857] Fixed jexample
 *                   
 */
public final class Hamming extends AbstractRealXdProcedure {

    /**
     * A unique function object to compute the element-by-element
     * multiplication of an input array with the amplitude normalized Hamming function.
     */
    public final static AbstractRealXdProcedure AMPLITUDE = new AbstractRealXdProcedure() {
        public Double1d mutate(Double1d x) {
            return applyUnitAmplitudeHamming(x);
        }
    };

    /**
     * A unique function object to compute the element-by-element
     * multiplication of an input array with the energy normalized Hamming function.
     */
    public final static AbstractRealXdProcedure ENERGY = new AbstractRealXdProcedure() {
        public Double1d mutate(Double1d x) {

            //Here's a table to find out the real scale for the function:
            // output sum = Sum([Hanning(Double1d(N)+1)]^2)
            //====================================================================|
            //  scale used | # samples | output sum | expected sum |  real scale  |
            //-------------|-----------|------------|--------------|--------------|
            //  1.0        |   10      |  3.75      |   1.0        | 1/sprt(3.75) |
            //-------------|-----------|------------|--------------|--------------|
            //  1.0        |   100     |  37.5      |   1.0        | 1/sprt(37.5) |
            //-------------|-----------|------------|--------------|--------------|
            //  1.0        |   1000    |  375       |   1.0        | 1/sprt(375)  |
            //====================================================================|
            //since the output sum is x times than the expected sum, so the
            //real scale to get the expected sum will just be 1 / sprt(output sum),
            //for each # of sample, these real scales are tested.
            //The general scale formula will be easy to find,
            //Formula: real scale = 1 / sprt(3.75) * sqrt(10 / n);
            //eg. when n = 10 , where n = # samples;
            //real scale = 1 / sprt(3.75) * sqrt(10 / 10) = 1/sprt(3.75);
            //when n = 100
            //real scale = 1 / sprt(3.75) * sqrt(10 / 100) = 1/sprt(37.5);
            //both formula match the result from the table.
            //so simplied formula is scale = 10.0 / (Math.sqrt(37.5 * n));
            //since this formula involves the # of samples, so the formula can
            //apply to both odd and even # of samples.

            //Formula : scale = SQRT(1 / ([alpha^2 + ((1-alpha)^2/2)] * n)));
            double scale = Math.sqrt(1 / ((Math.pow(alpha, 2) + Math.pow(1 - alpha, 2) / 2.0) * (x
                    .getSize())));
            return applyUnitAmplitudeHamming(x).multiply(scale);
        }
    };

    /**
     * <p>
     * The only Hamming object.  It applies an area normalizing Hamming function and
     * has three static members that can be used to apply other normalizations:
     * </p>
     * <ol>
     * <li>AREA - applies area normalization</li>
     * <li>AMPLITUDE - applies amplitude normalization</li>
     * <li>ENERGY - applies energy normalization</li>
     * </ol>
     */
    public final static Hamming PROCEDURE = new Hamming();

    /**
     * An alias to the area normalizing function object so that one
     * may access it by using Hamming.AREA or Hamming.PROCEDURE.AREA
     */
    public final static AbstractRealXdProcedure AREA = PROCEDURE;

    //Factor used to calculate Hamming function 
    //(used for unnormalized magnitude and y offset)
    private static final double alpha = 0.54;

    //Cannot create this object - only static object available
    private Hamming() {
    }

    /**
     * Multiplies the input array by a Hamming function that 
     * is normalized to have a maximum amplitude of 1.  This
     * is the "natural" normalization of the Hamming function 
     * - it requires no scaling.   
     * 
     * @param x The array which is to be multiplied by a unit amplitude Hamming function
     * @return The array multiplied by the Hamming function
     */
    public static Double1d applyUnitAmplitudeHamming(Double1d x) {
        double[] array = x.getArray();
        //get length of array
        double n = x.length();
        //get midpoint of array 
        // (The peak of the Hamming function is at this point)
        double n2 = n / 2.0;

        //angular frequency
        double t = 2.0 * Math.PI / n;

        //Multiply array by amplitude normalized Hamming function
        for (int i = 0; i < n; i++) {
            array[i] *= alpha + (1.0 - alpha) * Math.cos((i - n2) * t);
        }
        return x;
    }

    /**
     * Apply the area normalized Hamming function to the input array.
     * @param x The array which is to be multiplied by an area normalized Hamming function
     * @return  The array multiplied by the Hamming function
     */
    public Double1d mutate(Double1d x) {
        double scale = 1.0 / alpha;
        return applyUnitAmplitudeHamming(x).multiply(scale);
    }
}
