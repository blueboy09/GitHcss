/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: FFT_PACK_ODD.java,v 1.9 2012/07/23 22:24:27 tfulton Exp $
 *
 * Copyright (c) 2011 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.Double1d;
import herschel.ia.numeric.toolbox.AbstractArrayProcedure;
import herschel.ia.numeric.toolbox.ArrayProcedure;
import herschel.ia.numeric.toolbox.xform.util.RealDoubleFFT_Odd;

/**
 * Gives the Discrete Sine Transform (DST) using an FFT_PACK algorithm.  
 *
 * @jhelp Gives the Discrete Sine Transform (DST) of real data.
 * <p>       
 * FFT_PACK_ODD transforms real input into imaginary output.  
 * It is equivalent to the DFT of data with odd symmetry of the form 
 * (0, x<sub>0</sub>, x<sub>1</sub>, ..., x<sub>N-1</sub>, 0, -x<sub>N-1</sub>, ..., -x<sub>0</sub>).
 * </p>
 * <p>
 * DST(x<sub>0</sub>, ...,x<sub>N-1</sub>) is equivalent to -FFT 
 * (0, x<sub>0</sub>, x<sub>1</sub>, ..., x<sub>N-1</sub>, 0, -x<sub>N-1</sub>, ..., -x<sub>1</sub>).
 * </p>
 * If input has length N then output has length N.  
 * FFT_PACK_ODD is fast for input lengths for which the input length plus 1 can be  decomposed into small factors.
 * </p>    
 * <p>
 * Use FFT_PACK_ODD to quickly calculate the FFT of data with odd symmetry.  
 * However, if the length of input plus 1 has large prime factors, use FFT instead.  
 * </p>
 * <p>
 * The inverse transform is IFFT_PACK_ODD.  
 * It transforms imaginary input to real output. 
 * If input has length N then output has length N.     
 * Note that the output of IFFT_PACK_ODD is not normalized.    
 * To normalize, divide by the size of the extended sequence: 
 * signal = IFFT_PACK_ODD(FFT_PACK_ODD(signal))/(signal.size*2+2)
 *</p>
 *
 * @jalias FFT_PACK_ODD
 *
 *
 * @jexample A comparison of the FFT of odd real input with the FFT_PACK_ODD of (approximately) half the input.
 * 
 * from java.lang.Math import PI 
 * 
 * # Create an extended signal of beats with odd symmetry and even length.
 * # For the DST to be equivalent to the DFT, the extended signal must 
 * # have odd symmetry of the form (0, x0, x1, ..., x(N-1), 0, -x(N-1), ..., -x0). 
 * # Equivalence between DST and DFT: DST(x0, ...,x(N-1)) equals -DFT(0, x0, x1, ..., x(N-1), 0, -x(N-1), ..., -x0).
 * # Note that this means that the extended (odd) sequence has even length. 
 * 
 * deltaX = 0.25                # Spatial interval between samples  
 * N_extended = 60              # Length of extended signal (must have even length)
 * N = N_extended/2 -1          # Length of input to FFT_PACK_ODD 
 * periods = 2                  # Number of periods in signal
 * beats = 20                   # Secondary oscillations 
 * amplitude = 100.0            # amplitude of signal
 * x = Double1d.range(N_extended)*deltaX  # abscissa
 * extendedSignal = amplitude*SIN(2*PI*periods/N_extended/deltaX*x)*COS(2*PI*periods*beats/deltaX/N_extended*x)
 * 
 * # Calculate FT of extendedSignal using FFT (discard zero and negative frequencies)
 * spec_fft = FFT(Complex1d(extendedSignal))[1:N+1]
 * 
 * # Calculate spectrum from half of the extended signal using FFT_ODD
 * # Note that the zeros (at element 0 and element N+1) from the extended signal are not used as input to the DST.
 * # A completely imaginary spectrum has no zero frequency term.
 * signal = extendedSignal[1:N+1] 
 * spec_odd = FFT_PACK_ODD(signal)
 * 
 * # Compare FFT output with FFT_PACK_ODD output
 * print "Maximum sum between FFT and FFT_PACK_ODD:"
 * print MAX(ABS(spec_fft.imag + spec_odd))
 * 
 * # Recreate signal from spectrum 
 * # Note that the recreated signal is normalized by the length 
 * # of the *extended* signal (which is 2*N+2)
 * recreatedSignal = IFFT_PACK_ODD(spec_odd)/(extendedSignal.size)
 * print "Maximum absolute difference between signal and recreated signal:"
 * print MAX(ABS(signal-recreatedSignal))  
 * 
 * # Compare extended signals
 * extendedRecreatedSignal = Double1d([0]).append(recreatedSignal).append(0).append(-REVERSE(recreatedSignal))
 * print "Maximum absolute difference between extended signal and extended recreated signal:"
 * print MAX(ABS(extendedSignal-extendedRecreatedSignal))
 * 
 * @jsynopsis
 *  <y> = FFT_PACK_ODD(<x>)
 *  
 * @jparameter x, INPUT, Double1d, MANDATORY
 *  The input for the discrete sine transform.
 *
 * @jparameter y, OUTPUT, Double1d, MANDATORY
 *  The discrete sine transform of the input array.
 *
 * @jcategory
 *  Mathematics/Signal processing
 *
 * @jmiscellaneous
 * The discrete sine transformation produces output that assumes the input, if extended, has odd symmetry.
 * This DST with input size N is equivalent to a discrete Fourier transform (DFT) of the same input 
 * extended to have 2N + 2 real numbers with odd symmetry. 
 * 
 * @jlimitation
 * FFT_PACK_ODD only transforms Double1d input.    
 *
 * @jref um:sec-integral-transforms
 * @jref herschel.ia.numeric.toolbox.xform.FFT
 * @jref herschel.ia.numeric.toolbox.xform.util.RealDoubleFFT
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_EVEN
 * 
 * @author Trevor Fulton
 * 
 * Change Log:
 * 2011-06-24 PK [HCSS-12037] Updated URM entry.
 * 2011-07-19 PK [HCSS-12037] Made URM title consistent with other titles in the package.
 * 2012-07-23 TRF [HCSS-15868] Fix: Hide Utility Class Constructor violations.
 */
public class FFT_PACK_ODD {

    /**
     * The Forward FFT_PACK procedure.
     */
    public final static ArrayProcedure FFT_PACK_ODD = new AbstractArrayProcedure() {

        /**
         * Apply FFT_PACK_ODD function to Double1d. This function performs the 
         * forward sine transform for even input data.
         *
         * @param array Real data to be transformed
         * @return Result of transform
         */
        public final Double1d mutate(Double1d array) {
            return fft_pack_odd(array);
        }
    };

    /**
     * The Reverse FFT_PACK procedure.
     */
    public final static ArrayProcedure IFFT_PACK_ODD = new AbstractArrayProcedure() {

        /**
         * Apply FFT_PACK_ODD function to Double1d. This function performs the 
         * forward sine transform for even input data.
         *
         * @param array Real data to be transformed
         * @return Result of transform
         */
        public final Double1d mutate(Double1d array) {
            return ifft_pack_odd(array);
        }
    };

    //
    // Make it so the class cannot be instantiated.
    //
    private FFT_PACK_ODD() {
        throw new UnsupportedOperationException();
    }

    /**
     * Compute the Odd forward FFT.
     * 
     * @param array Array to be transformed.
     * @return Resultant transformation.
     */
    public static Double1d fft_pack_odd(Double1d array) {
        double[] in = array.getArray();

        RealDoubleFFT_Odd rdffto = new RealDoubleFFT_Odd(array.getSize());
        rdffto.ft(in);

        return new Double1d(in);

    }

    /**
     * Compute the Odd reverse FFT.
     * 
     * @param array Array to be transformed.
     * @return Resultant transformation.
     */
    public static Double1d ifft_pack_odd(Double1d array) {
        double[] in = array.getArray();

        RealDoubleFFT_Odd rdffto = new RealDoubleFFT_Odd(array.getSize());
        rdffto.bt(in);

        return new Double1d(in);

    }
}
