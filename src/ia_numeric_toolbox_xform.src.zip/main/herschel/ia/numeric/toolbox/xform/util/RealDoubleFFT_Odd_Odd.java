/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: RealDoubleFFT_Odd_Odd.java,v 1.5 2012/06/08 21:28:57 tfulton Exp $
 *
 * Copyright (c) 2006 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */

package herschel.ia.numeric.toolbox.xform.util;

/**
 * sine FFT transform with odd wave numbers.
 * @author Baoshe Zhang
 * NOTE: this file should be included into the herschel's extlib and remove from here
 */

public class RealDoubleFFT_Odd_Odd extends RealDoubleFFT_Even_Odd {
    /**
     * <em>norm_factor</em> can be used to normalize this FFT transform. This is because
     * a call of forward transform (<em>ft</em>) followed by a call of backward transform
     * (<em>bt</em>) will multiply the input sequence by <em>norm_factor</em>.
     */

    /**
     * Construct a wavenumber table with size n.
     * The sequences with the same size can share a wavenumber table. The prime
     * factorization of <em>n</em> together with a tabulation of the trigonometric functions
     * are computed and stored.
     *
     * @param  n  the size of a real data sequence. When <em>n</em> is a multiplication of small
     * numbers (4, 2, 3, 5), this FFT transform is very efficient.
     */
    public RealDoubleFFT_Odd_Odd(int n) {
        super(n);
    }

    /**
     * Forward FFT transform of quarter wave data. It computes the coeffients in
     * sine series representation with only odd wave numbers.
     *
     * @param x an array which contains the sequence to be transformed. After FFT,
     * <em>x</em> contains the transform coeffients.
     */
    public void ft(double x[]) {
        sinqf(ndim, x, wavetable);
    }

    /**
     * Backward FFT transform of quarter wave data. It is the unnormalized inverse transform
     * of <em>ft</em>.
     *
     * @param x an array which contains the sequence to be tranformed. After FFT, <em>x</em> contains
     * the transform coeffients.
     */
    public void bt(double x[]) {
        sinqb(ndim, x, wavetable);
    }

    /*-----------------------------------------------
       sinqf: forward sine FFT with odd wave numbers.
      ----------------------------------------------*/
    void sinqf(int n, double x[], double wtable[]) {
        int k;
        double xhold;
        int kc;
        int ns2;

        if (n == 1) {
            return;
        }
        ns2 = n / 2;
        for (k = 0; k < ns2; k++) {
            kc = n - k - 1;
            xhold = x[k];
            x[k] = x[kc];
            x[kc] = xhold;
        }
        cosqf(n, x, wtable);
        for (k = 1; k < n; k += 2) {
            x[k] = -x[k];
        }
    }

    /*-----------------------------------------------
       sinqb: backward sine FFT with odd wave numbers.
      ----------------------------------------------*/
    void sinqb(int n, double x[], double wtable[]) {
        int k;
        double xhold;
        int kc;
        int ns2;

        if (n <= 1) {
            x[0] *= 4;
            return;
        }
        ns2 = n / 2;
        for (k = 1; k < n; k += 2) {
            x[k] = -x[k];
        }
        cosqb(n, x, wtable);
        for (k = 0; k < ns2; k++) {
            kc = n - k - 1;
            xhold = x[k];
            x[k] = x[kc];
            x[kc] = xhold;
        }
    }
}
