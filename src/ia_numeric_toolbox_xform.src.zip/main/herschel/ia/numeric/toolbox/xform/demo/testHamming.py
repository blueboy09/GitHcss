# 
#  This file is part of Herschel Common Science System (HCSS).
#  Copyright 2001-2010 Herschel Science Ground Segment Consortium
# 
#  HCSS is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as
#  published by the Free Software Foundation, either version 3 of
#  the License, or (at your option) any later version.
# 
#  HCSS is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU Lesser General Public License for more details.
# 
#  You should have received a copy of the GNU Lesser General
#  Public License along with HCSS.
#  If not, see <http://www.gnu.org/licenses/>.
# 
nOdd = 9
wOdd = Double1d( nOdd )+1.0
w2Odd=HAMMING.AMPLITUDE(wOdd)
specOdd = FFT(Complex1d(w2Odd))
text = ""
for i in range(len(specOdd)): text = text + " %0.3f" %(ABS(specOdd[i]))
print text
text = ""
for i in range(len(w2Odd)): text = text + " %0.6f" %(ABS(w2Odd[i]))
print text

nEven = 10
wEven = Double1d( nEven )+1.0
w2Even=HAMMING.AMPLITUDE(wOdd)
specEven = FFT(Complex1d(w2Even))
text = ""
for i in range(len(specEven)): text = text + " %0.3f" %(ABS(specEven[i]))
print text
text = ""
for i in range(len(w2Even)): text = text + " %0.6f" %(ABS(w2Even[i]))
print text

