/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: FFT.java,v 1.14 2012/07/23 22:24:27 tfulton Exp $
 *
 * Copyright (c) 2001 Jon Brumfitt
 */

package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.Complex;
import herschel.ia.numeric.Complex1d;
import herschel.ia.numeric.toolbox.AbstractArrayProcedure;
import herschel.ia.numeric.toolbox.ArrayProcedure;
import jcuda.jcufft.*;
/**
 * Fast Fourier Transform.
 *
 * @jhelp
 * Gives the Fast Fourier Transform.
 * <p>
 * Note that greater performance may be achieved using the FFT_PACK classes if input 
 * has odd or even symmetry,  or if input is strictly real, 
 * or if the input length can be decomposed into small factors. 
 * </p>
 * 
 * <p>
 * The inverse transform is IFFT.  
 * It transforms complex input to complex output. 
 * If input has length N then output has length N.     
 * The output of IFFT is normalized: signal = IFFT(FFT(signal))
 *</p>
 *
 * @jalias CuFFT
 *
 * @jsynopsis
 *  <y>=CuFFT(<x>)
 *  
 * @jparameter x, INPUT, Complex1d, MANDATORY
 *  Complex1d arrays only.
 *
 * @jparameter y, OUTPUT, Double1d
 *   Returns a Double1d
 *
 * @jexample Apply CuFFT
 *  from java.lang.Math import PI
 *
 *  # Frequency modulated signal: parameters
 *  ts = 1E-6          # Sampling period (sec)
 *  fc = 200000        # Carrier frequency (Hz)
 *  fm = 2000          # Modulation frequency (Hz)
 *  beta = .0003       # Modulation index (Hz)
 *  n = 5000           # Number of samples
 *
 *  # Create signal in complex form
 *  t = Double1d.range(n) * ts
 *  signal = SIN(2 * PI * fc * t * (1 + beta * COS(2 * PI * fm * t)))
 *  z_signal=Complex1d(signal)
 *
 *  # Get spectrum
 *  spectrum = ABS(CuFFT(z_signal))
 *
 *  # Repeat with apodizing
 *  z_signal=Complex1d(HAMMING(signal))
 *  spectrum2 = ABS(CuFFT(z_signal))
 *  
 *  @jexample Recreate signal with CuIFFT
 *  # Create signal
 *  N = 100
 *  signal = Complex1d(Double1d.range(N), Double1d.range(N))
 *  # Recreate signal from spectrum using CuIFFT
 *  recreatedSignal = CuIFFT(FFT(signal)) 
 *  
 *  # Print difference in signal and recreated signal
 *  print "The maximum abs difference between the signal and recreated signal is:"
 *  print MAX(ABS(signal-recreatedSignal))
 *
 * @jcategory Mathematics/Signal processing
 *
 * @miscellaneous
 * This is implemented for Complex1d arrays only.
 * 
 * @jref um:sec-integral-transforms
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK
 * @jref herschel.ia.numeric.toolbox.xform.util.RealDoubleFFT
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_EVEN
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_ODD
 *
 * @author Jon Brumfitt
 * 
 * Change Log:
 * 2011-06-24 PK [HCSS-12037] Updated URM entry.
 * 2012-07-23 TRF [HCSS-15868] Fix: Hide Utility Class Constructor violations.
 * 2013-06-07 modify by yfjin
 */
public class CudaFFT {

    /*
     * This implementation handles arbitrary array sizes reasonably efficiently, using
     * the Chirp-Z transform algorithm. Arrays whose lengths are powers-of-two use
     * a Cooley-Tukey radix-2 decimation-in-time-algorithm.<p>
     *
     * A number of further optimizations could be applied, such as:
     *
     *  - providing optimized transforms for real arrays, exploting symmetry
     *  - optimizing multiplications by trivial twiddle factors
     *  - using radix-4 (and possibly radix-8) DIT algorithm
     *  - using mixed prime radix transforms
     *  - using the Winograd Fourier Transform algorithm
     *  - using mixed DIF-DIT algorithm to avoid bit-shuffling in convolutions
     *  - saving coefficient arrays as part of state of function object
     *
     * Mixed-radix should work well with the Chirp-Z algorithm, since we can
     * then easily pad with zeroes to a lengths involving these factors.
     * e.g. with radix 2 & 3, N=4097 can be padded to 8748 (3^7 * 4) instead of
     *  16384 (8192 * 2).
     */

    /**
     * Returns a function to compute the Fast Fourier Transform.
     */
	//Anonymous Inner Class
    public final static ArrayProcedure CudaFFT = new AbstractArrayProcedure() {
        public final Complex1d mutate(Complex1d array) {
            fft(array);
            return array;
        }
    };

    /**
     * Returns a function to compute the inverse Fast Fourier Transform.
     */
    public final static ArrayProcedure CudaIFFT = new AbstractArrayProcedure() {
        public final Complex1d mutate(Complex1d array) {
            invFft(array);
            return array;
        }
    };


    //
    // Make it so the class cannot be instantiated.
    //
    private CudaFFT() {
        throw new UnsupportedOperationException();
    }

    /**
     * Computes the FFT of a ComplexArray.
     *
     * The best algorithm is selected, according to the array size.
     * 
     * @param array Array to be transformed.
     */
    public static void fft(Complex1d array) {
    	double[] re=array.realArray();
    	double[] im=array.imagArray();
    	int size=array.getSize();
    	double[] outputJCufft=new double[2*size];
    	double[] inputJCufft=new double[2*size];
    	for(int i=0;i<size;i++){
    		inputJCufft[2*i]=re[i];
    		inputJCufft[2*i+1]=im[i];
    	}
        cufftHandle plan = new cufftHandle();
        JCufft.cufftPlan1d(plan, size, cufftType.CUFFT_Z2Z, 1);
        JCufft.cufftExecZ2Z(plan, inputJCufft, outputJCufft, JCufft.CUFFT_FORWARD);
  
        
        for(int i=0;i<size;i++){
        	re[i]=outputJCufft[2*i];
        	im[i]=outputJCufft[2*i+1];
        }
        JCufft.cufftDestroy(plan);
        array.set(new Complex1d(re,im));
        
    }
    

    /**
     * Perform in-place inverse FFT.
     * 
     * @param array Array to be transformed.
     */
    public static void invFft(Complex1d array) {
        double factor = 1D / array.length();
    	double[] re=array.realArray();
    	double[] im=array.imagArray();
    	int size=array.getSize();
    	double[] outputJCufft=new double[size*2];
    	double[] inputJCufft=new double[size*2];
    	for(int i=0;i<size;i++){
    		inputJCufft[2*i]=re[i];
    		inputJCufft[2*i+1]=im[i];
    	}
        cufftHandle plan = new cufftHandle();
        JCufft.cufftPlan1d(plan, size, cufftType.CUFFT_Z2Z, 1);
        JCufft.cufftExecZ2Z(plan, inputJCufft, outputJCufft, JCufft.CUFFT_INVERSE);
           
        for(int i=0;i<size;i++){
        	re[i]=outputJCufft[2*i];
        	im[i]=outputJCufft[2*i+1];
        }
        
        JCufft.cufftDestroy(plan);
        
        array.set(new Complex1d(re,im));
        array.multiply(new Complex(factor, 0));
    }

    /**
     * Discrete Fourier Transform (DFT) by direct calculation.
     *
     * This O(n*n) algorithm provides a reference implementation
     * for validating other implementations.
     * 
     * @param array Array to be transformed.
     */
    public static void dft(Complex1d array) {
        int ns = array.length();
        double[] real = array.realArray();
        double[] imag = array.imagArray();
        double[] ar = new double[ns];
        double[] ai = new double[ns];

        for (int j = 0; j < ns; j++) {
            for (int k = 0; k < ns; k++) {
                double arg = -2 * Math.PI * j * k / (double) ns;
                double wr = Math.cos(arg);
                double wi = Math.sin(arg);
                ar[j] += real[k] * wr - imag[k] * wi;
                ai[j] += imag[k] * wr + real[k] * wi;
            }
        }
        // Finally, copy the result to make it behave like an in-place algorithm.
        for (int j = 0; j < ns; j++) {
            real[j] = ar[j];
            imag[j] = ai[j];
        }
    }

    /**
     * Discrete Fourier Transform (DFT) by direct calculation.<p>
     *
     * This O(n*n) algorithm provides a reference implementation
     * for validating other implementations.
     * 
     * @param array Array to be transformed.
     */
    public static void idft(Complex1d array) {
        int ns = array.length();
        double[] real = array.realArray();
        double[] imag = array.imagArray();
        double[] ar = new double[ns];
        double[] ai = new double[ns];

        for (int j = 0; j < ns; j++) {
            for (int k = 0; k < ns; k++) {
                double arg = 2 * Math.PI * j * k / (double) ns;
                double wr = Math.cos(arg);
                double wi = Math.sin(arg);
                ar[j] += real[k] * wr - imag[k] * wi;
                ai[j] += imag[k] * wr + real[k] * wi;
            }
        }
        // Finally, copy the result to make it behave like an in-place algorithm.
        for (int j = 0; j < ns; j++) {
            real[j] = ar[j];
            imag[j] = ai[j];
        }
    }

    /**
     * FFT of an arbitrary length array, using the Chirp Z Transform.
     * 
     * @param array Array to be transformed.
     */

}
