/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: FFT_PACK_EVEN.java,v 1.9 2012/07/23 22:24:27 tfulton Exp $
 *
 * Copyright (c) 2011 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */
package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.Double1d;
import herschel.ia.numeric.toolbox.AbstractArrayProcedure;
import herschel.ia.numeric.toolbox.ArrayProcedure;
import herschel.ia.numeric.toolbox.xform.util.RealDoubleFFT_Even;

/**
 * Gives the Discrete Cosine Transform (DCT) using an FFT_PACK algorithm.  
 *
 * @jhelp Gives the Discrete Cosine Transform (DCT) of real data.
 * <p>
 * FFT_PACK_EVEN implements the Discrete Cosine Transform (DCT)       
 * FFT_PACK_EVEN transforms real input into real output.  
 * It is equivalent to the DFT of data with even symmetry of the form 
 * (x<sub>0</sub>, x<sub>1</sub>, ..., x<sub>N-2</sub>, x<sub>N-1</sub>, x<sub>N-2</sub>, ..., x<sub>1</sub>).
 * </p>
 * <p>
 * DCT(x<sub>0</sub>, ...,x<sub>N-1</sub>) is equivalent to 
 * FFT(x<sub>0</sub>, x<sub>1</sub>, ..., x<sub>N-2</sub>, x<sub>N-1</sub>, x<sub>N-2</sub>, ..., x<sub>1</sub>).
 * </p>
 * </p>
 * <p>
 * If input has length N then output has length N.  
 * FFT_PACK_EVEN is fast for input lengths for which the input length minus 1 can be  decomposed into small factors.
 * </p>    
 * <p>
 * Use FFT_PACK_EVEN to quickly calculate the FFT of evenly symmetric data.  
 * However, if the length of input minus 1 has large prime factors, use FFT instead.  
 * </p>
 * <p>
 * The inverse transform is IFFT_PACK_EVEN.  
 * It transforms real input to real output. 
 * If input has length N then output has length N.     
 * Note that the output of IFFT_PACK_EVEN is not normalized.    
 * To normalize, divide by the size of the extended sequence: 
 * signal = IFFT_PACK_EVEN(FFT_PACK_EVEN(signal))/(signal.size*2-2)
 *</p>
 *
 * @jalias FFT_PACK_EVEN
 *
 * @jsynopsis
 *  <y> = FFT_PACK_EVEN(<x>)
 *  
 * @jparameter x, INPUT, Double1d, MANDATORY
 * The input for the discrete cosine transform.
 *
 * @jparameter y, OUTPUT, Double1d, MANDATORY
 * The discrete cosine transform of the input array.
 *
 * @jexample Transform a symmetric double-sided interferogram into a spectrum using FFT_PACK and FFT_PACK_EVEN. 
 * from java.lang.Math import PI
 *
 * # Create double-sided interferogram with even symmetry and even length.
 * # For the DCT to be equivalent to the DFT, the extended signal must 
 * # have even symmetry of the form (x0, x1, ....,x(N-2), x(N-1), x(N-2), ..., x1).
 * # That is: DCT(x0, ...,x(N-1)) equals DFT(x0, x1, ...., x(N-2), x(N-1), x(N-2), ..., x1).
 * # Note that this means that the extended (symmetric) sequence has even length.
 * dOpd = 0.25                 # Spatial interval between samples 
 * wingLength = 100            # Number elements in each wing of the interferogram
 * c = 2*Math.PI*0.1           # Opd multiplier 
 * amplitudeAtZpd = 10.0       # The amplitude of the sinc at opd =0
 * opd = Double1d.range(2*wingLength+2)*dOpd- wingLength*dOpd # Optical path difference abscissa
 * extendedSignal = SIN(opd.copy()*c)/opd # Sinc function
 * extendedSignal = extendedSignal*(amplitudeAtZpd /c)
 * extendedSignal[wingLength] = amplitudeAtZpd      # Set value at ZPD to 1.0 (instead of NaN)
 * extendedSignal = SHIFT(extendedSignal,-wingLength) # Shift signal ZPd is the first element
 * 
 * # Calculate FT of extendedSignal using FFT (and discard negative frequencies)
 * spec_fft = FFT(Complex1d(extendedSignal))[0:(extendedSignal.size/2+1)]
 * 
 * # Calculate spectrum from half of the extended signal using FFT_EVEN
 * # (the other part of the signal is redundant given the DCT's implicit assumption of even symmetry)
 * signal = extendedSignal[:(wingLength+2)] 
 * spec_even = FFT_PACK_EVEN(signal)
 * # Compare FFT output with FFT_PACK_EVEN output
 * print "Maximum difference between FFT and FFT_PACK_ODD:"
 * print MAX(ABS(spec_fft -spec_even))
 * 
 * # Recreate signal from spectrum using inverse DCT
 * # Note that the recreated signal is normalized by the length 
 * # of the *extended* signal.
 * recreatedSignal = IFFT_PACK_EVEN(spec_even)/(extendedSignal.size)
 * print "Maximum absolute difference between signal and recreated signal:"
 * print MAX(ABS(signal-recreatedSignal))  
 * 
 * # Compare extended signals (original versus one recreated from a spectrum)
 * extendedRecreatedSignal = SHIFT(recreatedSignal.append( \
 *     REVERSE(recreatedSignal[1:(recreatedSignal.size-1)])), -recreatedSignal.size)
 * print "Maximum absolute difference between extended signal and extended recreated signal:"
 * print MAX(ABS(extendedSignal-extendedRecreatedSignal))
 *
 * @jcategory
 *  Mathematics/Signal processing
 *
 * @jmiscellaneous
 * The discrete cosine transformation produces output that assumes the input, if extended, has even symmetry.
 * The DCT of an input of size N is equivalent to a discrete Fourier transform (DFT) 
 * of the same input extended (with even symmetry) to have 2N - 2 real numbers.   
 * 
 * @jlimitation
 * FFT_PACK_EVEN only transforms Double1d input.    
 *
 * @jref um:sec-integral-transforms
 * @jref herschel.ia.numeric.toolbox.xform.FFT
 * @jref herschel.ia.numeric.toolbox.xform.util.RealDoubleFFT
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_ODD
 * 
 * @author Trevor Fulton
 * 
 * Change Log:
 * 2011-06-24 PK [HCSS-12037] Updated URM entry.
 * 2011-07-19 PK [HCSS-12037] Made URM title consistent with other titles in the package.
 * 2012-07-23 TRF [HCSS-15868] Fix: Hide Utility Class Constructor violations.
 */
public class FFT_PACK_EVEN {
    
    /**
     * The Forward FFT_PACK procedure.
     */
    public final static ArrayProcedure FFT_PACK_EVEN = new AbstractArrayProcedure() {

        /**
         * Apply FFT_PACK_EVEN function to Double1d. This function performs the 
         * forward cosine transform for even input data.
         *
         * @param array Real data to be transformed
         * @return Result of transform
         */
        public final Double1d mutate(Double1d array) {
            return fft_pack_even(array);
        }
    };

    /**
     * Returns a function that computes the reverse Fourier Transform
     * using FFT_PACK.
     */
    public final static ArrayProcedure IFFT_PACK_EVEN = new AbstractArrayProcedure() {
        /**
         * Apply FFT_PACK function to Complex1d. This function performs the 
         * real forward fourier transform.
         *
         * @param array Complex data to be transformed
         * @return Result of transform
         */
        public final Double1d mutate(Double1d array) {
            return ifft_pack_even(array);
        }
    };
    
    //
    // Make it so the class cannot be instantiated.
    //
    private FFT_PACK_EVEN() {
        throw new UnsupportedOperationException();
    }

    /**
     * Compute the Even forward FFT.
     * 
     * @param array Array to be transformed.
     * @return Resultant transformation.
     */
    public static Double1d fft_pack_even(Double1d array) {
        double[] in = array.getArray();

        RealDoubleFFT_Even rdffte = new RealDoubleFFT_Even(array.getSize());
        rdffte.ft(in);

        return new Double1d(in);

    }

    /**
     * Compute the Even reverse FFT.
     * 
     * @param array Array to be transformed.
     * @return Resultant transformation.
     */
    public static Double1d ifft_pack_even(Double1d array) {
        double[] in = array.getArray();

        RealDoubleFFT_Even rdffte = new RealDoubleFFT_Even(array.getSize());
        rdffte.bt(in);

        return new Double1d(in);

    }
}
