/* -*-java-*- script */

/**
 * "Table of Contents" for package:
 * herschel.ia.numeric.toolbox.xform package
 */
{
    // header: required
    TOC.message("xform.start");
    TOC.start();

    // body: here goes your information:
    TOC.title("Numeric Transform Toolbox","doc/index.html");
    TOC.add(new DocLink("DP Numeric Framework","../../index.html",true)); // local path!
    TOC.add(new DocLink("DP Documentation","../doc/index.html",true)); // escape frame!
    TOC.add(new DocSep());

    TOC.add(new DocLocal("CHANGELOG","CHANGELOG"));
    TOC.add(new DocLocal("FFT","doc/xform.html#FFT"));
    TOC.add(new DocLocal("FFT_PACK","doc/xform.html#FFT_PACK"));
    TOC.add(new DocLocal("HAMMING","doc/xform.html#HAMMING"));
    TOC.add(new DocLocal("HANNING","doc/xform.html#HANNING"));
    TOC.add(new DocLocal("IFFT","doc/xform.html#IFFT"));
    TOC.add(new DocLocal("IFFT_PACK","doc/xform.html#IFFT_PACK"));
    TOC.add(new DocSep());

    TOC.add(new DocLocal("Java API","../../../../api/herschel/ia/numeric/toolbox/basic/package-summary.html"));
    TOC.add(new DocChapter("Design Documentation","doc/design.html"));
    TOC.add(new DocChapter("Developer Guide","doc/devel.html"));
    // footer: required
    TOC.end();
    TOC.message("xform.end");
}
