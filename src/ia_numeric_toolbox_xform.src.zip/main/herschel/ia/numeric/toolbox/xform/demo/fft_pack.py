# 
#  This file is part of Herschel Common Science System (HCSS).
#  Copyright 2001-2010 Herschel Science Ground Segment Consortium
# 
#  HCSS is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as
#  published by the Free Software Foundation, either version 3 of
#  the License, or (at your option) any later version.
# 
#  HCSS is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU Lesser General Public License for more details.
# 
#  You should have received a copy of the GNU Lesser General
#  Public License along with HCSS.
#  If not, see <http://www.gnu.org/licenses/>.
# 
#
# $Id: fft_pack.py,v 1.2 2010/02/02 10:23:59 hsclib Exp $
# Demonstration of using the FFT_PACK function.
#
# Author: Trevor Fulton
#
from java.lang.Math import PI

# Frequency modulated signal: parameters
ts = 1E-6          # Sampling period (sec)
fc = 200000        # Carrier frequency (Hz)
fm = 2000          # Modulation frequency (Hz)
beta = .0003       # Modulation index (Hz)
n = 5000           # Number of samples

# Create signal in complex form
t = Double1d.range(n) * ts
signal = SIN(2 * PI * fc * t * (1 + beta * COS(2 * PI * fm * t)))
z_signal=Complex1d(signal)


# Get spectrum
spectrum = ABS(FFT_PACK(z_signal))

# Repeat with apodizing
z_signal=Complex1d(HAMMING(signal))
spectrum2 = ABS(FFT_PACK(z_signal))
