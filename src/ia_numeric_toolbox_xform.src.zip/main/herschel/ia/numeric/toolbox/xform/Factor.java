/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.Long1d;
import herschel.ia.numeric.toolbox.basic.Max;

/**
 * Factor.
 *
 * @jhelp
 * Computes a list of factors for a given long integer.
 *
 * @author Trevor Fulton
 * 
 * Change Log:
 * 2012-06-07 TRF [HCSS-15868] Sonar code review.
 * 2012-07-23 TRF [HCSS-15868] Fix: Hide Utility Class Constructor violations.
 */
public class Factor {

    //
    // Make it so the class cannot be instantiated.
    //
    private Factor() {
        throw new UnsupportedOperationException();
    }

    /**
     * Compute a list of factors for a given long integer.
     * 
     * @param n The long integer to be factored.
     * @return A Long1d() list of the factors for the input n.
     */
    public static Long1d factor(long n) {

        Long1d f = new Long1d();

        // for each potential factor i
        for (long i = 2; i <= n / i; i++) {
            // if i is a factor of N, repeatedly divide it out
            while (n % i == 0) {
                f.append(i);
                n = n / i;
            }
        }
        // if biggest factor occurs only once, n > 1
        if (n > 1) {
            f.append(n);
        }
        return f;
    }

    /**
     * Get the largest factor of a list.
     * 
     * @param in List of factors.
     * @return Maximum value of the list.
     */
    public static long maxFactor(Long1d in) {
        return in.reduce(Max.FOLDR);
    }
}
