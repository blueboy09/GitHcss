/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: FFT.java,v 1.14 2012/07/23 22:24:27 tfulton Exp $
 *
 * Copyright (c) 2001 Jon Brumfitt
 */

package herschel.ia.numeric.toolbox.xform;

import herschel.ia.numeric.Complex;
import herschel.ia.numeric.Complex1d;
import herschel.ia.numeric.Range;
import herschel.ia.numeric.toolbox.AbstractArrayProcedure;
import herschel.ia.numeric.toolbox.ArrayProcedure;
import static  herschel.ia.numeric.toolbox.xform.FFTNumCount.NCfft;
import static  herschel.ia.numeric.toolbox.xform.FFTNumCount.NCifft;
import jcuda.jcufft.*;
/**
 * Fast Fourier Transform.
 *
 * @jhelp
 * Gives the Fast Fourier Transform.
 * <p>
 * Note that greater performance may be achieved using the FFT_PACK classes if input 
 * has odd or even symmetry,  or if input is strictly real, 
 * or if the input length can be decomposed into small factors. 
 * </p>
 * 
 * <p>
 * The inverse transform is IFFT.  
 * It transforms complex input to complex output. 
 * If input has length N then output has length N.     
 * The output of IFFT is normalized: signal = IFFT(FFT(signal))
 *</p>
 *
 * @jalias FFT
 *
 * @jsynopsis
 *  <y>=FFT(<x>)
 *  
 * @jparameter x, INPUT, Complex1d, MANDATORY
 *  Complex1d arrays only.
 *
 * @jparameter y, OUTPUT, Double1d
 *   Returns a Double1d
 *
 * @jexample Apply FFT
 *  from java.lang.Math import PI
 *
 *  # Frequency modulated signal: parameters
 *  ts = 1E-6          # Sampling period (sec)
 *  fc = 200000        # Carrier frequency (Hz)
 *  fm = 2000          # Modulation frequency (Hz)
 *  beta = .0003       # Modulation index (Hz)
 *  n = 5000           # Number of samples
 *
 *  # Create signal in complex form
 *  t = Double1d.range(n) * ts
 *  signal = SIN(2 * PI * fc * t * (1 + beta * COS(2 * PI * fm * t)))
 *  z_signal=Complex1d(signal)
 *
 *  # Get spectrum
 *  spectrum = ABS(FFT(z_signal))
 *
 *  # Repeat with apodizing
 *  z_signal=Complex1d(HAMMING(signal))
 *  spectrum2 = ABS(FFT(z_signal))
 *  
 *  @jexample Recreate signal with IFFT
 *  # Create signal
 *  N = 100
 *  signal = Complex1d(Double1d.range(N), Double1d.range(N))
 *  # Recreate signal from spectrum using IFFT
 *  recreatedSignal = IFFT(FFT(signal)) 
 *  
 *  # Print difference in signal and recreated signal
 *  print "The maximum abs difference between the signal and recreated signal is:"
 *  print MAX(ABS(signal-recreatedSignal))
 *
 * @jcategory Mathematics/Signal processing
 *
 * @miscellaneous
 * This is implemented for Complex1d arrays only.
 * 
 * @jref um:sec-integral-transforms
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK
 * @jref herschel.ia.numeric.toolbox.xform.util.RealDoubleFFT
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_EVEN
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_ODD
 *
 * @author Jon Brumfitt
 * 
 * Change Log:
 * 2011-06-24 PK [HCSS-12037] Updated URM entry.
 * 2012-07-23 TRF [HCSS-15868] Fix: Hide Utility Class Constructor violations.
 */
public class FFT {

    /*
     * This implementation handles arbitrary array sizes reasonably efficiently, using
     * the Chirp-Z transform algorithm. Arrays whose lengths are powers-of-two use
     * a Cooley-Tukey radix-2 decimation-in-time-algorithm.<p>
     *
     * A number of further optimizations could be applied, such as:
     *
     *  - providing optimized transforms for real arrays, exploting symmetry
     *  - optimizing multiplications by trivial twiddle factors
     *  - using radix-4 (and possibly radix-8) DIT algorithm
     *  - using mixed prime radix transforms
     *  - using the Winograd Fourier Transform algorithm
     *  - using mixed DIF-DIT algorithm to avoid bit-shuffling in convolutions
     *  - saving coefficient arrays as part of state of function object
     *
     * Mixed-radix should work well with the Chirp-Z algorithm, since we can
     * then easily pad with zeroes to a lengths involving these factors.
     * e.g. with radix 2 & 3, N=4097 can be padded to 8748 (3^7 * 4) instead of
     *  16384 (8192 * 2).
     */

    /**
     * Returns a function to compute the Fast Fourier Transform.
     */
	//Anonymous Inner Class
	static boolean useGPU =false;
    public final static ArrayProcedure FFT = new AbstractArrayProcedure() {
        public final Complex1d mutate(Complex1d array) {
            fft(array);
            return array;
        }
        
    };

    /**
     * Returns a function to compute the inverse Fast Fourier Transform.
     */
    public final static ArrayProcedure IFFT = new AbstractArrayProcedure() {
        public final Complex1d mutate(Complex1d array) {
            invFft(array);
            return array;
        }
    };


    //
    // Make it so the class cannot be instantiated.
    //
    private FFT() {
        throw new UnsupportedOperationException();
    }

    /**
     * Computes the FFT of a ComplexArray.
     *
     * The best algorithm is selected, according to the array size.
     * 
     * @param array Array to be transformed.
     */
    public static void fft(Complex1d array) {
    	if(useGPU==false){
	        int nu = log2(array.length()); // Negative if ns is not a power of two
	        
	        if (nu >= 0) {
	            cooleyTukeyFft(array);
	        } else {
	            chirpZFft(array);
	        }
    	}
    	else{
        	double[] re=array.realArray();
        	double[] im=array.imagArray();
        	int size=array.getSize();
        	double[] outputJCufft=new double[2*size];
        	double[] inputJCufft=new double[2*size];
        	for(int i=0;i<size;i++){
        		inputJCufft[2*i]=re[i];
        		inputJCufft[2*i+1]=im[i];
        	}
            cufftHandle plan = new cufftHandle();
            JCufft.cufftPlan1d(plan, size, cufftType.CUFFT_Z2Z, 1);
            JCufft.cufftExecZ2Z(plan, inputJCufft, outputJCufft, JCufft.CUFFT_FORWARD);
      
            
            for(int i=0;i<size;i++){
            	re[i]=outputJCufft[2*i];
            	im[i]=outputJCufft[2*i+1];
            }
            JCufft.cufftDestroy(plan);
            array.set(new Complex1d(re,im));
//            System.out.println("use GPU calculate");
    	}
        FFTNumCount.FFTCount(NCfft);
        FFTNumCount.FFTDtlCount(NCfft, array.getDimension(0));
        
    }
    

    /**
     * Perform in-place inverse FFT.
     * 
     * @param array Array to be transformed.
     */
    public static void invFft(Complex1d array) {
    	if(useGPU==false){
	        /*
	         * This could be speeded up slightly by passing an argument to the
	         * FFT method, instead of modifying the result of a forward FFT.
	         */
	        double factor = 1D / array.length();
	        array.conjugate();
	        fft(array);
	        array.conjugate();
	        array.multiply(new Complex(factor, 0));
	        FFTNumCount.FFTCount(NCifft);
	        FFTNumCount.FFTDtlCount(NCifft, array.getDimension(0));
	        // because in fact, ifft would call the function fft. So we need correct the repeat count
	        FFTNumCount.FFTCorrect(NCfft);
	        FFTNumCount.FFTDtlCorrect(NCfft, array.getDimension(0));
    	}
    	else{
            double factor = 1D / array.length();
        	double[] re=array.realArray();
        	double[] im=array.imagArray();
        	int size=array.getSize();
        	double[] outputJCufft=new double[size*2];
        	double[] inputJCufft=new double[size*2];
        	for(int i=0;i<size;i++){
        		inputJCufft[2*i]=re[i];
        		inputJCufft[2*i+1]=im[i];
        	}
            cufftHandle plan = new cufftHandle();
            JCufft.cufftPlan1d(plan, size, cufftType.CUFFT_Z2Z, 1);
            JCufft.cufftExecZ2Z(plan, inputJCufft, outputJCufft, JCufft.CUFFT_INVERSE);
               
            for(int i=0;i<size;i++){
            	re[i]=outputJCufft[2*i];
            	im[i]=outputJCufft[2*i+1];
            }
            
            JCufft.cufftDestroy(plan);
//            System.out.println("use GPU calculate");            
            array.set(new Complex1d(re,im));
            array.multiply(new Complex(factor, 0));
            
    		FFTNumCount.FFTCount(NCifft);
	        FFTNumCount.FFTDtlCount(NCifft, array.getDimension(0));
    	}
    }

    /**
     * Discrete Fourier Transform (DFT) by direct calculation.
     *
     * This O(n*n) algorithm provides a reference implementation
     * for validating other implementations.
     * 
     * @param array Array to be transformed.
     */
    public static void dft(Complex1d array) {
        int ns = array.length();
        double[] real = array.realArray();
        double[] imag = array.imagArray();
        double[] ar = new double[ns];
        double[] ai = new double[ns];

        for (int j = 0; j < ns; j++) {
            for (int k = 0; k < ns; k++) {
                double arg = -2 * Math.PI * j * k / (double) ns;
                double wr = Math.cos(arg);
                double wi = Math.sin(arg);
                ar[j] += real[k] * wr - imag[k] * wi;
                ai[j] += imag[k] * wr + real[k] * wi;
            }
        }
        // Finally, copy the result to make it behave like an in-place algorithm.
        for (int j = 0; j < ns; j++) {
            real[j] = ar[j];
            imag[j] = ai[j];
        }
    }

    /**
     * Discrete Fourier Transform (DFT) by direct calculation.<p>
     *
     * This O(n*n) algorithm provides a reference implementation
     * for validating other implementations.
     * 
     * @param array Array to be transformed.
     */
    public static void idft(Complex1d array) {
        int ns = array.length();
        double[] real = array.realArray();
        double[] imag = array.imagArray();
        double[] ar = new double[ns];
        double[] ai = new double[ns];

        for (int j = 0; j < ns; j++) {
            for (int k = 0; k < ns; k++) {
                double arg = 2 * Math.PI * j * k / (double) ns;
                double wr = Math.cos(arg);
                double wi = Math.sin(arg);
                ar[j] += real[k] * wr - imag[k] * wi;
                ai[j] += imag[k] * wr + real[k] * wi;
            }
        }
        // Finally, copy the result to make it behave like an in-place algorithm.
        for (int j = 0; j < ns; j++) {
            real[j] = ar[j];
            imag[j] = ai[j];
        }
    }

    /**
     * FFT of an arbitrary length array, using the Chirp Z Transform.
     * 
     * @param array Array to be transformed.
     */
    public static void chirpZFft(Complex1d array) {
        int ns = array.length();
        int n = nextPowerOfTwo(2 * ns);

        // The numbers in the margin show approximate split of time (length = 4096).
        Complex1d pz = chirpFactors(ns, n); // 680

        Complex1d z2 = new Complex1d(n);
        Range r = new Range(0, ns);
        z2.set(r, array).multiply(pz).perform(FFT).as().complex1d()
                .multiply(pz.copy().conjugate().perform(FFT).as().complex1d()).perform(IFFT).as()
                .complex1d().multiply(pz);

        // Because chripZFft ,in fact, use three times cooleyTukeyFft, We need correct the repeat count
        FFTNumCount.FFTCorrect(NCfft);
        FFTNumCount.FFTDtlCorrect(NCfft, z2.getDimension(0));
        FFTNumCount.FFTCorrect(NCfft);
        FFTNumCount.FFTDtlCorrect(NCfft, z2.getDimension(0));
        FFTNumCount.FFTCorrect(NCifft);
        FFTNumCount.FFTDtlCorrect(NCifft, z2.getDimension(0));
        
        // Now copy the the first 'ns' elements as the result.
        array.set(r, z2.get(r)); // ~0
        // = 2330
        
        
    }

    /**
     * Return the Chirp Z transform coefficients.
     * 
     * @param ns Array length.
     * @param n Next power of two.
     * @return Chirp Z transform coefficients.
     */
    private static Complex1d chirpFactors(int ns, int n) {
        double[] pr = new double[n];
        double[] pi = new double[n]; // 120
        pr[0] = 1;
        pi[0] = 0;
        for (int i = 1; i < ns; i++) { // 560
            double arg = -Math.PI * i * i / (double) ns;
            double c = Math.cos(arg);
            double s = Math.sin(arg);
            pr[i] = c;
            pi[i] = s;
            pr[n - i] = c;
            pi[n - i] = s;
        }
        return new Complex1d(pr, pi);
    }

    /**
     * Cooley-Tukey radix-2 in-place Decimation-in-Time FFT.<p>
     *
     * The FFT is performed in-place, overwriting the original array.
     * 
     * @param array Array to be transformed.
     */
    public static void cooleyTukeyFft(Complex1d array) {
        int ns = array.length();
        int nu = log2(ns);
        double[] real = array.realArray();
        double[] imag = array.imagArray();
        cooleyTukeyFft(real, imag, ns, nu);
    }

    /**
     * Cooley-Tukey radix-2 in-place Decimation-in-Time FFT.<p>
     *
     * The FFT is performed in-place, overwriting the original array.
     *
     * @param real Array of real parts
     * @param imag Array of imaginary parts
     * @param ns   Length of the array (must be power of 2)
     * @param nu   Log2 of length of the array
     */
    public static void cooleyTukeyFft(double[] real, double[] imag, int ns, int nu) {
        shuffle(real, imag);
        int n2 = 1;
        for (int i = 1; i <= nu; i++) {
            int n = n2;
            n2 += n2;
            double wr = 1.0;
            double wi = 0.0;
            double arg = Math.PI / (double) n;
            double dwr = Math.cos(arg);
            double dwi = Math.sin(arg);
            for (int j = 0; j < n; j++) {
                double tr;
                double ti;
                for (int k = j; k < ns; k += n2) {
                    int z = k + n;
                    tr = real[z] * wr + imag[z] * wi;
                    ti = imag[z] * wr - real[z] * wi;
                    real[z] = real[k] - tr;
                    imag[z] = imag[k] - ti;
                    real[k] += tr;
                    imag[k] += ti;
                }
                tr = wr * dwr - wi * dwi;
                wi = wi * dwr + wr * dwi;
                wr = tr;
            }
        }
    }

    /**
     * In-place shuffle operation for FFT.<p>
     *
     * Assumes length of array is a power of 2.
     * 
     * @param real Real portion of the complex vector.
     * @param imag Imaginary portion of the complex vector.
     */
    private static void shuffle(double[] real, double[] imag) {
        int ns = real.length;
        int n2 = ns >> 1;
        int j = 0;
        for (int i = 0; i < ns - 1; i++) {
            if (i < j) {
                double t = real[i];
                real[i] = real[j];
                real[j] = t;
                t = imag[i];
                imag[i] = imag[j];
                imag[j] = t;
            }
            int k = n2;
            while (k <= j) {
                j -= k;
                k >>= 1;
            }
            j += k;
        }
    }

    /**
     * Return log2(n) if 'n' is a positive power of 2, otherwise return -1.
     * 
     * @param n Integer for which the base2 log is desired.
     * @return log2(n) or -1
     */
    public static int log2(int n) {
        if (n == 0) {
            return -1;
        }
        int k = 0;
        while ((n & 1) == 0) {
            n >>= 1;
            k++;
        }
        if (n != 1) {
            k = -1;
        }
        return k;
    }

    /**
     * Return the smallest power-of-2 >= n.
     * 
     * @param n Number of samples.
     * @return The smallest power-of-2 >= n.
     */
    public static int nextPowerOfTwo(int n) {
        if (n < 1) {
            throw new IllegalArgumentException(
                    "Error in FFT for nextPowerofTwo n must be > 0 but n was: " + n + ".");
        }
        int k = 0;
        int ones = 0;
        while (n > 0) {
            if ((n & 1) == 1) {
                ones++;
            }
            n >>= 1;
            k++;
        }
        if (ones == 1) {
            return 1 << (k - 1);
        } else {
            return 1 << k;
        }
    }
    
    public static void GPU(boolean bl){
    	if(bl==true){
    		useGPU=bl;
    		System.out.println("open GPU to calculate the FFT/IFFT!");
    	}
    	else{
    		useGPU=bl;
    		System.out.println("close GPU to calculate the FFT/IFFT!");
    	}
    }
}
