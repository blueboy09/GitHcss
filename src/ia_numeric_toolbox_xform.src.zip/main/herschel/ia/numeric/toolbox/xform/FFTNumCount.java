package herschel.ia.numeric.toolbox.xform;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;


class FFTPara{
	/**
	 * dim: predefine the space allocate to the _Detail array 
	 *  
	 */
	int dim;
	/**
	 * num: record the used space of the _Detail array
	 */
	int num;
	/**
	 * _Count: the times of the method being called 
	 */
	long _Count;
	/**
	 * the detail Counter
	 */
	long[][] _Detail;
	/**
	 * _para: the name of the subclass
	 */
	String _para;
	/**
	 * construct function
	 * @param _Dim predefine the space allocate to the _Detail array 
	 * @param name the name of the subclass 
	 * 
	 */
	FFTPara(int _Dim,String name){
		num=0;
		dim=_Dim;
		_Count=0;
		_Detail=new long[2][_Dim];
		_para=name;
	}
	/**
	 * Reset the Counter
	 */
	public void ReSet(){
		num=0;
		_Count=0;
		for(int i=0;i<2;i++){
			for(int j=0;j<dim;j++){
				_Detail[i][j] = 0;
			}
		}
				
	}
	
	/**
	 * the counter add one 
	 */
	public void NumCount(){
		_Count+=1;
	}
	
	/**
	 * the counter minus one 
	 */
	public void NumCorrect(){
		_Count-=1;
	}
	
	/**
	 * 
	 * @return the times of being called of the method 
	 */
	public long GetCount(){
		System.out.println("the number of "+_para+": "+ _Count);
		return _Count;
	}
	
	
	
	// this part is used for dimension count
	/**
	 * search whether the data scale have been used before
	 * @param len the data dimension
	 * @return if find the data of this dimension has been counted before,
	 * 			 then return true. 
	 */
	public boolean search(int len){
		boolean flag= false;
		for(int i=0;i<num;i++){
			if(_Detail[0][i]==len){
				flag=true;
				break;
			}
		}
		return flag;
	}
	
	/**
	 * 
	 * 	if the function "search" return true, then use this function. 
	 *  it means this dimension has appeared before, then it appeared again,
	 *  only need calculate once but not add another data kind.
	 *  
	 * @param len: the data scale (dimension)
	 * 
	 */
	
	public void Calculate(int len){
		int point=0;
		for(int i=0;i<num;i++){
			if(_Detail[0][i]==len){
				point=i;
				break;
			}
		}
		_Detail[1][point] = _Detail[1][point]+1;
		
	}

	//because the FFT use chirp-Z method called the Cool-Turkey method, so it would cause  counting overlap. so we need correct.
	/**
	 * this function is used for correct.
	 * 	if the function "search" return true, then use this function. 
	 *  it means this dimension has appeared before, then it appeared again,
	 *  and need be minus once.
	 *  
	 * @param len: the data scale (dimension)
	 * 
	 */
	public void Reduce(int len){
		int point=0;
		for(int i=0;i<num;i++){
			if(_Detail[0][i]==len){
				point=i;
				break;
			}
		}
		_Detail[1][point] = _Detail[1][point]-1;
		
	}
	/**
	 * 
	 * 	this function used when "search" function return false, it means this data kind
	 *  didn't appear before, so we need find a place in the _Detail array 
	 *  to insert the new one.
	 *  
	 * @param len: the data dimension
	 * 
	 * @return the point where need add the new data kind
	 * 
	 * 
	 */
	public int find(int len){
		int point=0;
		while(_Detail[0][point] < len && point < num){
			point++;
		}
		
		return point;
	}
	
	
	/**
	 * 
	 * @param point : the point to insert the new data kind
	 * @param len: the dimension of the new data kind
	 */
	public void insert(int point,int len){
		try {
		 
			if(num == dim) throw new Exception("space is not enough");
			for(int i= num;i>point;i--){
				for(int j=0;j<2;j++){
					_Detail[j][i]=_Detail[j][i-1];
				}
			}
			_Detail[0][point]=len;
			_Detail[1][point]=1;			
			num=num+1;
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("The recort space is not enough:"+e);
		}
		
	}
	/**
	 * 
	 * Count the detail information of the data used of target method
	 * @param len : the data dimension
	 *  
	 */	
	public void DtlCount(int len){
		int point;
		if(search(len)==true){
			Calculate(len);
		}
		else{
			point=find(len);
			insert(point,len);
		}

	}
	
	/**
	 * 
	 * correct(i.e. minus one) the detail information of the data used of target method
	 * @param len : the data dimension
	 *  
	 */	
	public void DtlCorrect(int len){
		Reduce(len);
	}
	/**
	 * 
	 * @return the _detail array has been counted 
	 */
	public long[][] GetDtl(){
		long[][] FFTDim= null;
		FFTDim=new long[2][num];
		for (int i=0;i<num;i++){
			for (int j=0;j<2;j++){
				FFTDim[j][i]=_Detail[j][i];					
			}
		}
		return FFTDim;
	}
	
	/**
	 * 
	 * output the detail results
	 * @param name the subclass's name(_para)
	 * @param Path: output path
	 * @throws IOException
	 * 
	 */
	public void NcOutput(String name,String Path) throws IOException{
	      FileOutputStream fos = null;
	      DataOutputStream dos = null;
	      long[][] dbuf = new long[2][num];
	      for(int i=0;i<2;i++){
	    	  for(int j=0;j<num;j++){
	    		  dbuf[i][j]=_Detail[i][j];
	    	  }
	      }
		  try{
		     fos = new FileOutputStream(Path+name);
		     dos = new DataOutputStream(fos);
		     dos.writeInt(num);
		     for(int i=0;i<dbuf.length;i++){
		    	 for (long d:dbuf[i]){
					 dos.writeLong(d);         
				  }	 
		     }
		     
		     dos.flush();  
		  }catch(Exception e){
		     e.printStackTrace();
		  }finally{
		         if(dos!=null)
		            dos.close();
		         if(fos!=null)
		            fos.close();	      
		  }
	}
	/**
	 * 
	 * @param name the subclass's name(para)
	 * @param Path the input path
	 * @return: the detail results
	 * @throws IOException
	 */
	public long[][] NcInput(String name, String Path) throws IOException{
		  InputStream is = null;
		  DataInputStream dis = null;
		  long[][] dbuf=null ;
		  try{
			  is = new FileInputStream(Path+name);
			  dis = new DataInputStream(is);
	  	      int i=0;		   
		      int j=0;		   
		      int num=dis.readInt();
		     
		      dbuf=new long[2][num];
		      while(dis.available()>0)
		      {
		    	 if(j==num){ 
		    	 i++;
	    		 j=0;
	    	  }
	          dbuf[i][j] = dis.readLong();
	          j++;
		     }   
		  }catch(Exception e){     
			  e.printStackTrace();
		  }finally{
			  if(is!=null)
				  is.close();
			  if(dis!=null)	
			  	dis.close();
		  }
		return dbuf;
	}
}


/**
 * 
 * This class is used to count the times of FFT methods called in a jython pipeline.
 *  the methods include fft and ifft 
 *	
 */
public class FFTNumCount {

	/**
	 * the pre-define space used. default=500 (int) 
	 */
	final static int _Dim=500;
	/**
	 * constructor
	 */
	public FFTNumCount(){
	}

	/**
	 * the static class NCFFT to count the FFT method 
	 */
	public static FFTPara NCfft= new FFTPara(_Dim,"NCfft");
	/**
	 * the static class NCiFFT to count the FFT method 
	 */
	public static FFTPara NCifft= new FFTPara(_Dim,"NCifft");

	/**
	 * the Counter list,include fft and ifft
	 */
	public static FFTPara[] list={NCfft,NCifft};
	
	/**
	 * Reset all the subclass, i.e. recount again 
	 */
	public static void ReSet(){
		for(FFTPara Ops : list){
			Ops.ReSet();
		}
	}
	/**
	 * get all methods' count numbers 
	 */
	public static void FFTGetALL(){
		for(FFTPara Ops : list){
			Ops.GetCount();
		}
	}
	/**
	 * output the all record results
	 * @param Path output path
	 * @throws IOException
	 */
	public static void FFTNcOutputALL(String Path) throws IOException{
		for(FFTPara Ops : list){
			Ops.NcOutput(Ops._para,Path);
		}
	}
	
	/**
	 * count the number of the operator
	 * @param Ops operator i.e. the method we want to count
	 * 
	 */
	public static void FFTCount(FFTPara Ops){
		Ops.NumCount();
	}
	/**
	 * minus one of  the number of the operator
	 * @param Ops operator i.e. the method we want to count
	 * 
	 */
	public static void FFTCorrect(FFTPara Ops){
		Ops.NumCorrect();
	}
	
	/**
	 * get the times of the Ops method having been called 
	 * @param Ops operator i.e. the method we want to count
	 * @return the number has been count
	 */
	public static long FFTGetCount(FFTPara Ops){
		return Ops.GetCount();
	}
	
	/**
	 * Count the detail information 
	 * @param Ops operator i.e. the method we want to count
	 * @param len the dimension of the data 
	 */
	public static void FFTDtlCount(FFTPara Ops,int len){
		Ops.DtlCount(len);
	}
	
	/**
	 * correct the detail information 
	 * @param Ops operator i.e. FFT or iFFT
	 * @param len the dimension of the data
	 */
	public static void FFTDtlCorrect(FFTPara Ops,int len){
		Ops.DtlCorrect(len);
	}
	/**
	 * 
	 * get the detail results of method Ops
	 * @param Ops operator i.e. the method we want to count
	 * @return the detail information
	 */
	public static long[][] FFTGetDtl(FFTPara Ops){
		return Ops.GetDtl();
	}
	
	/**
	 * Output the detail result of method Ops
	 * @param Ops operator i.e. the method we want to count
	 * @param Path output path
	 * @throws IOException
	 */
	
	public static void FFTNcOutput(FFTPara Ops,String Path) throws IOException{
		Ops.NcOutput(Ops._para, Path);
	}
	/**
	 * 
	 * input the detail result of method Ops
	 * @param Ops  operator i.e. the method we want to count
	 * @param Path input path
	 * @return return the input result
	 * @throws IOException
	 */
	public static long[][] FFTNcInput(FFTPara Ops,String Path) throws IOException{
		return Ops.NcInput(Ops._para, Path);
	}
	/**
	 * 
	 * change the sparse type to the continuous type (import lots of zeros, but it is convenient to draw figure)
	 * @param dtl the detail array
	 * @return reshape the dtl array and translate the sparse type to dense type
	 */
	public static long[] FFTGetDim(FFTPara Ops){
		long[][] dtl=FFTGetDtl(Ops);
		int nums = dtl[0].length;
		int dm= (int) dtl[0][nums-1];
		long[] Dim = new long[dm+1];
		for(int i=0;i<nums;i++){
			dm=(int) dtl[0][i];
			Dim[dm]=dtl[1][i];
		}
		return Dim;
	}
	
	public static String FFTtoString(FFTPara Ops){
		return Ops._para;
	}
}
