/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2012 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * $Id: RealDoubleFFT.java,v 1.11 2012/06/28 22:01:18 tfulton Exp $
 *
 * Copyright (c) 2011 Blue Sky Spectroscopy,
 *                    www.blueskyinc.ca
 *                    Lethbridge, Alberta, Canada.
 */

package herschel.ia.numeric.toolbox.xform.util;

/**
 * Fast Fourier Transform of real data using the FFT_PACK algorithm. 
 *
 * @jhelp Gives the Fast Fourier Transform of real data using an FFT_PACK algorithm.   
 * <p>       
 * RealDoubleFFT#ft transforms real input into complex output.   
 * It returns the positive frequencies of the DFT. 
 * The remaining frequencies of the DFT can be recontructed using conjugate symmetry 
 * (recall that for real input, X<sub>k</sub> = X<sub>N-k</sub>*).
 * </p>
 * <p>
 * If input has length N then output has length floor(N/2)+1.  
 * RealDoubleFFT#ft is fast for inputs with lengths that can be  decomposed into small factors.
 * </p>    
 * <p>
 * Use RealDoubleFFT#ft(double[]) to calculate the FFT of real data.  
 * However, if the length of input has large prime factors, use FFT instead.  
 * </p>
 * <p>
 * Each RealDoubleFFT object is contructed with an argument N, which is equivalent to the length 
 * of input to the forward transform. If performing multiple transforms on inputs of the same length, 
 * create a single RealDoubleFFT object and use it for each transform. Processing speed is improved 
 * by minimizing the number of times  RealDoubleFFT objects are created because each object performs 
 * intialization specific to the expected input length.
 * </p>
 *  
 * <p>
 * The inverse transform is RealDoubleFFT#bt.  
 * It transforms complex input to real output. 
 * If input has length L then output has length 2L-2 
 * (if N, an argument for the constructor of RealDoubleFFT, is even) or 2L-1 (if N is odd).
 * </p>
 * 
 * <p>   
 * Note that the output of RealDoubleFFT is not normalized.    
 * To normalize, divide the output of the inverse transform by N 
 * (an argument for the constructor of RealDoubleFFT).
 * N is stored in RealDoubleFFT#norm_factor.
 *</p>
 * 
 * @jsynopsis
 * RealDoubleFFT.ft(<x>, <c>)
 * 
 * @jparameter x, INPUT, Double1d, MANDATORY
 *  Double1d arrays only. Input is modified during the calculation.
 *
 * @jparameter c, OUTPUT, Complex1D
 *   Returns a Complex1D
 *  
 * @jexample Shows how to get equivalent results with FFT, FFT_PACK, and RealDoubleFFT.  
 * from herschel.ia.numeric.toolbox.xform.util import RealDoubleFFT
 * from herschel.ia.numeric.toolbox.xform.util import Complex1D
 * 
 * ts = 1E-6          # Sampling period (sec)
 * fc = 200000        # Carrier frequency (Hz)
 * fm = 2000          # Modulation frequency (Hz)
 * beta = 0.0003      # Modulation index (Hz)
 * N = 1000           # Number of samples
 * pi = java.lang.Math.PI   # define pi
 * t = Double1d.range(N) * ts    
 * # a real, asymmetrical signal 
 * signal = SIN(2 * pi * fc * t * (1 + beta * COS(2 * pi * fm * t)))
 * 
 * # Option 1.  FFT (slow)
 * spec_fft = FFT(Complex1d(signal))  
 * # Option 2. FFT_PACK (slow)
 * spec_fftpack = FFT_PACK(Complex1d(signal)) 
 * # Option 3. RealDoubleFFT (fast)
 * rdfft = RealDoubleFFT(N)
 * c = Complex1D()
 * # Calculation destroys input signal
 * rdfft.ft(signal.copy().array,c)
 * spec_rdfft = Complex1d(c.x, c.y) 
 * 
 * # Compare lengths of output
 * print "Length of FFT output: %d"%spec_fft.size             # N
 * print "Length of FFT_PACK output: %d"%spec_fftpack.size    # N
 * print "Length of RealDoubleFFT output: %d"%spec_rdfft.size # floor(N/2)+1  
 * 
 * # Compare values in output (maximum modulus of difference)
 * print "Maximum modulus of difference output of FFT and FFT_PACK:"
 * print MAX(ABS(spec_fft - spec_fftpack))
 * print "Maximum modulus of difference between output of FFT and RealDoubleFFT (unextended):"
 * print MAX(ABS(spec_fft[0:(N/2)+1]- spec_rdfft))
 * 
 * # To get the full spectrum using RealDoubleFFT, use the following symmetry relationship 
 * # which applies to the FFT of real input:
 * #    The (N-k)th complex FFT coefficient is the conjugate of kth complex FFT coefficient
 * #    where N is the length of the input.
 * 
 * # Extend the RealDoubleFFT output using symmetry X(N-k) = X(k)*   
 * rdfft_extended = spec_rdfft.copy().append(Complex1d(REVERSE(spec_rdfft[1:(N-N/2)].real), \
 *     REVERSE(-spec_rdfft[1:(N-N/2)].imag)))
 * # Compare FFT output with extended RealDoubleFFT output using maximum modulus of difference
 * print "Maximum modulus of difference between FFT output and RealDoubleFFT output extended by symmetry:"
 * print MAX(ABS(spec_fft - rdfft_extended))
 *
 * @jexample Recreate signal using forward and inverse transform
 * from herschel.ia.numeric.toolbox.xform.util import RealDoubleFFT
 * from herschel.ia.numeric.toolbox.xform.util import Complex1D
 *
 * N = 1000
 * signal = Double1d.range(N)
 * # Apply forward transform to signal
 * rdfft = RealDoubleFFT(N)
 * c = Complex1D()
 * rdfft.ft(signal.toArray(), c)
 * # Recreate signal using inverse transform
 * signal_rdfft = Double1d(N)
 * rdfft.bt(c, signal_rdfft.getArray())
 * signal_rdfft = signal_rdfft/N
 * print "Maximum absolute difference between signal and recreated signal:"
 * print MAX(ABS(signal-signal_rdfft)) 
 *
 * @jcategory
 *  Mathematics/Signal processing
 *
 * @miscellaneous
 * This class uses the Complex1D class.
 *
 * @jref um:sec-integral-transforms
 * @jref herschel.ia.numeric.toolbox.xform.FFT
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_EVEN
 * @jref herschel.ia.numeric.toolbox.xform.FFT_PACK_ODD
 *
 * @author Trevor Fulton
 * 
 * Change Log:
 * 2011-06-24 PK [HCSS-12037] Updated URM entry.
 * 2011-07-19 PK [HCSS-12037] Made URM title consistent with other titles in the package.
 * 2011-10-14 DS [HCSS-14289] Corrected Jexample.
 */
public class RealDoubleFFT extends RealDoubleFFT_Mixed {
    /**
     * <em>norm_factor</em> can be used to normalize this FFT transform. This is because
     * a call of forward transform (<em>ft</em>) followed by a call of backward transform
     * (<em>bt</em>) will multiply the input sequence by <em>norm_factor</em>.
     */
    private double normFactor;
    private double wavetable[];
    private int ndim;

    /**
     * Construct a wavenumber table with size <em>n</em>.
     * The sequences with the same size can share a wavenumber table. The prime
     * factorization of <em>n</em> together with a tabulation of the trigonometric functions
     * are computed and stored.
     *
     * @param  n  the size of a real data sequence. When <em>n</em> is a multiplication of small
     * numbers (4, 2, 3, 5), this FFT transform is very efficient.
     */
    public RealDoubleFFT(int n) {
        ndim = n;
        normFactor = n;
        if (wavetable == null || wavetable.length != (2 * ndim + 15)) {
            wavetable = new double[2 * ndim + 15];
        }
        rffti(ndim, wavetable);
    }

    /**
     * Forward real FFT transform. It computes the discrete transform of a real data sequence.
     *
     * @param x an array which contains the sequence to be transformed. After FFT,
     * <em>x</em> contains the transform coefficients used to construct <em>n</em> complex FFT coefficients.
     * <br>
     * The real part of the first complex FFT coefficients is <em>x</em>[0]; its imaginary part
     * is 0. If <em>n</em> is even set <em>m</em> = <em>n</em>/2, if <em>n</em> is odd set
     * <em>m</em> = <em>n</em>/2, then for
     * <br>
     * <em>k</em> = 1, ..., <em>m</em>-1 <br>
     * the real part of <em>k</em>-th complex FFT coefficients is <em>x</em>[2*<em>k</em>-1];
     * <br>
     * the imaginary part of <em>k</em>-th complex FFT coefficients is <em>x</em>[2*<em>k</em>-2].
     * <br>
     * If <em>n</em> is even,
     * the real of part of (<em>n</em>/2)-th complex FFT coefficients is <em>x</em>[<em>n</em>]; 
     * its imaginary part is 0.
     * The remaining complex FFT coefficients can be obtained by the symmetry relation:
     * the (<em>n</em>-<em>k</em>)-th complex FFT coeffient is the conjugate of <em>n</em>-th complex FFT coeffient.
     *
     */
    public void ft(double x[]) {
        if (x.length != ndim) {
            throw new IllegalArgumentException("The length of data can not match that of the wavetable");
        }
        rfftf(ndim, x, wavetable);
    }

    /**
     * Forward real FFT transform. It computes the discrete transform of a real data sequence.
     *
     * @param x an array which contains the sequence to be transformed. After FFT,
     * <em>x</em> contains the transform coefficients used to construct <em>n</em> complex FFT coefficients.
     * <br>
     * @param y the first complex (<em>n</em>+1)/2 (when <em>n</em> is odd) or (<em>n</em>/2+1) (when
     * <em>n</em> is even) FFT coefficients.
     * The remaining complex FFT coefficients can be obtained by the symmetry relation:
     * the (<em>n</em>-<em>k</em>)-th complex FFT coeffient is the conjugate of <em>n</em>-th complex FFT coeffient.
     *
     */
    public void ft(double x[], Complex1D y) {
        if (x.length != ndim) {
            throw new IllegalArgumentException("The length of data can not match that of the wavetable");
        }
        rfftf(ndim, x, wavetable);
        //
        // Local real and imaginary components.
        //
        double[] thisX;
        double[] thisY;

        if (ndim % 2 == 0) {
            thisX = new double[ndim / 2 + 1];
            thisY = new double[ndim / 2 + 1];
        } else {
            thisX = new double[(ndim + 1) / 2];
            thisY = new double[(ndim + 1) / 2];
        }

        thisX[0] = x[0];
        thisY[0] = 0.0D;
        for (int i = 1; i < (ndim + 1) / 2; i++) {
            thisX[i] = x[2 * i - 1];
            thisY[i] = x[2 * i];
        }
        if (ndim % 2 == 0) {
            thisX[ndim / 2] = x[ndim - 1];
            thisY[ndim / 2] = 0.0D;
        }
        y.setX(thisX);
        y.setY(thisY);
    }

    /**
     * Backward real FFT transform. It is the unnormalized inverse transform of <em>ft</em>(double[]).
     *
     * @param x an array which contains the sequence to be transformed. After FFT,
     * <em>x</em> contains the transform coefficients. Also see the comments of <em>ft</em>(double[])
     * for the relation between <em>x</em> and complex FFT coefficients.
     */
    public void bt(double x[]) {
        if (x.length != ndim) {
            throw new IllegalArgumentException("The length of data can not match that of the wavetable");
        }
        rfftb(ndim, x, wavetable);
    }

    /**
     * Backward real FFT transform. It is the unnormalized inverse transform of <em>ft</em>(Complex1D, double[]).
     *
     * @param x  an array which contains the sequence to be transformed. When <em>n</em> is odd, it contains the first
     * (<em>n</em>+1)/2 complex data; when <em>n</em> is even, it contains (<em>n</em>/2+1) complex data.
     * @param y  the real FFT coefficients.
     * <br>
     * Also see the comments of <em>ft</em>(double[]) for the relation
     * between <em>x</em> and complex FFT coefficients.
     */
    public void bt(Complex1D x, double y[]) {
        if (ndim % 2 == 0) {
            if (x.getX().length != ndim / 2 + 1) {
                throw new IllegalArgumentException(
                        "The length of data can not match that of the wavetable");
            }
        } else {
            if (x.getX().length != (ndim + 1) / 2) {
                throw new IllegalArgumentException(
                        "The length of data can not match that of the wavetable");
            }
        }

        y[0] = x.getX()[0];
        for (int i = 1; i < (ndim + 1) / 2; i++) {
            y[2 * i - 1] = x.getX()[i];
            y[2 * i] = x.getY()[i];
        }
        if (ndim % 2 == 0) {
            y[ndim - 1] = x.getX()[ndim / 2];
        }
        rfftb(ndim, y, wavetable);
    }

    /**
    * Get the normalization factor.
    * 
    * @return Normalization factor.
    */
    public double getNormFactor() {
        return this.normFactor;
    }
}
