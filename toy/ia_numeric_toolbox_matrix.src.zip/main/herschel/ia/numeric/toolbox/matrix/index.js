/* -*-java-*- script */

/**
 * "Table of Contents" for package:
 * herschel.ia.numeric.toolbox.matrix package
 */
{
    // header: required
    TOC.message("matrix.start");

    // Always start with...
    TOC.start();

    // body: here goes your information:
    TOC.title("Matrix","./doc/matrix.html");

    // Access to the CHANGLOG...
    TOC.add(new DocLocal("CHANGELOG","CHANGELOG"));

    // Developer web pages: escapes the frameset...
    TOC.add(new DocLink("DP Developer Web Pages","http://www.rssd.esa.int/SD-general/Projects/Herschel/hscdt/docsDpDeveloper.shtml"));

    // Relative link DP doc: escapes the frameset...
    TOC.add(new DocLink("DP Documentation","../doc/index.html",true));

    // Numeric documentation...
    TOC.add(new DocLink("DP Numeric Framework","../../index.html",true)); // local path!

    // A separator:
    TOC.add(new DocSep());

    // Function descriptions.
    TOC.add(new DocLocal("DETERMINANT","./doc/matrix.html#DETERMINANT"));
    TOC.add(new DocLocal("INVERSE","./doc/matrix.html#INVERSE"));
    TOC.add(new DocLocal("TRANSPOSE","./doc/matrix.html#TRANSPOSE"));
    TOC.add(new DocLocal("MatrixMultiply","./doc/matrix.html#MatrixMultiply"));
    TOC.add(new DocLocal("MatrixSolve","./doc/matrix.html#MatrixSolve"));
    TOC.add(new DocLocal("CholeskyDecomposition","./doc/matrix.html#CholeskyDecomposition"));
    TOC.add(new DocLocal("EigenvalueDecomposition","./doc/matrix.html#EigenvalueDecomposition"));
    TOC.add(new DocLocal("LUDecomposition","./doc/matrix.html#LUDecomposition"));
    TOC.add(new DocLocal("QRDecomposition","./doc/matrix.html#QRDecomposition"));
    TOC.add(new DocLocal("SingularValueDecomposition","./doc/matrix.html#SingularValueDecomposition"));

    // Javadoc
    TOC.add(new DocLocal("Java API", "../../api/herschel/ia/numeric/toolbox/basic/package-summary.html"));

    // Always end with...
    TOC.end();
    TOC.message("matrix.end");
}
