/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
// -*-java-*-
//
// File:      Util.java
// Author:    Jorgo Bakker <jbakker@rssd.esa.int>
// Generated: Tue Jul  6 12:51:42 CEST 2004
// Usage:     -
// Info:      -

package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.*;

/**
 * @author Jorgo Bakker <jbakker@rssd.esa.int>
 */
class Util
{
    static void checkIsSquare(ArrayData x) {
	if (x.getRank() != 2) error("not a matrix");
	
	final int[] d=x.getDimensions();
	if (d[0]!=d[1]) error("is not a square matrix");
    }
    
    static void error(String s) {
	    throw new IllegalArgumentException(s);
    }
}
