/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.*;

/**
 * Abstract function object that computes real arrays of rank 1 out of
 * numeric arrays of rank 2 holding ordered types.
 * <p>
 * It provides two {@link #calc} methods to allo strongly typed usage as well.
 * @author Jorgo Bakker <jbakker@rssd.esa.int>
 *
 */
public abstract class AbstractOrdered2dToReal1d extends AbstractArrayToArray
{
    /**
     * developers must implement this method
     */
    public abstract Double1d calc(Double2d x);

    /**
     * 
     * developers may override this method for effieciency reasons
     */
    public Float1d calc(Float2d x) {
	return new Float1d(calc(new Double2d(x)));
    }

    // --- framework support
    public ArrayData of(Byte2d x) { return of(new Double2d(x)); }
    public ArrayData of(Short2d x) { return of(new Double2d(x)); }
    public ArrayData of(Int2d x) { return of(new Double2d(x)); }
    public ArrayData of(Long2d x) { return of(new Double2d(x)); }
    public ArrayData of(Float2d x) { return calc(x); }    
    public ArrayData of(Double2d x) { return calc(x); }
}
