# 
#  This file is part of Herschel Common Science System (HCSS).
#  Copyright 2001-2010 Herschel Science Ground Segment Consortium
# 
#  HCSS is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as
#  published by the Free Software Foundation, either version 3 of
#  the License, or (at your option) any later version.
# 
#  HCSS is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU Lesser General Public License for more details.
# 
#  You should have received a copy of the GNU Lesser General
#  Public License along with HCSS.
#  If not, see <http://www.gnu.org/licenses/>.
# 
"""
******************************************************************
Test script for IA.Numerics.Toolbox.Matrix
Tester: Antonio Cava (PACS ICC)
May 12, 2010
by Yi Mei

Perform a series of matrix operations and compare results with IDL
******************************************************************
"""

from java.util.logging import *
from java.lang import *
from herschel.ia.numeric import *
from herschel.ia.numeric.toolbox.basic import *
#from herschel.ia.numeric.Float2d import *
from herschel.ia.numeric.toolbox.util import *
from herschel.ia.numeric.toolbox.matrix import *
import unittest
from org.junit.Assert import *
#import static org.junit.Assert.*

class VVTestMatrix(unittest.TestCase):
    
    tolerance = 1.e-5
    errMsg='error'
    
    # IDL results for comparison
    # --------------------------
    #  made with 5-points-precission floats
    #  on a IDL Version 6.4 (linux x86 m32) on herl37 (HSC/ESAC)
    #  on Tue Sep 16 12:25:14 CEST 2008
    
 
    def testInverse1(self):
        A=Float2d([[1,2],[3,4]])
        rslt = INVERSE(A)
        exp = Float2d([[-2.00000,1.00000], [1.50000,-0.500000]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)        
        
    def testInverse2(self):
        A=Float2d([[1,2,2],[4,6,6],[7,8,9]])
        rslt = INVERSE(A)
        #IDL's result is wrong. This is correct expected result:
        exp = Float2d([[-3.00000,1.00000,-0.00000],[-3.00000,2.50000,-1.00000],[5.00000,-3.00000,1.00000]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)

    def testInverse3(self):
        passed = 1
        try:
          A=Float2d([[3.,1.,-4.],[1.,3.,-4.],[-4.,-4.,8.]])
          rslt = INVERSE(A)
        except RuntimeException, e:
          passed = 0
        self.failUnless(not passed, "Exception not thrown");
        
    def testMatrixSolve1(self):
        A=Float2d([[1.0,2.0],[3.0,4.0]])
        x=Double1d([8.0,18.0])
        rslt = MatrixSolve(x)(A)
        exp = Float1d([2.0,3.0])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)

    def testMatrixSolve2(self):
        A=Float2d([[1,2,2],[4,5,6],[3,4,5]])
        x=Double1d([8.0,18.0,5.0])
        rslt = MatrixSolve(x)(A)
        exp = Float1d([18.00000,24.00000,-29.00000])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        rslt = A.apply(MatrixSolve(x))
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        
    def testMatrixSolve3(self):
        passed = 1
        try:
          A=Float2d([[1.0,2.0,3.0],[4.0,5.0,6.0],[7.0,8.0,9.0]])
          x=Double1d([8.0,18.0,5.0])
          rslt = A.apply(MatrixSolve(x))
        except RuntimeException, e:
          passed = 0
        self.failUnless(not passed, "Exception not thrown");
        
    def testTranspose1(self):
        A=Int2d([[1,2],[3,4],[5,6]])
        rslt = TRANSPOSE(A)
        exp = Int2d([[1,3,5],[2,4,6]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)

    def testTranspose2(self):
        A=Double2d([[1.2349999999,2.235456],[3.12345678,4.221223],[5.3343456655,6.111122224333]])
        rslt = TRANSPOSE(A)
        exp = Double2d([[1.2350000,3.1234568,5.3343457],[2.2354560,4.2212230,6.11112222]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)

    def testTranspose3(self):
        A=Bool2d([[1,1,1],[0,0,0]])
        rslt = TRANSPOSE(A)
        exp = Bool2d([[1,0],[1,0],[1,0]])
        self.failUnless(exp==rslt,self.errMsg)

    def testDeterminant1(self):
        A=Double2d([[1.0,2.0],[3.0,4.0]])
        rslt = DETERMINANT(A)
        exp = -2.00000
        #self.failIf(ABS(exp-rslt)>self.tolerance,self.errMsg)
        self.failIf(ABS(exp-rslt)>self.tolerance,self.errMsg)

    def testDeterminant2(self):
        passed = 1
        try:
          A=Double2d([[1.234],[2.34355],[3.21246643],[0.13324]])
          rslt = DETERMINANT(A)
        #except RuntimeException, e:???
        except IllegalArgumentException, e:
          passed = 0
        self.failUnless(not passed, "Exception not thrown");

    def testDeterminant3(self):
        A=Double2d([[1.234,3.23,4.54,5.332323],[2.34355,1.234,3.23,4.54],[3.21246643,2.34355,1.234,3.23],[0.13324,3.23,4.54,5.332323]])
        rslt = DETERMINANT(A)
        exp = 14.934293421147183
        self.failIf(ABS(exp-rslt)>self.tolerance,self.errMsg)

    def testDeterminant4(self):
        passed = 1
        try:
          A=Float2d([[1.23400],[2.34355],[3.21247],[0.13324]])
          rslt = DETERMINANT(A)
        except RuntimeException, e:
          passed = 0
        self.failUnless(not passed, "Exception not thrown");
        
    def testMatrixMultiply1(self):
        A=Double2d([[2.0,4.0,6.0],[1.0,3.0,5.0]])
        B=TRANSPOSE(A)
        rslt = MatrixMultiply(B)(A)
        exp = Double2d([[56.0,44.0],[44.0,35.0]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        
    def testMatrixMultiply2(self):
        A=Double2d([[1,2,3],[7,5,4],[7,4,9]])
        x=Double1d([4,1,7])
        rslt = MatrixMultiply(x)(A)
        exp = Double1d([27.0,61.0,95.0])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)

    def testMatrixMultiply3(self):
        A=Int2d([[1,2,3],[2,3,4]])
        B=Int2d([[1,2],[2,3],[3,4]])
        rslt=A.apply(MatrixMultiply(B))
        exp=Int2d([[14,20],[20,29]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        x=Int1d([1,2])
        rslt=x.apply(MatrixMultiply(A))
        exp=Int1d([5,8,11])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        x=Int1d([1,2,3])
        rslt=A.apply(MatrixMultiply(x))
        exp=Int1d([14,20])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        
    def testMatrixMultiply4(self):
        A=Bool2d([[1,0,1],[1,1,1]])
        B=TRANSPOSE(A)
        rslt=MatrixMultiply(B)(A)
        exp=Bool2d([[1,1],[1,1]])
        self.failUnless(exp==rslt,self.errMsg)
        
    def testLUDecompostion(self):
        A=Double2d([[ 2.0,  1.0,  1.0],[ 4.0, -6.0,  0.0],[-2.0,  7.0,  2.0]])
        B=Double2d([[3.0],[-8.0],[10.0]]) 
        rslt=B.apply(LUDecomposition(A))
        exp=Double2d([[1.00000],[2.00000],[-1.00000]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        
    def testEigenvalueDecompostion1(self):
        A=Double2d([[3.,1.,-4.],[1.,3.,-4.],[-4.,-4.,8.]])
        x=A.apply(EigenvalueDecomposition())
        #Get eigen values
        rslt=x.getD()
        #IDL:TRIRED, A,D,E; TRIQL,D,E,A; 
        # PRINT D 
        #result is [2.0, 0.0, 12.0]. The eigenvalues are the same but in a different order.
        #Here the exp is modified from IDL result in order to compare with our result.
        exp=Double2d([[0.0, 0.0, 0.0],[0.0, 2.0, 0.0],[0.0, 0.0, 12.0]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        #Get eigen vector matrix
        rslt=x.getV()
        # IDL PRINT A
        #result is in different order due to different order of eigen values. 
        #Here the exp is modified from IDL result in order to compare with our result.
        exp=Double2d([[-0.577350,-0.707107,-0.408248],[-0.577350,0.707107,-0.408248],[-0.577350,0.0,0.816497]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        
    def testEigenvalueDecompostion2(self):
        B=Double2d([[1.,0.,2.],[0.,1.,-1.],[-1.,1.,1.]])
        x=B.apply(EigenvalueDecomposition())
        rslt=x.getD()
        #IDL: hes=ELMHES(B); print HQR(hes). The dimension and order are different from our result. 
        exp=Double2d([[1.0000,1.73205,0.00000],[-1.73205,1.00000,0.00000],[0.00000,0.00000,1.00000]])
        self.failIf(ANY(ABS(exp-rslt)>self.tolerance),self.errMsg)
        
#end class VVTestMatrix


# Stand-alone: run module straight from the command line:
#  jython scrtest.py
if __name__ == '__main__':
    unittest.main()

