/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2011 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.Double1d;
import herschel.ia.numeric.Double2d;
import herschel.ia.numeric.Float2d;
import herschel.ia.numeric.toolbox.AbstractArrayToObject;

/**
 * Eigenvalues and eigenvectors of a real matrix.
 * <p>
 *  If A is symmetric, then A = V*D*V' where the eigenvalue matrix D is
 *  diagonal and the eigenvector matrix V is orthogonal.
 * <p>
 *  If A is not symmetric, then the eigenvalue matrix D is block diagonal
 *  with the real eigenvalues in 1-by-1 blocks and any complex eigenvalues,
 *  lambda + i*mu, in 2-by-2 blocks, [lambda, mu; -mu, lambda].  The
 *  columns of V represent the eigenvectors in the sense that A*V = V*D.
 *  The matrix V may be badly conditioned, or even singular, so the validity of 
 *  the equation A = V*D*inverse(V) depends upon Vcond().
 * <p>
 *  Note:  This documentation has been derived from the Jama.EigenvalueDecomposition javadocs.
 *
 * <p>
 * Example:
 * <pre> Eigenvalue decomposition for ...
 * <em># jython </em>
 *
 * A=Double2d( [ [1.,1.,1.],[1.,2.,3.],[1.,3.,6.] ] )
 * evd=A.apply(EigenvalueDecomposition())
 * print evd.d
 * print evd.v
 * print evd.imagEigenvalues
 * print evd.realEigenvalues
 *
 * <em>// java: </em>
 *
 * double[][] pvals = {{1.,1.,1.},{1.,2.,3.},{1.,3.,6.}};
 * Double2d A = new Double2d (pvals);
 * EigenvalueDecomposition Eig = (EigenvalueDecomposition) 
 *    A.apply(new EigenvalueDecomposition());
 * Double2d D = Eig.getD();
 * Double2d V = Eig.getV();
 * Double1d r = Eig.getRealEigenvalues();
 * Double1d i = Eig.getImagEigenvalues();
 * </pre>
 *
 *@jhelp EigenvalueDecomposition
 * Eigenvalues and eigenvectors of a real matrix.
 * 
 *  If A is symmetric, then A = V*D*V' where the eigenvalue matrix D is
 *  diagonal and the eigenvector matrix V is orthogonal.
 *
 *  If A is not symmetric, then the eigenvalue matrix D is block diagonal
 *  with the real eigenvalues in 1-by-1 blocks and any complex eigenvalues,
 *  lambda + i*mu, in 2-by-2 blocks, [lambda, mu; -mu, lambda].  The
 *  columns of V represent the eigenvectors in the sense that A*V = V*D.
 *  The matrix V may be badly conditioned, or even singular, so the validity of 
 *  the equation A = V*D*inverse(V) depends upon Vcond().
 *
 * @jalias EigenvalueDecomposition 
 *
 * @jsynopsis
 *   A=Double2d()
 *   evd=A.apply(EigenvalueDecomposition())
 *   # get the eigenvalue matrix D
 *   D = evd.d
 *   # get the eigenvector matrix V
 *   V = evd.v
 *   # Get the imaginary eigenvalues
 *   imagEigenvalues = evd.imagEigenvalues
 *   # Get the real eigenvalues
 *   realEigenvalues = evd.realEigenvalues
 *
 * @jexample The columns of V represent the Eigenvectors: A*V = V*D
 *
 * A=Double2d( [ [1.,1.,1.],[1.,2.,3.],[1.,3.,6.] ] )
 * evd=A.apply(EigenvalueDecomposition())
 * D = evd.d
 * V = evd.v
 * print A.apply(MatrixMultiply(V))
 * # [
 * # [-0.06907722348532569,-0.8164965809277256,1.5259625390319682],
 * # [0.09922885633779388,-0.4082482904638629,3.7179950198195835],
 * # [-0.03892559063285694,0.4082482904638627,6.769920097883521]
 * # ]
 * print V.apply(MatrixMultiply(D))
 * # [
 * # [-0.06907722348532568,-0.8164965809277251,1.525962539031968],
 * # [0.09922885633779421,-0.4082482904638631,3.717995019819584],
 * # [-0.03892559063285706,0.4082482904638628,6.769920097883519]
 * # ]
 *
 * @jparameter A, INPUT, Double2d , MANDATORY
 *   Input must be a Double2d or Float2d array.
 *
 * @jcategory
 *  herschel.ia.numeric.toolbox.matrix
 *
 * @author Jeff Jacobson <jdj@ipac.caltech.edu>
 */
public class EigenvalueDecomposition 
   extends AbstractArrayToObject
{
	/**
     * Wraps the Jama.EigenvalueDecomposition class.
     */
	private herschel.ia.numeric.toolbox.matrix.jama.EigenvalueDecomposition evd_;

   private int maxIterations_ = Integer.MAX_VALUE;
	   

    /**
     * Default constructor.
     */
    public EigenvalueDecomposition () {}

    /**
     * Iteration-limiting constructor.
     * @param maxIterations Prevent runaways
     */
    public EigenvalueDecomposition (int maxIterations) {
       maxIterations_ = maxIterations;
    }

    /** 
	 * Check for symmetry, then construct the eigenvalue decomposition
	 * @param A    Input matrix
	 * @return     Structure to access D and V.
         */	
    public EigenvalueDecomposition(Double2d A) {
		// Wraps the Jama version.
    	evd_ = new herschel.ia.numeric.toolbox.matrix.jama.EigenvalueDecomposition(
    			new Jama.Matrix (A.getArray()), maxIterations_);
	}


    /** 
	 * Check for symmetry, then construct the eigenvalue decomposition
	 * @param A    Input matrix
	 * @param maxIterations    max iterations
	 * @return     Structure to access D and V.
         */	
    public EigenvalueDecomposition(Double2d A, int maxIterations) {
		// Wraps the Jama version.
    	evd_ = new herschel.ia.numeric.toolbox.matrix.jama.EigenvalueDecomposition(
    			new Jama.Matrix (A.getArray()), maxIterations);
	}


    /**
     * Applies this function to an array of type Float2d.
     * @param A   Input matrix
     * @return Object - returns object containing eigen values and eigen vectors.
     */
    public EigenvalueDecomposition of(Float2d A) {
    	//JCS: evd_ = Jama.EigenvalueDecomposition(
    	evd_ = new herschel.ia.numeric.toolbox.matrix.jama.EigenvalueDecomposition(
    			new Jama.Matrix (new Double2d (A).getArray()), maxIterations_);
      return this;
    }

    /**
     * Applies this function to an array of type Double2d.
     * @param A   Input matrix
     * @return Object - returns object containing eigen values and eigen vectors.
     */
    public EigenvalueDecomposition of(Double2d A) {
    	//JCS: evd_ = Jama.EigenvalueDecomposition(
    	evd_ = new herschel.ia.numeric.toolbox.matrix.jama.EigenvalueDecomposition(
    			new Jama.Matrix (A.getArray()), maxIterations_);
      return this;
    }

    /**
     * Return the eigenvector matrix
     * @return V vector.
     */
    public Double2d getV () {
    	Double2d V = new Double2d (evd_.getV().getArray());
    	return V;
    }

    /**
     * Return the block diagonal eigenvalue matrix
     * @return D values
     */
    public Double2d getD () {
    	Double2d D = new Double2d (evd_.getD().getArray());
    	return D;
    }

    /** 
     * Return the real parts of the eigenvalues
     * @return     real(diag(D))
     */
    public Double1d getRealEigenvalues () {
    	return new Double1d (evd_.getRealEigenvalues());
    }

    /**
     *  Return the imaginary parts of the eigenvalues
	 *  @return     imag(diag(D))
     */
    public Double1d  getImagEigenvalues () {
    	return new Double1d (evd_.getImagEigenvalues());
    }
    
    /**
     * Return the condition (2 norm) of the matrix.  Defined as
     * the ratio of the highest to the smallest singular value.
     * @return cond
	 */
     public double  getVcond () {
         //Double2d V = new Double2d (evd_.getV().getArray());
         //return (Double)V.apply(Basic.MAX)/(Double)V.apply(Basic.MIN);
         return evd_.getV().cond();
     }
}
