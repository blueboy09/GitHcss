/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2011 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;

import herschel.ia.numeric.Double2d;
import herschel.ia.numeric.Float2d;
import herschel.ia.numeric.toolbox.AbstractArrayToObject;

/**
 * Wraps the Jama class for DP.
   <P>
   For an m-by-n matrix A with m >= n, the singular value decomposition is
   an m-by-n orthogonal matrix U, an n-by-n diagonal matrix S, and
   an n-by-n orthogonal matrix V so that A = U*S*V'.
   <P>
   The singular values, sigma[k] = S[k][k], are ordered so that
   sigma[0] >= sigma[1] >= ... >= sigma[n-1].
   <P>
   The singular value decompostion always exists, so the constructor will
   never fail.  The matrix condition number and the effective numerical
   rank can be computed from this decomposition.

 *  This documentation has been taken from the Jama.SingularValueDecompostion
 *  javadocs.
 *
 * <p>
 * Example:
 * <pre> LU decomposition for ...
 * <em># jython </em>
 * 
 *
 *  IA>> A = Double2d([[ 2.0,  1.0,  1.0],[ 4.0, -6.0,  0.0],[-2.0,  7.0,  2.0]])
 *  IA>> svd=A.apply(SingularValueDecomposition())
 *  IA>>leftSingularValues = svd.u
 *
 *  IA>>rightSingularValues = svd.v
 *  
 *  IA>>singularValues = svd.singularValues
 *  
 *  IA>>diagonalMatrixOfSingularValues = svd.s
 *
 *  IA>>norm2 = svd.norm2
 *  IA>>cond = svd.cond
 *  IA>>rank = svd.rank
 *  IA>>print rank
 *
 * <em>// java: </em>
 *
 * Double2d A = new Double2d (...);
 * SingularValueDecomposition sgv = new SingularValueDecomposition(A);
 * Double2d leftSingularValues = svd.u;
 * Double2d rightSingularValues = svd.v;
 * double[] singularValues = svd.singularValues;
 * Double2d diagonalMatrixOfSingularValues = svd.s;
 * double norm2 = svd.norm2;
 * double cont = cvs.cond;
 * double rank = svd.rank;

 * </pre>
 * 
 * @jhelp SingularValueDecompositon
 * Wraps the Jama class for DP.
 * For an m-by-n matrix A with m >= n, the singular value decomposition is
 * an m-by-n orthogonal matrix U, an n-by-n diagonal matrix S, and
 * an n-by-n orthogonal matrix V so that A = U*S*V'.
 *
 * The singular values, sigma[k] = S[k][k], are ordered so that
 * sigma[0] >= sigma[1] >= ... >= sigma[n-1].
 *
 * The singular value decomposition always exists, so the constructor will
 * never fail.  The matrix condition number and the effective numerical
 * rank can be computed from this decomposition.
 *
 * @jalias SingularValueDecomposition 
 *
 * @jsynopsis
 *   A=Double2d()
 *   svd=B.apply(SingularValueDecomposition())
 *   leftSingularValues = svd.u
 *   rightSingularValues = svd.v
 *   singularValues = svd.singularValues
 *   diagonalMatrixOfSingularValues = svd.s
 *   norm2 = svd.norm2
 *   cont = cvs.cond
 *   rank = svd.rank
 *
 * @jexample SingularValueDecomposition
 *
 *  A = Double2d([[ 2.0,  1.0,  1.0],[ 4.0, -6.0,  0.0],[-2.0,  7.0,  2.0]])
 *  svd=A.apply(SingularValueDecomposition())
 *  leftSingularValues = svd.u
 *  print leftSingularValues
 *  # [
 *  # [-0.02280776366786053,-0.7589359216500687,-0.6507657587378364],
 *  # [0.6882378213114239,-0.4840524707277569,0.5403905133316635],
 *  # [-0.7251265456683931,-0.4355565088613817,0.5333685595866234]
 *  # ]
 *  rightSingularValues = svd.v
 *  print rightSingularValues
 *  # [
 *  # [0.4064876334980915,-0.810943043763452,-0.42087906052070156],
 *  # [-0.9022337235002555,-0.28366605734965333,-0.32481975938444235],
 *  # [-0.1440212206307982,-0.5117664972224835,0.8469669062771251]
 *  # ]
 *  singularValues = svd.singularValues
 *  print singularValues
 *  # array([10.228082004532315, 3.185141950908502, 0.49113059477592597], double)
 *  diagonalMatrixOfSingularValues = svd.s
 *  print diagonalMatrixOfSingularValues
 *  # [
 *  # [10.228082004532315,0.0,0.0],
 *  # [0.0,3.185141950908502,0.0],
 *  # [0.0,0.0,0.49113059477592597]
 *  # ]
 *  norm2 = svd.norm2
 *  print norm2
 *  # 10.228082004532315
 *  cond = svd.cond
 *  print cond
 *  # 20.825585115907487
 *  rank = svd.rank
 *  print rank
 *  # 3.0
 *  
 * @jparameter A, INPUT, Double2d , MANDATORY
 *   Input must be a Double2d or Float2d array.
 *
 * @jcategory
 *  herschel.ia.numeric.toolbox.matrix
 *
 * @author Jeff Jacobson <jdj@ipac.caltech.edu>
 */
public class SingularValueDecomposition 
extends AbstractArrayToObject
{
	/**
	 * Wraps the Jama.SingularValueDecomposition class.
	 */
	private Jama.SingularValueDecomposition svd_;

	/**
	 * Default constructor.
	 */
	public SingularValueDecomposition () {}

	/** 
	 * @param A    Input matrix
	 * @return     Object to access U, S and V
	 */	
	public SingularValueDecomposition(Double2d A) {
		svd_ = new Jama.SingularValueDecomposition(new Jama.Matrix (A.getArray()));
	}

	/**
	 * @param A    Input matrix
	 * @return     Object to access U, S and V
	 */	
	public SingularValueDecomposition(Float2d A) {
		svd_ = new Jama.SingularValueDecomposition(
				new Jama.Matrix (new Double2d (A).getArray()));
	}
    /**
     * Applies this function to an array of type Float2d.
     * @param A   Input matrix
     * @return Object - returns object to access U, S and V
     */
    public SingularValueDecomposition of(Float2d A) {
    	svd_ = new Jama.SingularValueDecomposition(
    			new Jama.Matrix (new Double2d (A).getArray()));
      return this;
    }

    /**
     * Applies this function to an array of type Double2d.
     * @param A   Input matrix
     * @return Object - .
     */
    public SingularValueDecomposition of(Double2d A) {
    	svd_ = new Jama.SingularValueDecomposition(
    			new Jama.Matrix (A.getArray()));
      return this;
    }

	/**
	 * Return left singular vectors
	 * @return U
	 */
	public Double2d getU () {
		Double2d U = new Double2d (svd_.getU().getArray());
		return U;
	}

	/**
	 * Return right singular vectors
	 * @return V
	 */
	public Double2d getV () {
		Double2d V = new Double2d (svd_.getV().getArray());
		return V;
	}

	/**
	 * Return the one-dimensional array of singlular vales
	 * @return diagonal of S
	 */
	public double[] getSingularValues () {
		double[] d = svd_.getSingularValues();
		return d;
	}

	/**
	 * Return the diagonal matrix of singular values
	 * @return S
	 */
	public Double2d getS () {
		Double2d S = new Double2d(svd_.getS().getArray());
		return S;
	}

	/**
	 * Return two norm
	 * @return number
	 */
	public double getNorm2 () {
		double number = svd_.norm2();
		return number;
	}

	/**
	 * Return two norm condition number
	 * @return number
	 */
	public double getCond () {
		double number = svd_.cond();
		return number;
	}
	/**
	 * Return effective numerical matrix rank
	 * @return number
	 */
	public double getRank () {
		double number = svd_.rank();
		return number;
	}
}
