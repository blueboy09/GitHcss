/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.*;

/**
 * Computes the determinant of a square matrix.
 * <p>
 * Example:
 * <pre>
 * <em>Computing the determinant of:</em>
 *    | 3  1 |
 * det|      |
 *    | 5  2 |
 *
 * <em># jython:</em>
 * a=Int2d( [ [3,1],[5,2] ])
 * det=MatrixDeterminant.FUNCTION(a)
 * <em># Note, for jython users a simplified approach is available:</em>
 * det=DETERMINANT(a)
 *
 * <em>// java:</em>
 * ArrayData a=new Int2d( [ [3,1],[5,2] ]);
 * Number det=a.apply(MatrixDeterminant.FUNCTION);
 * </pre>
 * 
 * @jhelp
 * Yields the determinant of a square matrix.
 *
 * @jalias DETERMINANT
 *
 * @jcategory Mathematics/Matrices
 *
 * @jsynopsis
 *  <y>=DETERMINANT(<x>)
 *
 * @jexample  Apply a DETERMINANT to a Double2d matrix
 * A=Double2d([ [1,2],[3,4] ])
 * print DETERMINANT(A) # -2
 *
 * @jparameter x, INPUT, any square matrix, MANDATORY
 *   Any square matrix
 *
 * @jparameter y, INPUT, double, NOT_MANDATORY, false
 *   Returns a double
 *
 * @jmiscellaneous
 * Does not work for complex matrices.
 *
 * @jref
 * herschel.ia.numeric.toolbox.interp.CubicSplineInterpolator
 * herschel.ia.numeric.toolbox.interp.LinearInterpolator
 *
 * @author Jorgo Bakker <jbakker@rssd.esa.int>
 */
public class MatrixDeterminant extends AbstractArrayToDouble
{
    public static final MatrixDeterminant FUNCTION=new MatrixDeterminant();
    private MatrixDeterminant() {}

    public double calc(Double2d x) {
	Util.checkIsSquare(x);
	return new Jama.Matrix(x.getArray()).det();
    }
}
