# 
#  This file is part of Herschel Common Science System (HCSS).
#  Copyright 2001-2010 Herschel Science Ground Segment Consortium
# 
#  HCSS is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as
#  published by the Free Software Foundation, either version 3 of
#  the License, or (at your option) any later version.
# 
#  HCSS is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU Lesser General Public License for more details.
# 
#  You should have received a copy of the GNU Lesser General
#  Public License along with HCSS.
#  If not, see <http://www.gnu.org/licenses/>.
# 
"""
Provides matrix functions. To get a full listing you have to execute:
     $ print herschel.ia.numeric.toolbox.matrix.__all__
     
Provides static function object instances:
 * TRANSPOSE(a)
 * INVERSE(a)
 * DETERMINANT(a)

Usage:
     $ A=Double2d([ [1,2],[3,4] ])
     $ x=Double1d([2,3])
     $ detA=DETERMINANT(A)
     $ invA=INVERSE(A)
     $ tA=TRANSPOSE(A)
"""

# --- Begin required code
#   Please see herschel.recursive_module_lookup() in herschel/__init__.py
#   for more information!
import herschel
herschel.recursive_module_lookup(__name__,__path__,__file__)
del(herschel)
# --- End required code


from Matrix import *

# public available when importing '*'
__all__=[
    # short-cuts to static instances
    'DETERMINANT',
    'INVERSE',
    'TRANSPOSE',
    # Java classes
    'CholeskyDecomposition',
    'EigenvalueDecomposition',
    'LUDecomposition',
    'QRDecomposition',
    'SingularValueDecomposition',
    'MatrixSolve',
    'MatrixMultiply',
    'MatrixMultiplyToy',
    ]
__all__.sort()
