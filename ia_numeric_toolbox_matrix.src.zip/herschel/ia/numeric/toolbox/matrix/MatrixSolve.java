/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.*;
import herschel.ia.numeric.toolbox.*;

/**
 * Solves systems of linear equations.
 * A system of equations is a collection of equations that you deal with all
 * together at once.
 * <p>
 * This function object supports solving linear equations of the form
 * <tt>A X = B</tt>, where A is a square numeric array of any type, and
 * X and B are numeric arrays of type Double1d.
 * <p>
 * <pre>
 * <em>Solving the linear equations:</em>
 *   21 x<sub>1</sub> +  4 x<sub>2</sub> = 5
 *  129 x<sub>1</sub> + 21 x<sub>2</sub> = 14
 *
 * <em>is equivalent to solving the matrix equation <tt>A X = B</tt>:</em>
 *  |&nbsp;21&nbsp;&nbsp;&nbsp;4|&nbsp;|x<sub>1</sub>|&nbsp;&nbsp;&nbsp;|&nbsp;5|
 *  |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;|&nbsp;&nbsp;|&nbsp;=&nbsp;|&nbsp;&nbsp;|
 *  |129&nbsp;&nbsp;21|&nbsp;|x<sub>2</sub>|&nbsp;&nbsp;&nbsp;|14|
 * &nbsp;
 * <em># jython:</em>
 * a=Int2d( [ [21,4],[129,21] ])
 * b=Double1d( [5,14] )
 * f=MatrixSolve(b)
 * x=f(a) #  x is a Double1d
 * <em># Note, for jython users a simplified approach is available:</em>
 * x=MatrixSolve(b)(a)
 * #or
 * x=a.apply(MatrixSolve(b))
 * &nbsp;
 * <em>// java:</em>
 * ArrayData a=new Int2d( [ [21,4],[129,21] ]);
 * ArrayData b=new Double1d( [ 5 14 ] );
 * ArrayData x=a.apply(new MatrixSolve(b)); // x is a Double1d
 * </pre>
 *
 * @jalias
 *    MATRIXSOLVE
 *
 * @jcategory Mathematics/Matrices
 *
 * @jhelp Solves systems of linear equations of type A x = b.
 * A system of equations is a collection of equations that you deal with all together at once.
 *
 *
 * @jsynopsis
 *  <x>=MatrixSolve(<b>)(<A>)
 *
 * @jexample  Apply MatrixSolve
 * # Solve
 * #  | 1  2 | |x1|   | 8|
 * #  |      | |  | = |  |
 * #  | 3  4 | |x2|   |18|
 * #
 * A=Float2d([ [1,2],[3,4] ])
 * b=Double1d([8.0,18.0])
 * print MatrixSolve(b)(A) # [2.0,3.0]
 * print A.apply(MatrixSolve(b))
 *
 * @jparameter A, INPUT, any matrix, MANDATORY
 *   Any matrix
 *
 * @jparameter b, INPUT, Double1d , MANDATORY
 *   Input must be a Double1d array.
 *
 * @jmiscellaneous
 * Does not work for complex matrices.
 *
 * @author Jorgo Bakker <jbakker@rssd.esa.int>
 */
public class MatrixSolve extends AbstractOrdered2dToReal1d
{
    private final Jama.Matrix _b;
    private final Range       _r;

    /**
     * Constructs a function object with the right-hand-side of the equation.
     */
    public MatrixSolve(Double1d b) {
	final int n=b.length();
	_r=new Range(0,n);
	_b=new Jama.Matrix(new Double2d(n,1).set(_r,0,b).getArray());
    }

    /**
     * solves <tt>x</tt> in the equation <tt>A x=B</tt>
     * @return Double1d array holding <tt>x</tt>
     */
    public Double1d calc(Double2d a) {
	final int[] dim=a.getDimensions();

	if (dim[1]!=_b.getRowDimension() )
	    // TODO: arrayshape exception
	    throw new IllegalArgumentException("herschel.ia.numeric.toolbox.matrix.MatrixSolve.calc(): " +
                      "Number of columns in "+
					       "coefficient matrix A does "+
					       "not match number of rows "+
					       "in B");

	Jama.Matrix lhs=new Jama.Matrix(a.getArray()).solve(_b);
	return new Double2d(lhs.getArray()).get(_r,0);

    }
}
