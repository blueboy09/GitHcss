/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2011 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;

import herschel.ia.numeric.Double2d;
import herschel.ia.numeric.Float2d;
import herschel.ia.numeric.toolbox.AbstractArrayToObject;

/**
 * @jhelp QRDecomposition
 * Wraps the Jama class for DP.
 *
 * For an m-by-n matrix A with m >= n, the QR decomposition is an m-by-n
 * orthogonal matrix Q and an n-by-n upper triangular matrix R so that
 * A = Q*R.
 *
 *  The QR decomposition always exists, even if the matrix does not have
 *  full rank, so the constructor will never fail.  The primary use of the
 *  QR decomposition is in the least squares solution of nonsquare systems
 *  of simultaneous linear equations.  This will fail if isFullRank()
 *  returns false.
 *
 * @jalias QRDecomposition 
 *
 * @jsynopsis
 *   A=Double2d()
 *   B=Double2d()
 *   res=B.apply(QRDecomposition(A))
 *   
 *   QRD = QRDecomposition(A)
 *   leastSquaresSolutionAXeqB = B.apply(QRD)
 *   isFullRank = QRD.isFullRank
 *   HouseholderVectors = QRD.h
 *   rightTriangularFactor = QRD.r
 *   orthFactor = QRD.qs
 * 
 * @jexample Decompose a 2D array and get QR components.
 *  A = Double2d([[ 2.0,  1.0,  1.0],[ 4.0, -6.0,  0.0],[-2.0,  7.0,  2.0]])
 *  B=Double2d( [ [3.0],[-8.0],[10.0] ] )
 *  QRD = QRDecomposition(A)
 *  leastSquaresSolutionAXeqB = B.apply(QRD)
 *  print leastSquaresSolutionAXeqB
 *  # [
 *  # [0.9999999999999971],
 *  # [1.9999999999999978],
 *  # [-0.9999999999999969]
 *  # ]
 *  isFullRank = QRD.isFullRank
 *  print isFullRank
 *  # 1
 *  HouseholderVectors = QRD.h
 *  print HouseholderVectors
 *  # [
 *  # [1.4082482904638631,0.0,0.0],
 *  # [0.8164965809277261,1.4099776105529318,0.0],
 *  # [-0.4082482904638631,-0.9120955864630134,2.0]
 *  # ]
 *
 *  rightTriangularFactor = QRD.r
 *  print rightTriangularFactor
 *  # [
 *  # [-4.898979485566356,7.3484692283495345,0.408248290463863],
 *  # [0.0,5.656854249492381,2.1213203435596424],
 *  # [0.0,0.0,-0.5773502691896262]
 *  # ]
 *  orthFactor = QRD.qs
 *  print orthFactor
 *  # [
 *  # [-0.40824829046386313,0.7071067811865475,0.5773502691896257],
 *  # [-0.8164965809277261,5.551115123125783E-17,-0.5773502691896256],
 *  # [0.4082482904638631,0.7071067811865475,-0.577350269189626]
 *  
 * @jparameter A, INPUT, Double2d , MANDATORY
 *   Input must be a Double2d or Float2d array.
 *
 * @jcategory
 *  herschel.ia.numeric.toolbox.matrix
 *
 * @author Jeff Jacobson <jdj@ipac.caltech.edu>
 *
 */
public class QRDecomposition 
extends AbstractArrayToObject
{
	/**
	 * Wraps the Jama.QRDecomposition class.
	 */
	private Jama.QRDecomposition qrd_;

	/**
	 * Default constructor.
	 */
	public QRDecomposition () {}

	/** 
	 * @param A    Input rectangular matrix
	 * @return     Structure to access R and the Householder vectors and compute Q.
	 */	
	public QRDecomposition(Double2d A) {
		qrd_ = new Jama.QRDecomposition(new Jama.Matrix (A.getArray()));
	}

	/**
	 * @param A    Input rectangular matrix
	 * @return     Structure to access R and the Householder vectors and compute Q.
	 */	
	public QRDecomposition(Float2d A) {
		qrd_ = new Jama.QRDecomposition(
				new Jama.Matrix (new Double2d (A).getArray()));
	}
    
    /**
     * getIsFullRank
     * is the madrix full rank
     * @return tru if R, and hence A, has full rank.
     */
    public boolean getIsFullRank() {
    	return qrd_.isFullRank();
    }

	/**
	 * Return the Householder vectors
	 * @return H, the lower trapezoidal matrix whose columns define the reflections
	 */
	public Double2d getH () {
		Double2d H = new Double2d (qrd_.getH().getArray());
		return H;
	}

	/**
	 * Return the upper triangular factor
	 * @return R
	 */
	public Double2d getR () {
		Double2d R = new Double2d (qrd_.getR().getArray());
		return R;
	}

	/**
	 * Generate and return the (economy-sized) orthogonal factor
	 * @return Q
	 */
	public Double2d getQs () {
		Double2d Q = new Double2d (qrd_.getQ().getArray());
		return Q;
	}

	/**
	 *  Least squares solution of A*X = B
     *  @param B    A Matrix with as many rows as A and any number of columns.
     *  @return     X that minimizes the two norm of Q*R*X-B.
     *  @exception  IllegalArgumentException  Matrix row dimensions must agree.
     *  @exception  RuntimeException  Matrix is rank deficient.
	 */
	public Double2d of (Double2d B) {
		Double2d S = new Double2d(qrd_.solve(
			new Jama.Matrix(B.getArray())).getArray());
		return S;
	}
	
	/**
	 *  Least squares solution of A*X = B
     *  @param B    A Matrix with as many rows as A and any number of columns.
     *  @return     X that minimizes the two norm of Q*R*X-B.
     *  @exception  IllegalArgumentException  Matrix row dimensions must agree.
     *  @exception  RuntimeException  Matrix is rank deficient.
	 */
	public Double2d of (Float2d B) {
		Double2d dB = new Double2d (B);
		Double2d S = new Double2d(qrd_.solve(
			new Jama.Matrix(dB.getArray())).getArray());
		return S;
	}
}
