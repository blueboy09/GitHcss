/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * QRDecompositionTest.java
 * JUnit based test
 * @author Jeff Jacobson (jdj@ipac.caltech.edu)
 */

package herschel.ia.numeric.toolbox.matrix.test;

import herschel.ia.numeric.Double1d;
import herschel.ia.numeric.Double2d;
import herschel.ia.numeric.Range;
import herschel.ia.numeric.toolbox.basic.Reshape;
import herschel.ia.numeric.toolbox.matrix.QRDecomposition;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 *
 * @author jdj
 * TODO: Test not complete.  Turn wrappers in anyway, add test for wrappers
 * later.  Need to beat code freeze Sept. 12.
 */
public class QRDecompositionTest extends TestCase {
    
    private static int maxIterations = 1;  // Force timeout handling.

    public QRDecompositionTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }

    /* AllTests uses this to access the QRDecompositionTest class. */
    public static Test suite() {
      return new TestSuite(QRDecompositionTest.class);
    }

/*  The Jama test??? Scrap code.

      double[] columnwise = {1.,2.,3.,4.,5.,6.,7.,8.,9.,10.,11.,12.};
    validld= 3;
      double[][] subavals = {{5.,8.,11.},{6.,9.,12.}};


      double[][] sqSolution = {{13.},{15.}};
      SUB = new Matrix(subavals);

      A = new Matrix(columnwise,4);
      QRDecompositionDecomposition SVD = A.svd();
      try {
         check(A,SVD.getU().times(SVD.getS().times(SVD.getV().transpose())));
         try_success("QRDecompositionDecomposition...","");
      } catch ( java.lang.RuntimeException e ) {
         errorCount = try_failure(errorCount,"QRDecompositionDecomposition...","incorrect singular value decomposition calculatio
n");
      }
      DEF = new Matrix(rankdef);
      try {
         check(DEF.rank(),Math.min(DEF.getRowDimension(),DEF.getColumnDimension())-1);
         try_success("rank()...","");
      } catch ( java.lang.RuntimeException e ) {
         errorCount = try_failure(errorCount,"rank()...","incorrect rank calculation");
      }
      B = new Matrix(condmat);
      SVD = B.svd();
      double [] singularvalues = SVD.getQRDecompositions();
      try {
         check(B.cond(),singularvalues[0]/singularvalues[Math.min(B.getRowDimension(),B.getColumnDimension())-1]);
         try_success("cond()...","");
      } catch ( java.lang.RuntimeException e ) {
         errorCount = try_failure(errorCount,"cond()...","incorrect condition number calculation");
      }    
*/

    /**
     * The Jama Test.  Not complete.
     */
    public void testDouble2d() throws Exception {
      double[] temp = {1.,2.,3.,4.,5.,6.,7.,8.,9.,10.,11.,12.};
      Double1d columnwise = new Double1d(temp);
      //int validld= 3;
      double[][] avals = {{1.,4.,7.,10.},{2.,5.,8.,11.},{3.,6.,9.,12.}};
      double[][] rankdef = avals;

      //double[][] subavals = {{5.,8.,11.},{6.,9.,12.}};
      //double[][] sqSolution = {{13.},{15.}};
      //Double2d DEF = new Double2d(rankdef);

      //A = new Matrix(columnwise,4);
      Double2d A = (Double2d) columnwise.apply (new Reshape(4,3));
      //int n = A.getColumnDimension();
      int n = A.getDimensions()[1];
      //A = A.getMatrix(0,n-1,0,n-1);
      Range range=new Range(0,n-1);
      A = A.get(range,range);
      A.set(0,0,0.);
      QRDecomposition SV = new QRDecomposition (A);
      // TBD: Complete this test.
      //check(A.getMatrix(SV.getPivot(),0,n-1),SV.getL().times(SV.getU()));
    }
    /**
     * testFringeModelCase
     * Under time pressure, we satisfy the one use case before 
     * the code deadline of March 23.
     */
    public void testFringeModel() throws Exception {
       double [][] tmp  = {
            {3944.2141901709658, -39.83013886638742, 24.856149542676924, -49.90362121047403},
            {-39.83013886638742, 3958.7850982903415, 39.244285251565444, 37.29778768650653},
            {24.856149542676924, 39.244285251565444, 3952.2910884701473, -1.216735893731549},
            {-49.90362121047403, 37.29778768650653, -1.216735893731549, 3950.7089115298527},
       };
       Double2d mat = new Double2d (tmp);
       double [][] tmp2 = {
            {1184.8157857233916},
            {-360.85066234104187},
            {-426.7929837904702},
            {-179.95015720518913}
       };
       Double2d vec = new Double2d (tmp2);
       double [][] tmp3 = {
            {0.2996866683828611},
            {-0.0866698113921456},
            {-0.10902299354957672},
            {-0.040978662517317826}
       };
       Double2d expected = new Double2d (tmp3);
       int [] dims = expected.getDimensions();
       int rows = dims[0];
       int cols = dims[1];

       // Run the test.
       QRDecomposition qrd = new QRDecomposition(mat);
       Double2d result = (Double2d) vec.apply(qrd);
       // Check the results.
       for (int i=0; i<rows; i++) {
          for (int j=0; j<cols; j++) {
             String msg = "QRDecomposition (" + i + ",i" + j + ") incorrect result:";
             assertEquals (msg, expected.get(i,j), result.get(i,j), 1e-07);
          }
       }
    }



   private static void check(Double2d X, Double2d Y) {
      double eps = Math.pow(2.0,-52.0);
      if (norm1(X) == 0. & norm1(Y) < 10*eps) return;
      if (norm1(Y) == 0. & norm1(X) < 10*eps) return;
      //System.out.println ("\nnorm1(X) = " + norm1(X));
      //System.out.println ("norm1(Y) = " + norm1(Y));
      //System.out.println ("eps = " + eps);
      //System.out.println ("1000 * eps * max(norm1(X), norm1(Y)) = " + 10*eps*Math.max(norm1(X),norm1(Y)));
      //System.out.println ("X.copy().subtract(Y)) = " + X.copy().subtract(Y));
      if (norm1(X.copy().subtract(Y)) > 
          1000*eps*Math.max(norm1(X),norm1(Y))) {
         throw new RuntimeException("The norm of (X-Y) is too large: " 
            +  Double.toString(norm1(X.copy().subtract(Y))));
      }
    }

   /** Check that vCond > 0 and both imaginary and real parts are returned. **/
   private void check(double c, Double1d i, Double1d r) {
	   if (c <= 0.0) {
	       throw new RuntimeException ("Vcond <= 0.0, found " + c + ".");
   	}
   	if (i == null) {
   	    throw new RuntimeException ("No imaginary values.");
   	}
   	if (r == null) {
   	    throw new RuntimeException ("No real values");
   	}
   }

   private static double norm1 (Double2d A) {
      int dim[] = A.getDimensions ();
      int m = dim[0];
      int n = dim[1];
      double f = 0.;
      for (int j = 0; j < n; j++) {
         double s = 0;
         for (int i = 0; i < m; i++) {
            s += Math.abs(A.get(i,j));
         }
         f = Math.max(f,s);
      }
      return f;
   }

   /** Linear algebraic matrix multiplication, A * B
   @param B    another matrix
   @return     Matrix product, A * B
   @exception  IllegalArgumentException Matrix inner dimensions must agree.
   JJ's note:  Should use Matrix.Multiply, but that needs test harness.
   */
   private Double2d times (Double2d A, Double2d B) {
      int Am = A.getDimensions()[0];
      int An = A.getDimensions()[1];
      int Bm = B.getDimensions()[0];
      int Bn = B.getDimensions()[1];

      if (Bm != An) {
         throw new IllegalArgumentException("Matrix inner dimensions must agree.");
      }
      //Double2d X = new Double2d(Am,Bn);
      //double[][] C = X.getArray();
      double [][] C = new double[Am][Bn];
      double[] Bcolj = new double[An];
      for (int j = 0; j < Bn; j++) {
         for (int k = 0; k < An; k++) {
            //Bcolj[k] = B.A[k][j];
            Bcolj[k] = B.get(k,j);
         }
         for (int i = 0; i < Am; i++) {
            //double[] Arowi = A[i];
            double[] Arowi = A.get(i).toArray();
            double s = 0;
            for (int k = 0; k < An; k++) {
               s += Arowi[k]*Bcolj[k];
            }
            C[i][j] = s;
         }
      }
      return new Double2d(C);
   }

}

