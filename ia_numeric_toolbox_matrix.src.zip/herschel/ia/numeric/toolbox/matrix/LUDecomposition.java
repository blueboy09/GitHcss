/*
 * This file is part of Herschel Common Science System (HCSS).
 * Copyright 2001-2010 Herschel Science Ground Segment Consortium
 *
 * HCSS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * HCSS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with HCSS.
 * If not, see <http://www.gnu.org/licenses/>.
 */
package herschel.ia.numeric.toolbox.matrix;
import herschel.ia.numeric.Int1d;
import herschel.ia.numeric.Double1d;
import herschel.ia.numeric.Double2d;
import herschel.ia.numeric.Float2d;
import herschel.ia.numeric.toolbox.AbstractArrayToObject;

/**
 * LU Decompostion, wraps the Jama class for DP.
 * <p>
 * For an m-by-n matrix A with m >= n, the LU decomposition is an m-by-n
 * unit lower triangular matrix L, an n-by-n upper triangular matrix U,
 * and a permutation vector piv of length m so that A(piv,:) = L*U.
 * If m < n, then L is m-by-m and U is m-by-n.
 * <P>
 * The LU decompostion with pivoting always exists, even if the matrix is
 * singular, so the constructor will never fail.  The primary use of the
 * LU decomposition is in the solution of square systems of simultaneous
 * linear equations.  This will fail if isNonsingular() returns false.
 *
 *  This documentation has been taken from the Jama.LUDecompostion
 *  javadocs.
 *
 * <p>
 * Example:
 * <pre> LU decomposition for ...
 * <em># jython </em>
 * 
 * A=Double2d( [ [1.,1.,1.],[1.,2.,3.],[1.,3.,6.] ] )
 * B=Double2d( [ [1.,1.,1.],[1.,2.,3.],[1.,3.,6.] ] )
 * result = B.apply(LUDecomposition(A))
 *
 * <em>// java: </em>
 *
 * Double2d A = new Double2d (...);
 * Double2d B = new Double2d (...);
 * lud = new LUDecomposition(A);
 * Double2d result = (Double2d) B.apply(lud);
 * Double2d lowerTriangularFactor = lud.getL();
 * Double2d upperTrangularFactor = lud.getU();
 * double determinant = lud.getDet();
 * Int1d integerPivot = lud.getPivot();
 * Double1d doublePivot = lud.getDoublePivot();
 * bool flag = lud.isSingular();
 * </pre>
 *
 * @jalias LUDecomposition 
 *
 * @jcategory Mathematics/Matrices
 *
 * @jsynopsis
 *   A=Double2d()
 *   B=Double2d()
 *   res=B.apply(LUDecomposition(A))
 *   
 *   lud = LUDecomposition(A)
 *   res = B.apply(lud)
 *   lowerTriangularFactor = lud.l
 *   uppperTrangularFactor = lud.u
 *   determinant = lud.det
 *   integerPivot = lud.pivot
 *   doublePivot = lud.doublePivot
 *   flag = lud.isSingular();
 * 
 * @jexample
 * 
 *  # Cava, Matrix Test Report:
 *  #########################
 *  #### LUDecomposition ####
 *  #########################
 *  #
 *  ### HIPE ###
 *  #
 *  A = Double2d([[ 2.0,  1.0,  1.0],[ 4.0, -6.0,  0.0],[-2.0,  7.0,  2.0]])
 *  print A
 *  [
 *  [2.0,1.0,1.0],
 *  [4.0,-6.0,0.0],
 *  [-2.0,7.0,2.0]
 *  ]
 *  B = Double2d([[3.0],[-8.0],[10.0]])
 *  print B
 *  [
 *  [3.0],
 *  [-8.0],
 *  [10.0]
 *  ]
 *  res=B.apply(LUDecomposition(A))
 *  print res
 *  [
 *  [1.0],
 *  [2.0],
 *  [-1.0]
 *  ]
 *  #
 *
 * @jparameter A, INPUT, Double2d , MANDATORY
 *   Input must be a Double2d or Float2d array.
 *
 * @author Jeff Jacobson <jdj@ipac.caltech.edu>
 */
public class LUDecomposition 
extends AbstractArrayToObject
{
    /**
     * Wraps the Jama.LUDecompostion class.
     */
    private Jama.LUDecomposition lud_;

    /**
     * Default constructor.
     */
    public LUDecomposition () {}

    /** 
     * @param A    Input matrix
     * @return     Object contains methods for pivot, upper and lower
     *             triangular factors, determinant.
     */	
    public LUDecomposition(Double2d A) {
	lud_ = new Jama.LUDecomposition(new Jama.Matrix (A.getArray()));
    }

    /**
     * @param A    Input matrix
     * @return     Object contains methods for pivot, upper and lower
     *             triangular matrices, determinant.
     */	
    public LUDecomposition(Float2d A) {
	lud_ = new Jama.LUDecomposition(
		new Jama.Matrix (new Double2d (A).getArray()));
    }

    /** Is the matrix nonsingular?
   @return     true if U, and hence A, is nonsingular.
     */

    public boolean isNonsingular () {
	return lud_.isNonsingular();
    }

    /**
     * Return lower triangular factor.
     * @return L
     */
    public Double2d getL () {
	Double2d L = new Double2d (lud_.getL().getArray());
	return L;
    }

    /**
     * Return upper triangular factor.
     * @return U
     */
    public Double2d getU () {
	Double2d U = new Double2d (lud_.getU().getArray());
	return U;
    }

    /**
     * Determinant
     * @return det(A)
     */
    public double getDet () {
	double d = lud_.det();
	return d;
    }

    /**
     * Return pivot permutation factor as an Int1d
     * @return piv
     */
    public Int1d getPivot () {
	Int1d piv = new Int1d(lud_.getPivot());
	return piv;
    }

    /**
     * Return pivot permutation factor as a Double1d
     * @return piv
     */
    public Double1d getDoublePivot () {
	Double1d piv = new Double1d(lud_.getDoublePivot());
	return piv;
    }

    /** apply to solve A*X = B
     * @param  B   A Matrix with as many rows as A and any number of columns.
     *  @return     X so that L*U*X = B(piv,:)
     * @exception  IllegalArgumentException Matrix row dimensions must agree.
     * @exception  RuntimeException  Matrix is singular.
     */
    public Double2d of (Double2d B) {
	double[][] tmp = lud_.solve(new Jama.Matrix(B.getArray())).getArray();
	Double2d X = new Double2d(tmp);
	return (X);
    }

    /** apply to solve A*X = B
     * @param  B   A Matrix with as many rows as A and any number of columns.
     *  @return     X so that L*U*X = B(piv,:)
     * @exception  IllegalArgumentException Matrix row dimensions must agree.
     * @exception  RuntimeException  Matrix is singular.
     */
    public Double2d of (Float2d B) {
	Double2d dB = new Double2d (B);
	double[][] tmp = lud_.solve(new Jama.Matrix(dB.getArray())).getArray();
	Double2d X = new Double2d(tmp);
	return (X);
    }
}
